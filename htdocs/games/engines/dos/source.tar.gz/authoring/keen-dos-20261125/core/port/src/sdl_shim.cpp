/* Posse DOS runtime: implementation of the minimal SDL 1.2 shim (see core/port/include/SDL.h).
 * Clock: deterministic virtual milliseconds advanced only by the host (posse_clock_*),
 *        or wall clock when posse_clock_set_mode(1). SDL_Delay advances the virtual clock
 *        by the requested amount (models the sleep) so the DOSBox loop never spins forever.
 * Audio: SDL_OpenAudio records the callback; the host pulls PCM with posse_audio_pull(),
 *        which runs the DOSBox mixer callback under the (single-threaded) audio lock.
 * CD:    no physical drives. Mutexes: single-threaded no-ops. */
#include "SDL.h"
#include <string.h>
#include <time.h>

static int clock_mode = 0;          /* 0 = virtual (deterministic), 1 = wall clock */
static Uint64 virt_ms = 0;
static Uint64 wall_base_ns = 0;
static SDL_AudioSpec audio_spec;
static int audio_open = 0, audio_paused = 1, audio_lock = 0;

static Uint64 now_ns(void) {
  struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
  return (Uint64)ts.tv_sec * 1000000000ull + (Uint64)ts.tv_nsec;
}

extern "C" {
void posse_clock_set_mode(int mode) { clock_mode = mode ? 1 : 0; wall_base_ns = now_ns(); }
int posse_clock_mode(void) { return clock_mode; }
void posse_clock_advance(Uint32 ms) { virt_ms += ms; }
Uint32 posse_clock_now(void) { return SDL_GetTicks(); }

Uint32 SDL_GetTicks(void) {
  if (clock_mode) return (Uint32)((now_ns() - wall_base_ns) / 1000000ull);
  return (Uint32)virt_ms;
}
void SDL_Delay(Uint32 ms) {
  if (clock_mode) { struct timespec ts = { (time_t)(ms / 1000), (long)(ms % 1000) * 1000000L }; nanosleep(&ts, 0); }
  else virt_ms += ms;
}
const char *SDL_GetError(void) { return "posse headless shim"; }

int SDL_OpenAudio(SDL_AudioSpec *desired, SDL_AudioSpec *obtained) {
  if (!desired || !desired->callback || desired->channels != 2 || desired->format != AUDIO_S16SYS) return -1;
  audio_spec = *desired;
  audio_spec.size = (Uint32)audio_spec.samples * 4u;
  if (obtained) *obtained = audio_spec;
  audio_open = 1; audio_paused = 1;
  return 0;
}
void SDL_PauseAudio(int p) { audio_paused = p ? 1 : 0; }
void SDL_LockAudio(void) { audio_lock++; }
void SDL_UnlockAudio(void) { if (audio_lock > 0) audio_lock--; }
void SDL_CloseAudio(void) { audio_open = 0; }

int posse_audio_rate(void) { return audio_open ? audio_spec.freq : 0; }
/* Fill `frames` stereo S16 frames into out; returns frames written (0 if audio unavailable). */
int posse_audio_pull(Sint16 *out, int frames) {
  if (!audio_open || audio_paused || frames <= 0) { if (out && frames > 0) memset(out, 0, (size_t)frames * 4); return 0; }
  audio_spec.callback(audio_spec.userdata, (Uint8 *)out, frames * 4);
  return frames;
}

struct SDL_mutex { int dummy; };
static SDL_mutex the_mutex;
SDL_mutex *SDL_CreateMutex(void) { return &the_mutex; }
void SDL_DestroyMutex(SDL_mutex *) {}
int SDL_mutexP(SDL_mutex *) { return 0; }
int SDL_mutexV(SDL_mutex *) { return 0; }

int SDL_CDNumDrives(void) { return 0; }
const char *SDL_CDName(int) { return ""; }
SDL_CD *SDL_CDOpen(int) { return 0; }
CDstatus SDL_CDStatus(SDL_CD *) { return CD_ERROR; }
int SDL_CDPlayTracks(SDL_CD *, int, int, int, int) { return -1; }
int SDL_CDPlay(SDL_CD *, int, int) { return -1; }
int SDL_CDPause(SDL_CD *) { return -1; }
int SDL_CDResume(SDL_CD *) { return -1; }
int SDL_CDStop(SDL_CD *) { return -1; }
int SDL_CDEject(SDL_CD *) { return -1; }
void SDL_CDClose(SDL_CD *) {}
}
