// Posse DOS runtime: runs the Wasm build in a node worker and collects frames.tsv-equivalent evidence.
import { Worker } from 'node:worker_threads';
import { readFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
export const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const sha = b => createHash('sha256').update(b).digest('hex');
// Same 64-bit hash over RGB bytes (alpha skipped) as fnv() in core/port/src/posse_main.cpp, bit for bit.
// NOTE: the native code's offset basis is 1469598103934665603 (the standard FNV-1a basis 14695981039346656037
// with its last digit missing). It is deterministic, but it is not standard FNV-1a. The native source is
// frozen for review, so this mirrors it exactly; see handoffs/verifier-web-candidate-20261125.md.
export const NATIVE_FNV_BASIS = 1469598103934665603n;
export function fnv64(u8, w, h, pitch) {
  let hi = 0x14650fb0, lo = 0x739d0383;
  for (let y = 0; y < h; y++) { const r = y * pitch;
    for (let i = 0; i < w * 4; i++) { if ((i & 3) === 3) continue;
      lo = (lo ^ u8[r + i]) >>> 0;
      const t = lo * 0x1b3, carry = Math.floor(t / 4294967296);
      hi = (hi * 0x1b3 + carry + ((lo << 8) >>> 0)) >>> 0; lo = t >>> 0; } }
  return hi.toString(16).padStart(8, '0') + lo.toString(16).padStart(8, '0');
}
// Authenticates the web artifact against its in-build manifest before loading it.
export function authenticateWeb(dir = join(ROOT, 'build/web')) {
  const m = JSON.parse(readFileSync(join(dir, 'build-manifest.json'), 'utf8'));
  if (m.format !== 'posse-dos-web-build-manifest/1') throw new Error('unexpected web build manifest');
  for (const k of ['js', 'wasm']) if (sha(readFileSync(join(dir, m.output[k].file))) !== m.output[k].sha256) throw new Error(`${k} artifact does not match its build manifest`);
  return { dir, manifest: m, js: join(dir, m.output.js.file), wasm: join(dir, m.output.wasm.file) };
}
export function runWasm({ drive, conf, untilMs, speed = 1000, mtimeMs = 694224000 * 1000, timeoutMs = 180000, dir, keepFrames = [] }) {
  const keep = new Set(keepFrames), raw = new Map();
  const art = authenticateWeb(dir);
  const ctl = new SharedArrayBuffer(272 * 4), c = new Int32Array(ctl); c[3] = speed;
  const frames = [], modes = []; let audioFrames = 0, audioNonzero = 0, rate = 0, lastMs = 0, exit = null; const logs = [];
  return new Promise((res, rej) => {
    const w = new Worker(join(ROOT, 'core/web/node-worker.mjs'), { workerData: { ctl, js: art.js, wasm: art.wasm, drive: [...drive], conf, mtimeMs } });
    const stop = () => { Atomics.store(c, 2, 2); Atomics.notify(c, 4); };
    const timer = setTimeout(() => { stop(); setTimeout(() => w.terminate(), 2000); rej(new Error('wasm run timeout')); }, timeoutMs);
    w.on('message', m => {
      if (m.type === 'frame') { const u8 = new Uint8Array(m.data); const prev = frames.at(-1);
        if (!prev || prev.w !== m.w || prev.h !== m.h) modes.push({ frame: m.n, ms: m.ms, width: m.w, height: m.h });
        if (keep.has(m.n)) raw.set(m.n, { w: m.w, h: m.h, pitch: m.pitch, data: u8 });
        if (m.ms <= untilMs) frames.push({ n: m.n, ms: m.ms, w: m.w, h: m.h, hash: fnv64(u8, m.w, m.h, m.pitch) }); }
      else if (m.type === 'audio') { const s = new Int16Array(m.data); rate = m.rate; audioFrames += s.length / 2; for (const v of s) if (v) audioNonzero++; }
      else if (m.type === 'clock') { lastMs = m.ms; if (m.ms >= untilMs) stop(); }
      else if (m.type === 'log') { if (logs.length < 200) logs.push(m.text); }
      else if (m.type === 'exit') exit = m;
      else if (m.type === 'returned') { clearTimeout(timer); w.terminate(); res({ artifact: { js: art.manifest.output.js.sha256, wasm: art.manifest.output.wasm.sha256, inputDigest: art.manifest.inputs.inputDigest }, exit, code: m.code, lastClockMs: lastMs, frames, modes, rate, audioFrames, audioNonzero, logs, raw }); }
    });
    w.on('error', e => { clearTimeout(timer); rej(e); });
  });
}
