#!/usr/bin/env bash
# Posse DOS runtime: native headless build of the DOSBox 0.74-3 machine + Posse port layer.
# Usage: core/port/scripts/build-native.sh [OUTDIR]   (default build/native)
# Invalidation is content-based: a compiler/flag/include change rebuilds everything; otherwise a TU
# is reused only if the sha256 of its source and every header in its -MMD depfile is unchanged AND the
# object still has the sha256 recorded when this script compiled it (OBJ.o.objsha, N4). Immediately before
# linking every listed object is re-hashed against that record; altered objects are rebuilt (obj/altered.log)
# and the link is refused if any still differs. manifest.mjs re-checks after linking and binds the records.
# Only TUs listed now are linked. build-manifest.json is written during the build itself.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd)"
[[ "$ROOT" != *[[:space:]]* ]] || { echo "project path must not contain whitespace"; exit 1; }
OUT="${1:-$ROOT/build/native}"; mkdir -p "$OUT/obj"; OUT="$(cd "$OUT" && pwd)"
CXX="${CXX:-g++}"
CXXFLAGS="${CXXFLAGS:--O2 -g0 -std=gnu++11 -fno-strict-aliasing -Wno-deprecated -Wno-narrowing -w}"
LDFLAGS="${LDFLAGS:-}"
INC="-I$ROOT/core/port/include -I$ROOT/core/dosbox/include"
S="$ROOT/core/port/scripts"
rm -f "$OUT/build-manifest.json" "$OUT/posse-dosbox.tmp"
START_DIGEST="$(node "$S/digest.mjs" "$ROOT")"
CXX_PATH="$(command -v "$CXX")" || { echo "compiler not found: $CXX"; exit 1; }
CXX_REAL="$(readlink -f "$CXX_PATH")"; CXX_SHA="$(sha256sum "$CXX_REAL" | cut -d' ' -f1)"
CXX_VERSION="$("$CXX" --version | head -1)"
CC1PLUS="$("$CXX" -print-prog-name=cc1plus 2>/dev/null || true)"; CC1PLUS_SHA=""
[[ -n "$CC1PLUS" && -f "$CC1PLUS" ]] && { CC1PLUS="$(readlink -f "$CC1PLUS")"; CC1PLUS_SHA="$(sha256sum "$CC1PLUS" | cut -d' ' -f1)"; } || CC1PLUS=""
CONFIG="$(printf 'cxx=%s\nsha=%s\nversion=%s\ncc1plus=%s %s\ncxxflags=%s\ninc=%s\n' "$CXX_REAL" "$CXX_SHA" "$CXX_VERSION" "$CC1PLUS" "$CC1PLUS_SHA" "$CXXFLAGS" "$INC")"
if [[ ! -f "$OUT/obj/config.stamp" || "$(cat "$OUT/obj/config.stamp")" != "$CONFIG" ]]; then
  rm -rf "$OUT/obj"; mkdir -p "$OUT/obj"; printf '%s' "$CONFIG" > "$OUT/obj/config.stamp"; fi
SRCS=()
while read -r s; do [[ -z "$s" || "$s" == \#* ]] && continue; SRCS+=("core/dosbox/src/$s"); done < "$ROOT/core/port/sources.txt"
SRCS+=(core/port/src/sdl_shim.cpp core/port/src/headless_gfx.cpp core/port/src/posse_main.cpp core/port/src/posse_time.cpp)
objof() { echo "$OUT/obj/$(echo "$1" | tr '/' '_').o"; }
# Object content record: OBJ.o.objsha holds only the hex sha256 written right after this script compiled OBJ.o.
objsha_ok() { [[ -f "$1" && -s "$1.objsha" && "$(sha256sum "$1" | cut -d' ' -f1)" == "$(cat "$1.objsha")" ]]; }
compile() { local s="$1" o; o="$OUT/obj/$(echo "$1" | tr '/' '_').o"; local sd; sd="$(dirname "$ROOT/$s")"
  if [[ -f "$o" && -s "$o.deps" ]] && sha256sum --status -c "$o.deps" 2>/dev/null; then
    if [[ ! -s "$o.objsha" ]]; then echo "unrecorded $s" >> "$OUT/obj/altered.log"
    elif objsha_ok "$o"; then return 0
    else echo "altered $s" >> "$OUT/obj/altered.log"; fi; fi
  rm -f "$o" "$o.deps" "$o.d" "$o.objsha"; echo "compile $s" >> "$OUT/obj/compiled.log"
  $CXX $CXXFLAGS $INC -I"$sd" -MMD -MF "$o.d" -c "$ROOT/$s" -o "$o" 2>"$o.err" || { rm -f "$o"; echo "FAIL $s"; return 1; }
  sed -e 's/^[^:]*://' -e 's/\\$//' "$o.d" | tr ' ' '\n' | grep -v '^$' | sort -u | xargs sha256sum > "$o.deps"
  sha256sum "$o" | cut -d' ' -f1 > "$o.objsha.tmp" && mv -f "$o.objsha.tmp" "$o.objsha"; }
export -f compile objsha_ok; export ROOT OUT CXX CXXFLAGS INC
: > "$OUT/obj/compiled.log"; : > "$OUT/obj/altered.log"; fail=0
printf '%s\n' "${SRCS[@]}" | xargs -P "$(nproc)" -I{} bash -c 'compile "$@"' _ {} || fail=1
cat "$OUT"/obj/*.err > "$OUT/errors.log" 2>/dev/null || true
if [[ $fail -ne 0 ]]; then echo "compile failures; see $OUT/errors.log"; exit 1; fi
: > "$OUT/obj/tus.txt"; OBJS=()
for s in "${SRCS[@]}"; do o="$(objof "$s")"; OBJS+=("$o"); printf '%s\t%s\n' "$s" "$o" >> "$OUT/obj/tus.txt"; done
declare -A KEEP=(); for o in "${OBJS[@]}"; do KEEP["$o"]=1; done
for f in "$OUT"/obj/*.o; do [[ -n "${KEEP[$f]:-}" ]] || { echo "drop unlisted object $f"; rm -f "$f" "$f".*; }; done
# N4: every listed object must still equal its compile-time record immediately before the link.
for pass in 1 2; do bad=0
  while IFS=$'\t' read -r s o; do objsha_ok "$o" && continue; bad=1; echo "prelink-altered $s" >> "$OUT/obj/altered.log"
    if [[ $pass -eq 1 ]]; then compile "$s" < /dev/null || { cat "$o.err" >> "$OUT/errors.log" 2>/dev/null || true; echo "recompile failed: $s"; exit 1; }; fi
  done < "$OUT/obj/tus.txt"
  if [[ $bad -eq 0 ]]; then break; fi
  if [[ $pass -eq 2 ]]; then echo "objects differ from their compile-time sha256 records; refusing to link"; exit 1; fi
done
mapfile -t OBJS < <(printf '%s\n' "${OBJS[@]}" | LC_ALL=C sort)
"$CXX" -o "$OUT/posse-dosbox.tmp" "${OBJS[@]}" $LDFLAGS 2>"$OUT/link.log" || { rm -f "$OUT/posse-dosbox.tmp"; echo "link failed; see $OUT/link.log"; exit 1; }
export CXX_REAL CXX_SHA CXX_VERSION CC1PLUS CC1PLUS_SHA LDFLAGS
export LINK_DESC="$CXX -o posse-dosbox <${#OBJS[@]} listed objects, C-sorted> $LDFLAGS"
node "$S/manifest.mjs" "$ROOT" "$OUT" "$START_DIGEST" "$OUT/posse-dosbox.tmp" || { rm -f "$OUT/posse-dosbox.tmp"; echo "manifest refused; no binary installed"; exit 1; }
mv -f "$OUT/posse-dosbox.tmp" "$OUT/posse-dosbox"
echo "built $OUT/posse-dosbox ($(wc -l < "$OUT/obj/compiled.log") TUs compiled, $(grep -c '^altered\|^prelink-altered' "$OUT/obj/altered.log" || true) altered objects rebuilt)"
