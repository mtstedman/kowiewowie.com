// Posse DOS runtime: native vs Wasm parity on one package/executable (no input). Writes a receipt.
// node core/web/parity.mjs PACKAGE.zip EXE UNTIL_MS
import { writeFileSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { PackageManager } from '../../lib/package/PackageManager.mjs';
import { buildConfig } from '../../lib/runner/conf.mjs';
import { DosRunner } from '../../lib/runner/DosRunner.mjs';
import { runWasm, ROOT } from './node-host.mjs';
const [pkg, exe, until] = process.argv.slice(2); const untilMs = Number(until);
const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..*/, 'Z').toLowerCase();
const pm = new PackageManager(); const { key, metadata } = await pm.importFile(pkg, { executable: exe });
const id = metadata.candidateIdentity;
const conf = buildConfig({ driveDir: 'C', executable: id.executable, format: id.format, machine: id.machine });
const t0 = Date.now(); const web = await runWasm({ drive: pm.drive(key), conf, untilMs }); const webWallMs = Date.now() - t0;
const nat = await new DosRunner().run({ packageFile: pkg, executable: exe, untilMs, instance: `webparity-native-${stamp}` });
const nf = readFileSync(join(nat.instanceDir, 'out/frames.tsv'), 'utf8').trim().split('\n').slice(1).map(l => l.split('\t')).map(([n, ms, w, h, hash]) => ({ n: +n, ms: +ms, w: +w, h: +h, hash }));
const wf = web.frames; let firstDiff = null;
for (let i = 0; i < Math.max(nf.length, wf.length); i++) { const a = nf[i], b = wf[i];
  if (!a || !b || a.n !== b.n || a.ms !== b.ms || a.w !== b.w || a.h !== b.h || a.hash !== b.hash) { firstDiff = { index: i, native: a ?? null, wasm: b ?? null }; break; } }
const r = { format: 'posse-dos-web-parity/1', stamp, package: id, untilMs, wasm: { ...web.artifact, exit: web.exit, lastClockMs: web.lastClockMs, frames: wf.length, modes: web.modes, rate: web.rate, audioFrames: web.audioFrames, audioNonzero: web.audioNonzero, wallMs: webWallMs },
  native: { binarySha256: nat.binarySha256, instanceDir: nat.instanceDir, frames: nf.length, modes: nat.summary.modes, audioFrames: nat.summary.audioFrames, audioNonzero: nat.summary.audioNonzeroSamples },
  framesIdentical: firstDiff === null, firstDiff };
writeFileSync(join(ROOT, `build/web/parity-${stamp}.json`), JSON.stringify(r, null, 2) + '\n');
console.log(JSON.stringify(r).slice(0, 2500));
