/* Posse DOS runtime: headless runner entry point for the DOSBox 0.74-3 machine.
 * New Posse port code, GPL-2.0-or-later (links DOSBox).
 * Usage: posse-dosbox --conf FILE --until-ms N [--input FILE] [--shot-ms a,b,..] [--out DIR] [--wall]
 * The DOS program/drive mapping comes from the [autoexec] section of FILE (host-generated).
 * Clock is virtual by default: emulated ms advance only after the CPU has executed that ms of configured cycles.
 * Shot T = the displayed framebuffer at emulated ms T: taken at the ms-T tick, or at the end of the frame being
 * rendered at that tick. DOSBox completes a frame only when content changed (frames.tsv lists those changed
 * frames), so a static screen still yields its shot. If a shot is still pending at --until-ms the run continues
 * up to SHOT_GRACE_MS; summary.emulatedMs reports the actual end.
 * DIR (must already exist and be writable) receives summary.json, frames.tsv (one line per completed frame),
 * audio.wav and shot-NNNNNNNN.ppm. Nothing is written for usage/config/input errors.
 * Exit status: 0 only if --until-ms was reached, every output was written and every shot was taken;
 * 1 machine error/killswitch, 2 usage/config/input/--out error, 3 DOS program or shell exited before
 * --until-ms (includes a nonexistent program), 4 output I/O error, 5 requested shot missing. */
#include "dosbox.h"
#include "control.h"
#include "keyboard.h"
#include "mapper.h"
#include "posse_host.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string>
#include <vector>
#include <set>
#include <algorithm>

void POSSE_Config_Add_Headless();


struct KeyEv { uint32_t ms; KBD_KEYS key; bool down; };
struct KeyName { const char *n; KBD_KEYS k; };
static const KeyName key_names[] = {
 {"1",KBD_1},{"2",KBD_2},{"3",KBD_3},{"4",KBD_4},{"5",KBD_5},{"6",KBD_6},{"7",KBD_7},{"8",KBD_8},{"9",KBD_9},{"0",KBD_0},
 {"q",KBD_q},{"w",KBD_w},{"e",KBD_e},{"r",KBD_r},{"t",KBD_t},{"y",KBD_y},{"u",KBD_u},{"i",KBD_i},{"o",KBD_o},{"p",KBD_p},
 {"a",KBD_a},{"s",KBD_s},{"d",KBD_d},{"f",KBD_f},{"g",KBD_g},{"h",KBD_h},{"j",KBD_j},{"k",KBD_k},{"l",KBD_l},{"z",KBD_z},
 {"x",KBD_x},{"c",KBD_c},{"v",KBD_v},{"b",KBD_b},{"n",KBD_n},{"m",KBD_m},
 {"f1",KBD_f1},{"f2",KBD_f2},{"f3",KBD_f3},{"f4",KBD_f4},{"f5",KBD_f5},{"f6",KBD_f6},{"f7",KBD_f7},{"f8",KBD_f8},{"f9",KBD_f9},{"f10",KBD_f10},
 {"esc",KBD_esc},{"tab",KBD_tab},{"backspace",KBD_backspace},{"enter",KBD_enter},{"space",KBD_space},
 {"lalt",KBD_leftalt},{"ralt",KBD_rightalt},{"lctrl",KBD_leftctrl},{"rctrl",KBD_rightctrl},{"lshift",KBD_leftshift},{"rshift",KBD_rightshift},
 {"left",KBD_left},{"up",KBD_up},{"down",KBD_down},{"right",KBD_right},{"home",KBD_home},{"end",KBD_end},{"pageup",KBD_pageup},{"pagedown",KBD_pagedown},
 {"insert",KBD_insert},{"delete",KBD_delete},{"kpenter",KBD_kpenter},{0,KBD_NONE}};

static const uint32_t MAX_UNTIL_MS = 3600000u, SHOT_GRACE_MS = 1000u;
struct Shot { uint32_t req_ms, frame_ms; uint64_t frame; int w, h; std::string file; };
struct Mode { uint64_t frame; uint32_t ms; int w, h; };
static struct Run {
  uint32_t until_ms = 0; std::string out = ".";
  std::vector<KeyEv> keys; size_t key_i = 0; uint32_t keys_sent = 0;
  std::vector<uint32_t> shots; size_t shot_i = 0; std::vector<Shot> shots_written;
  FILE *pcm = 0, *frames_log = 0; uint64_t audio_frames = 0, audio_nonzero = 0; double audio_acc = 0; int rate = 0;
  std::set<uint64_t> distinct; uint64_t last_hash = 0; int w = 0, h = 0; uint64_t frames = 0;
  std::vector<Mode> modes; std::vector<std::string> logs, io_errors;
} R;
static void io_fail(const std::string &what, int err) {
  if (R.io_errors.size() < 50) R.io_errors.push_back(what + ": " + (err ? strerror(err) : "short write"));
}
static bool parse_u32(const char *s, uint32_t *v) {
  if (!s || *s < '0' || *s > '9') return false;
  char *end; errno = 0; unsigned long long x = strtoull(s, &end, 10);
  if (errno || *end || x > 0xffffffffull) return false;
  *v = (uint32_t)x; return true;
}
static uint64_t fnv(const uint32_t *px, int w, int h, int pitch) {
  uint64_t x = 1469598103934665603ull;
  for (int y = 0; y < h; y++) { const uint8_t *row = (const uint8_t *)px + (size_t)y * pitch;
    for (int i = 0; i < w * 4; i++) { if ((i & 3) == 3) continue; x ^= row[i]; x *= 1099511628211ull; } }
  return x;
}
static bool write_ppm(const char *path, const uint32_t *px, int w, int h, int pitch) {
  FILE *f = fopen(path, "wb"); if (!f) { io_fail(path, errno); return false; }
  bool ok = fprintf(f, "P6\n%d %d\n255\n", w, h) > 0;
  std::vector<uint8_t> line((size_t)w * 3);
  for (int y = 0; ok && y < h; y++) { const uint32_t *r = (const uint32_t *)((const uint8_t *)px + (size_t)y * pitch);
    for (int x = 0; x < w; x++) { line[x*3] = (r[x] >> 16) & 255; line[x*3+1] = (r[x] >> 8) & 255; line[x*3+2] = r[x] & 255; }
    ok = fwrite(&line[0], 1, line.size(), f) == line.size(); }
  int e = errno;
  if (fclose(f) != 0) { ok = false; e = errno; }
  if (!ok) { io_fail(path, e); remove(path); }
  return ok;
}
static const char *base_name(const char *p) { const char *b = strrchr(p, '/'); return b ? b + 1 : p; }
static void take_shots(uint32_t now, const uint32_t *px, int w, int h, int pitch, uint64_t n) {
  while (R.shot_i < R.shots.size() && R.shots[R.shot_i] <= now) {
    uint32_t ms = R.shots[R.shot_i++];
    char p[1200]; snprintf(p, sizeof p, "%s/shot-%08u.ppm", R.out.c_str(), ms);
    if (!write_ppm(p, px, w, h, pitch)) continue;
    Shot s = { ms, now, n, w, h, base_name(p) }; R.shots_written.push_back(s);
  }
}
static void on_frame(void *, const uint32_t *px, int w, int h, int pitch, uint64_t n) {
  uint32_t now = posse_clock_now();
  R.frames = n; R.last_hash = fnv(px, w, h, pitch);
  if (R.distinct.size() < 100000) R.distinct.insert(R.last_hash);
  if (w != R.w || h != R.h) { Mode m = { n, now, w, h }; R.modes.push_back(m); R.w = w; R.h = h; }
  if (R.frames_log && fprintf(R.frames_log, "%llu\t%u\t%d\t%d\t%016llx\n", (unsigned long long)n, now, w, h,
                              (unsigned long long)R.last_hash) < 0) { io_fail("frames.tsv", errno); fclose(R.frames_log); R.frames_log = 0; }
  take_shots(now, px, w, h, pitch, n);
}
static void pull_audio() {
  if (!R.rate) { R.rate = posse_audio_rate(); if (!R.rate) return; }
  R.audio_acc += R.rate / 1000.0; int n = (int)R.audio_acc; if (n <= 0) return; R.audio_acc -= n;
  static std::vector<int16_t> buf; buf.resize((size_t)n * 2);
  if (posse_audio_pull(&buf[0], n) != n) return;
  for (int i = 0; i < n * 2; i++) if (buf[i]) R.audio_nonzero++;
  R.audio_frames += n;
  if (R.pcm && fwrite(&buf[0], 4, n, R.pcm) != (size_t)n) io_fail("audio.pcm", errno);
}
static uint32_t last_tick_ms = 0xffffffffu;
static void on_tick(void *) {
  uint32_t now = posse_clock_now();
  if (now == last_tick_ms) return; /* once per emulated ms */
  last_tick_ms = now;
  pull_audio();
  while (R.key_i < R.keys.size() && R.keys[R.key_i].ms <= now && R.keys[R.key_i].ms <= R.until_ms) {
    KEYBOARD_AddKey(R.keys[R.key_i].key, R.keys[R.key_i].down); R.key_i++; R.keys_sent++; }
  { const uint32_t *px; int w, h, pitch;
    if (R.shot_i < R.shots.size() && R.shots[R.shot_i] <= now && posse_framebuffer(&px, &w, &h, &pitch)) take_shots(now, px, w, h, pitch, posse_frame_count()); }
  if (now >= R.until_ms && (R.shot_i >= R.shots.size() || now >= R.until_ms + SHOT_GRACE_MS)) posse_request_exit();
}
static void on_log(void *, const char *m) { if (R.logs.size() < 200) R.logs.push_back(m); }

/* Strict: every line is blank, a '#' comment, or exactly "MS KEY down|up". Anything else is an error. */
static bool load_input(const char *path) {
  FILE *f = fopen(path, "r"); if (!f) { fprintf(stderr, "cannot open input %s: %s\n", path, strerror(errno)); return false; }
  char line[512]; unsigned ln = 0; bool ok = true;
  while (ok && fgets(line, sizeof line, f)) {
    ln++; size_t L = strlen(line);
    if (L == sizeof line - 1 && line[L - 1] != '\n' && !feof(f)) { fprintf(stderr, "input line %u too long\n", ln); ok = false; break; }
    char *p = line; while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') p++;
    if (!*p || *p == '#') continue;
    char ms_s[32], name[64], act[16], extra[2]; uint32_t ms = 0;
    int nt = sscanf(p, "%31s %63s %15s %1s", ms_s, name, act, extra);
    KBD_KEYS k = KBD_NONE;
    if (nt == 3) for (const KeyName *kn = key_names; kn->n; kn++) if (!strcmp(kn->n, name)) k = kn->k;
    if (nt != 3 || !parse_u32(ms_s, &ms) || k == KBD_NONE || (strcmp(act, "down") && strcmp(act, "up"))) {
      fprintf(stderr, "bad input line %u (want 'MS KEY down|up'): %s%s", ln, p, p[strlen(p) - 1] == '\n' ? "" : "\n"); ok = false; break; }
    KeyEv e = { ms, k, !strcmp(act, "down") }; R.keys.push_back(e);
  }
  if (ferror(f)) { fprintf(stderr, "read error on input %s\n", path); ok = false; }
  fclose(f);
  std::stable_sort(R.keys.begin(), R.keys.end(), [](const KeyEv &a, const KeyEv &b) { return a.ms < b.ms; });
  return ok;
}
static bool wav_header(FILE *f, int rate, uint32_t frames) {
  uint32_t data = frames * 4, riff = 36 + data, br = rate * 4, sr = rate, fmt = 16; uint16_t pcm = 1, ch = 2, ba = 4, bits = 16;
  uint8_t h[44]; memcpy(h, "RIFF", 4); memcpy(h + 4, &riff, 4); memcpy(h + 8, "WAVEfmt ", 8); memcpy(h + 16, &fmt, 4);
  memcpy(h + 20, &pcm, 2); memcpy(h + 22, &ch, 2); memcpy(h + 24, &sr, 4); memcpy(h + 28, &br, 4); memcpy(h + 32, &ba, 2);
  memcpy(h + 34, &bits, 2); memcpy(h + 36, "data", 4); memcpy(h + 40, &data, 4);
  return fwrite(h, 1, 44, f) == 44;
}
static void json_str(FILE *f, const std::string &s) {
  fputc('"', f); for (unsigned char c : s) { if (c == '"' || c == '\\') { fputc('\\', f); fputc(c, f); } else if (c < 0x20) fprintf(f, "\\u%04x", c); else fputc(c, f); } fputc('"', f);
}
static int usage(const char *why) {
  fprintf(stderr, "%s\nusage: posse-dosbox --conf FILE --until-ms N(1..%u) [--input FILE] [--shot-ms a,b] [--out DIR] [--wall]\n", why, MAX_UNTIL_MS);
  return 2;
}

// Output-open failure (exit 4) must not leave partial outputs behind. Only files this process opened, and so
// created or truncated, are closed and removed; nothing else in the output directory is touched.
static void close_partial_outputs(const std::string &pcmp, const std::string &flp) {
  if (R.pcm) { fclose(R.pcm); R.pcm = 0; remove(pcmp.c_str()); }
  if (R.frames_log) { fclose(R.frames_log); R.frames_log = 0; remove(flp.c_str()); }
}

int main(int argc, char *argv[]) {
  const char *conf = 0, *input = 0, *shot_arg = 0; bool wall = false;
  for (int i = 1; i < argc; i++) {
    std::string a = argv[i]; const char *v = i + 1 < argc ? argv[i + 1] : 0;
    if (a == "--wall") { wall = true; continue; }
    if (!v) return usage(("missing value for " + a).c_str());
    i++;
    if (a == "--conf") conf = v;
    else if (a == "--until-ms") { if (!parse_u32(v, &R.until_ms)) return usage("--until-ms must be a decimal integer"); }
    else if (a == "--input") input = v;
    else if (a == "--out") R.out = v;
    else if (a == "--shot-ms") shot_arg = v;
    else return usage(("unknown argument: " + a).c_str());
  }
  if (!conf) return usage("--conf is required");
  if (R.until_ms < 1 || R.until_ms > MAX_UNTIL_MS) return usage("--until-ms out of range");
  if (shot_arg) {
    std::string s = shot_arg; size_t p = 0;
    while (true) { size_t q = s.find(',', p); if (q == std::string::npos) q = s.size(); uint32_t ms;
      if (!parse_u32(s.substr(p, q - p).c_str(), &ms)) return usage("--shot-ms must be comma-separated decimal integers");
      R.shots.push_back(ms); if (q == s.size()) break; p = q + 1; }
    std::sort(R.shots.begin(), R.shots.end());
    if (std::adjacent_find(R.shots.begin(), R.shots.end()) != R.shots.end()) return usage("--shot-ms has duplicates");
    if (R.shots.back() > R.until_ms) return usage("--shot-ms beyond --until-ms");
  }
  struct stat st;
  if (stat(R.out.c_str(), &st) != 0 || !S_ISDIR(st.st_mode) || access(R.out.c_str(), W_OK | X_OK) != 0) {
    fprintf(stderr, "--out %s must be an existing writable directory\n", R.out.c_str()); return 2; }
  { FILE *cf = fopen(conf, "r"); if (!cf) { fprintf(stderr, "cannot open config %s: %s\n", conf, strerror(errno)); return 2; } fclose(cf); }
  if (input && !load_input(input)) return 2;
  setenv("TZ", "UTC0", 1); tzset(); /* localtime() must not depend on the host zone */
  posse_clock_set_mode(wall ? 1 : 0);
  PosseHostHooks hk = { on_frame, on_tick, on_log, 0 }; posse_set_hooks(&hk);
  std::string exit_reason = "program-exit", error;
  std::string pcmp = R.out + "/audio.pcm", flp = R.out + "/frames.tsv";
  const char *cargv[] = { "posse-dosbox" };
  try {
    CommandLine com_line(1, cargv);
    Config myconf(&com_line); control = &myconf;
    POSSE_Config_Add_Headless();
    DOSBOX_Init();
    if (!control->ParseConfigFile(conf)) { fprintf(stderr, "cannot parse config %s\n", conf); return 2; }
    /* outputs are opened only after the config parsed */
    R.pcm = fopen(pcmp.c_str(), "wb"); if (!R.pcm) io_fail("audio.pcm", errno);
    R.frames_log = fopen(flp.c_str(), "w"); if (!R.frames_log) io_fail("frames.tsv", errno);
    else if (fprintf(R.frames_log, "frame\tms\twidth\theight\tfnv64\n") < 0) io_fail("frames.tsv", errno);
    if (!R.io_errors.empty()) { fprintf(stderr, "cannot open outputs in %s: %s\n", R.out.c_str(), R.io_errors[0].c_str());
      close_partial_outputs(pcmp, flp); return 4; }
    control->Init();
    MAPPER_Init();
    control->StartUp();
  } catch (char *e) { exit_reason = "machine-error"; error = e; }
  catch (int) { exit_reason = posse_exit_requested() ? "until-ms" : "killswitch"; }
  if (R.pcm && fclose(R.pcm) != 0) io_fail("audio.pcm", errno);
  R.pcm = 0;
  if (R.frames_log && fclose(R.frames_log) != 0) io_fail("frames.tsv", errno);
  bool have_frames = R.frames_log != 0; R.frames_log = 0;
  bool have_wav = false;
  if (R.rate && R.audio_frames && R.io_errors.empty()) {
    std::string wp = R.out + "/audio.wav";
    FILE *in = fopen(pcmp.c_str(), "rb"); if (!in) io_fail("audio.pcm", errno);
    FILE *o = in ? fopen(wp.c_str(), "wb") : 0; if (in && !o) io_fail("audio.wav", errno);
    bool ok = in && o && wav_header(o, R.rate, (uint32_t)R.audio_frames);
    char b[65536]; size_t n;
    while (ok && (n = fread(b, 1, sizeof b, in))) ok = fwrite(b, 1, n, o) == n;
    if (in && ferror(in)) ok = false;
    if (in) fclose(in);
    if (o && fclose(o) != 0) ok = false;
    if (in && o && !ok) { io_fail("audio.wav", errno); remove(wp.c_str()); }
    have_wav = ok;
  }
  if (remove(pcmp.c_str()) != 0 && errno != ENOENT) io_fail("audio.pcm remove", errno);
  std::set<uint32_t> taken; for (const Shot &s : R.shots_written) taken.insert(s.req_ms);
  std::vector<uint32_t> missing; for (uint32_t ms : R.shots) if (!taken.count(ms)) missing.push_back(ms);
  int code = 0;
  if (exit_reason == "machine-error" || exit_reason == "killswitch") code = 1;
  else if (exit_reason == "program-exit") code = 3;
  else if (!R.io_errors.empty()) code = 4;
  else if (!missing.empty()) code = 5;
  std::vector<std::string> failures;
  if (exit_reason != "until-ms") failures.push_back(exit_reason == "program-exit" ? "program-exit-before-until-ms" : exit_reason);
  if (!R.io_errors.empty()) failures.push_back("io-error");
  if (!missing.empty()) failures.push_back("missing-shots");
  std::string sp = R.out + "/summary.json", tp = sp + ".tmp";
  FILE *s = fopen(tp.c_str(), "w");
  if (!s) { fprintf(stderr, "cannot write %s: %s\n", tp.c_str(), strerror(errno)); return 4; }
  fprintf(s, "{\"format\":\"posse-dosbox-summary/2\",\"ok\":%s,\"exitStatus\":%d,\"exit\":", code ? "false" : "true", code); json_str(s, exit_reason);
  fprintf(s, ",\"failures\":["); for (size_t i = 0; i < failures.size(); i++) { if (i) fputc(',', s); json_str(s, failures[i]); }
  fprintf(s, "],\"error\":"); json_str(s, error);
  fprintf(s, ",\"clock\":\"%s\",\"untilMs\":%u,\"emulatedMs\":%u,\"frames\":%llu,\"width\":%d,\"height\":%d,\"lastFrameHash\":\"%016llx\",\"distinctFrames\":%zu",
    wall ? "wall" : "virtual", R.until_ms, posse_clock_now(), (unsigned long long)R.frames, R.w, R.h, (unsigned long long)R.last_hash, R.distinct.size());
  fprintf(s, ",\"modes\":["); for (size_t i = 0; i < R.modes.size(); i++)
    fprintf(s, "%s{\"frame\":%llu,\"ms\":%u,\"width\":%d,\"height\":%d}", i ? "," : "", (unsigned long long)R.modes[i].frame, R.modes[i].ms, R.modes[i].w, R.modes[i].h);
  fprintf(s, "],\"framesFile\":%s,\"audioRate\":%d,\"audioFrames\":%llu,\"audioNonzeroSamples\":%llu,\"audioFile\":%s,\"keysParsed\":%zu,\"keysSent\":%u",
    have_frames ? "\"frames.tsv\"" : "null", R.rate, (unsigned long long)R.audio_frames, (unsigned long long)R.audio_nonzero, have_wav ? "\"audio.wav\"" : "null", R.keys.size(), R.keys_sent);
  fprintf(s, ",\"shotsRequested\":["); for (size_t i = 0; i < R.shots.size(); i++) fprintf(s, "%s%u", i ? "," : "", R.shots[i]);
  fprintf(s, "],\"shots\":["); for (size_t i = 0; i < R.shots_written.size(); i++) { if (i) fputc(',', s); json_str(s, R.shots_written[i].file); }
  fprintf(s, "],\"shotDetails\":["); for (size_t i = 0; i < R.shots_written.size(); i++) { const Shot &h = R.shots_written[i];
    fprintf(s, "%s{\"requestedMs\":%u,\"frameMs\":%u,\"frame\":%llu,\"width\":%d,\"height\":%d,\"file\":", i ? "," : "", h.req_ms, h.frame_ms, (unsigned long long)h.frame, h.w, h.h);
    json_str(s, h.file); fputc('}', s); }
  fprintf(s, "],\"missingShots\":["); for (size_t i = 0; i < missing.size(); i++) fprintf(s, "%s%u", i ? "," : "", missing[i]);
  fprintf(s, "],\"ioErrors\":["); for (size_t i = 0; i < R.io_errors.size(); i++) { if (i) fputc(',', s); json_str(s, R.io_errors[i]); }
  fprintf(s, "],\"log\":["); for (size_t i = 0; i < R.logs.size(); i++) { if (i) fputc(',', s); json_str(s, R.logs[i]); }
  fprintf(s, "]}\n");
  bool sok = !ferror(s); if (fclose(s) != 0) sok = false;
  if (!sok || rename(tp.c_str(), sp.c_str()) != 0) { fprintf(stderr, "cannot write %s\n", sp.c_str()); remove(tp.c_str()); return 4; }
  return code;
}
