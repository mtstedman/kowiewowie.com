// Posse DOS runtime: content digest of every native build input (upstream tree + port layer).
// Shared by build-native.sh (manifest), provenance.mjs and DosRunner. CLI: node digest.mjs ROOT
import { readFileSync, readdirSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { join, relative, sep, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
export const sha = b => createHash('sha256').update(b).digest('hex');
export function walk(d, out = []) {
  for (const e of readdirSync(d, { withFileTypes: true })) { const p = join(d, e.name); if (e.isDirectory()) walk(p, out); else if (e.isFile()) out.push(p); }
  return out;
}
// Under core/port/scripts only the build driver and its helpers are inputs.
export const BUILD_SCRIPTS = Object.freeze(['build-native.sh', 'digest.mjs', 'manifest.mjs']);
export function buildInputs(root) {
  const rel = p => relative(root, p).split(sep).join('/');
  const files = [...walk(join(root, 'core/dosbox')), ...walk(join(root, 'core/port'))]
    .filter(p => { const r = rel(p); return !r.startsWith('core/port/scripts/') || BUILD_SCRIPTS.includes(r.slice(18)); })
    .map(p => [rel(p), sha(readFileSync(p))]).sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
  return { files: files.length, inputDigest: sha(files.map(([r, h]) => r + ' ' + h).join('\n')) };
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) process.stdout.write(buildInputs(resolve(process.argv[2] || '.')).inputDigest + '\n');
