/* Posse DOS runtime: deterministic host calendar time for the headless machine.
 * New Posse port code, GPL-2.0-or-later. DOSBox reads host wall time via time()/localtime() in
 * dos.cpp (boot date + BIOS tick counter seed) and cmos.cpp (RTC registers). In virtual clock mode
 * this executable-level definition interposes time() for the whole program: it returns a fixed
 * epoch plus elapsed emulated seconds. main() sets TZ=UTC0 so localtime() is host-independent.
 * In wall mode the real time is returned. Deliberately does not include <time.h>; x86-64/LP64 and
 * wasm32 libcs both define time_t as a signed long-sized integer (static_assert below). */
#include <stdint.h>
#include <unistd.h>
#include <sys/syscall.h>
#include "posse_host.h"
static_assert(sizeof(long) == sizeof(void *), "posse_time assumes time_t == long");
extern "C" long time(long *t) {
  long v;
  if (posse_clock_mode() == 0) v = (long)POSSE_VIRTUAL_EPOCH + (long)(posse_clock_now() / 1000u);
  else v = (long)syscall(SYS_time, (long *)0);
  if (t) *t = v;
  return v;
}
