#!/usr/bin/env node
// Posse DOS runtime: provenance for the source-built core. It is derived from build-manifest.json, which the build
// itself wrote, and it is authenticated against the current tree and binary. Exit 1 (no JSON) when the binary is
// missing, the manifest is missing, the binary hash differs from the manifest, or the current input digest
// differs from the digest the build recorded. Usage: node provenance.mjs [OUTDIR]   (default build/native)
import { readFileSync, existsSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildInputs, walk, sha } from './digest.mjs';
import { relative, sep } from 'node:path';
const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../../..');
const out = resolve(process.argv[2] || join(ROOT, 'build/native'));
const fail = m => { process.stderr.write(JSON.stringify({ error: m }) + '\n'); process.exit(1); };
const mp = join(out, 'build-manifest.json'), bp = join(out, 'posse-dosbox');
if (!existsSync(mp)) fail(`no build manifest at ${mp}; rebuild with core/port/scripts/build-native.sh`);
if (!existsSync(bp)) fail(`no binary at ${bp}`);
const m = JSON.parse(readFileSync(mp, 'utf8'));
const binSha = sha(readFileSync(bp));
if (binSha !== m.output.sha256) fail(`binary ${binSha} does not match manifest output ${m.output.sha256}`);
const now = buildInputs(ROOT);
if (now.inputDigest !== m.inputs.inputDigest) fail(`source tree digest ${now.inputDigest} differs from the digest the binary was built from (${m.inputs.inputDigest}); rebuild`);
// N4: the manifest must carry the compile-time object records, its object-set digest must recompute from them, and
// any object still present in OUT/obj must equal its recorded sha256 (both in the manifest and in OBJ.o.objsha).
const oi = m.objectIntegrity, tus = Array.isArray(m.translationUnits) ? m.translationUnits : [];
if (!oi || typeof oi.objectSetDigest !== 'string' || oi.verifiedObjects !== tus.length) fail('build manifest has no object-integrity records (N4); rebuild');
for (const t of tus) if (!/^[0-9a-f]{64}$/.test(t.objectSha256 || '') || t.compileRecordSha256 !== t.objectSha256) fail(`object record missing or inconsistent for ${t.source}`);
if (sha(tus.map(t => `${t.source} ${t.objectSha256}`).join('\n')) !== oi.objectSetDigest) fail('objectSetDigest does not recompute from translationUnits');
let objectsPresent = 0;
for (const t of tus) { const op = join(out, t.object); if (!existsSync(op)) continue; objectsPresent++;
  const a = sha(readFileSync(op)); if (a !== t.objectSha256) fail(`object ${t.object} is ${a}, manifest records ${t.objectSha256}`);
  const rp = op + '.objsha'; if (!existsSync(rp) || readFileSync(rp, 'utf8').trim() !== t.objectSha256) fail(`compile record for ${t.object} is missing or differs`); }
const upstream = JSON.parse(readFileSync(join(ROOT, 'core/upstream.json'), 'utf8'));
const dosDir = join(ROOT, 'core/dosbox');
const present = new Map(walk(dosDir).map(p => [relative(dosDir, p).split(sep).join('/'), sha(readFileSync(p))]));
const modified = [], missing = [], added = [];
for (const [f, h] of Object.entries(upstream.files)) { if (!present.has(f)) missing.push(f); else if (present.get(f) !== h) modified.push(f); }
for (const f of present.keys()) if (!(f in upstream.files)) added.push(f);
const portFiles = Object.fromEntries(walk(join(ROOT, 'core/port')).map(p => [relative(ROOT, p).split(sep).join('/'), sha(readFileSync(p))]).sort());
const copying = readFileSync(join(dosDir, 'COPYING'));
process.stdout.write(JSON.stringify({
  format: 'posse-dos-core-provenance/2',
  upstream: { project: upstream.project, version: upstream.version, license: upstream.license, archiveUrl: upstream.archiveUrl,
    archiveSha256: upstream.archiveSha256, archiveBytes: upstream.archiveBytes, importedFiles: Object.keys(upstream.files).length,
    unmodified: !modified.length && !missing.length && !added.length, modified, missing, added },
  license: { file: 'core/dosbox/COPYING', sha256: sha(copying), matchesImport: sha(copying) === upstream.files.COPYING,
    port: 'core/port/* is new Posse port code under GPL-2.0-or-later (links DOSBox)' },
  port: { files: portFiles },
  build: { manifest: relative(ROOT, mp), manifestSha256: sha(readFileSync(mp)), builtAt: m.builtAt, compiler: m.compiler,
    cxxflags: m.cxxflags, ldflags: m.ldflags, linkCommand: m.linkCommand, translationUnits: m.translationUnits.length, inputs: m.inputs,
    objectIntegrity: { scheme: oi.scheme, verifiedObjects: oi.verifiedObjects, objectSetDigest: oi.objectSetDigest, objectsPresentAndMatching: objectsPresent } },
  authenticated: { binaryMatchesManifest: true, treeMatchesManifest: true, checkedAt: new Date().toISOString() },
  output: { path: relative(ROOT, bp), bytes: m.output.bytes, sha256: binSha },
}, null, 2) + '\n');
