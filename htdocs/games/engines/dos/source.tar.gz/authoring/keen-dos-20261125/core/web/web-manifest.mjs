// Posse DOS runtime: writes OUT/build-manifest.json for the browser build, during the build.
// Refuses if the inputs changed between build start and link (contemporaneous provenance).
import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { sha } from '../port/scripts/digest.mjs';
import { webBuildInputs } from './web-digest.mjs';
const [root, out, startDigest] = process.argv.slice(2);
const now = webBuildInputs(root);
if (now.inputDigest !== startDigest) { console.error(`inputs changed during build (${startDigest} -> ${now.inputDigest}); rebuild`); process.exit(1); }
const js = readFileSync(join(out, 'stage/posse-dosbox.js')), wasm = readFileSync(join(out, 'stage/posse-dosbox.wasm'));
const compiled = readFileSync(join(out, 'obj/compiled.log'), 'utf8').split('\n').filter(Boolean).length;
const m = { format: 'posse-dos-web-build-manifest/1', upstream: 'DOSBox 0.74-3 (core/upstream.json), GPL-2.0; port layer GPL-2.0-or-later',
  toolchain: { image: process.env.IMAGE, imageId: process.env.IMAGE_ID, emcc: process.env.EMCC_VERSION },
  flags: { cxxflags: process.env.CXXFLAGS, ldflags: process.env.LDFLAGS },
  inputs: { files: now.files, inputDigest: now.inputDigest },
  translationUnits: readFileSync(join(out, 'obj/srcs.txt'), 'utf8').split('\n').filter(Boolean), compiledThisBuild: compiled,
  output: { js: { file: 'posse-dosbox.js', bytes: js.length, sha256: sha(js) }, wasm: { file: 'posse-dosbox.wasm', bytes: wasm.length, sha256: sha(wasm) } } };
writeFileSync(join(out, 'build-manifest.json'), JSON.stringify(m, null, 2) + '\n');
