/* Posse DOS runtime: host boundary for the headless DOSBox frontend.
 * The machine (CPU, memory, DOS/BIOS, devices) stays inside DOSBox; the host only
 * receives finished frames, is called once per emulated millisecond, and injects input. */
#ifndef POSSE_HOST_H
#define POSSE_HOST_H
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef struct PosseHostHooks {
  /* Called after every completed frame. px is XRGB8888, pitch in bytes. */
  void (*frame)(void *ctx, const uint32_t *px, int width, int height, int pitch, uint64_t frame_no);
  /* Called from GFX_Events (about once per emulated ms). May throw via posse_request_exit(). */
  void (*tick)(void *ctx);
  /* Called when DOSBox prints a log/info message. */
  void (*log)(void *ctx, const char *msg);
  void *ctx;
} PosseHostHooks;
void posse_set_hooks(const PosseHostHooks *hooks);
void posse_request_exit(void);              /* stop the machine at the next safe point */
int posse_exit_requested(void);
uint64_t posse_frame_count(void);
void posse_frame_size(int *w, int *h);
/* Displayed framebuffer (XRGB8888). Returns 0 before the first frame or while a frame is mid-render.
 * DOSBox only completes a frame when screen content changed, so between frames this is the visible image. */
int posse_framebuffer(const uint32_t **px, int *w, int *h, int *pitch);
/* clock (sdl_shim.cpp) */
void posse_clock_set_mode(int mode);
int posse_clock_mode(void);                   /* 0 virtual, 1 wall */
/* Calendar time seen by the machine in virtual mode: 1992-01-01T00:00:00Z + emulated seconds. */
#define POSSE_VIRTUAL_EPOCH 694224000
void posse_clock_advance(uint32_t ms);
uint32_t posse_clock_now(void);
/* audio (sdl_shim.cpp) */
int posse_audio_rate(void);
int posse_audio_pull(int16_t *out, int frames);
#ifdef __cplusplus
}
#endif
#endif
