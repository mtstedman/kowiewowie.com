/* Posse DOS runtime: hand-maintained replacement for DOSBox 0.74-3 autoconf config.h.
 * Applies to native (gcc/clang, LP64) and wasm32 (emscripten) headless builds.
 * Disabled on purpose: dynamic cores, debugger, OpenGL, screenshots (libpng),
 * IPX/modem/directserial networking, SDL_sound CD audio, priority control. */
#ifndef POSSE_DOSBOX_CONFIG_H
#define POSSE_DOSBOX_CONFIG_H

#define PACKAGE "dosbox"
#define PACKAGE_NAME "dosbox"
#define PACKAGE_TARNAME "dosbox"
#define PACKAGE_VERSION "0.74-3"
#define PACKAGE_STRING "dosbox 0.74-3 (posse-headless)"
#define PACKAGE_BUGREPORT ""
#define PACKAGE_URL ""
#define VERSION "0.74-3"

#define C_FPU 1
#define C_CORE_INLINE 1
#define C_HAS_ATTRIBUTE 1
#define C_HAS_BUILTIN_EXPECT 1
#define C_ATTRIBUTE_ALWAYS_INLINE 1
#define DIRENT_HAS_D_TYPE 1
#define STDC_HEADERS 1
#define HAVE_INTTYPES_H 1
#define HAVE_MEMORY_H 1
#define HAVE_STDINT_H 1
#define HAVE_STDLIB_H 1
#define HAVE_STRINGS_H 1
#define HAVE_STRING_H 1
#define HAVE_SYS_STAT_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_UNISTD_H 1
#define HAVE_PWD_H 1
#define HAVE_REALPATH 1
/* LINUX intentionally NOT defined: it only selects physical CD-ROM ioctl and direct-serial code,
 * both excluded from this headless build (no host devices are exposed to the DOS machine). */

#define SIZEOF_UNSIGNED_CHAR 1
#define SIZEOF_UNSIGNED_SHORT 2
#define SIZEOF_UNSIGNED_INT 4
#define SIZEOF_UNSIGNED_LONG __SIZEOF_LONG__
#define SIZEOF_UNSIGNED_LONG_LONG 8
#define SIZEOF_INT_P __SIZEOF_POINTER__

#if C_ATTRIBUTE_ALWAYS_INLINE
#define INLINE inline __attribute__((always_inline))
#else
#define INLINE inline
#endif
#define DB_FASTCALL
#define GCC_ATTRIBUTE(x) __attribute__ ((x))
#define GCC_UNLIKELY(x) __builtin_expect((x),0)
#define GCC_LIKELY(x) __builtin_expect((x),1)

typedef         double     Real64;
typedef unsigned char Bit8u;
typedef   signed char Bit8s;
typedef unsigned short Bit16u;
typedef   signed short Bit16s;
typedef unsigned int Bit32u;
typedef   signed int Bit32s;
typedef unsigned long long Bit64u;
typedef   signed long long Bit64s;
#if SIZEOF_INT_P == 4
  typedef Bit32u Bitu;
  typedef Bit32s Bits;
#else
  typedef Bit64u Bitu;
  typedef Bit64s Bits;
#endif

#endif
