/* Posse DOS runtime: headless replacement for DOSBox src/gui/sdlmain.cpp video/mapper glue.
 * Original DOSBox 0.74-3 GPL-2.0-or-later; this file is a new Posse port layer under the same license.
 * Renders to an in-memory XRGB8888 framebuffer; no window, no SDL. */
#include "dosbox.h"
#include "video.h"
#include "mapper.h"
#include "mouse.h"
#include "setup.h"
#include "control.h"
#include "posse_host.h"
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <vector>

bool mouselocked = false;
bool autofire = false; /* upstream lives in sdl_mapper.cpp; set by [joystick] autofire */
static PosseHostHooks hooks;
static bool exit_req = false;
static std::vector<uint32_t> fb;
static Bitu fb_w = 0, fb_h = 0;
static bool updating = false, started = false;
static uint64_t frames = 0;
static GFX_CallBack_t gfx_cb = 0;

extern "C" void posse_set_hooks(const PosseHostHooks *h) { if (h) hooks = *h; else memset(&hooks, 0, sizeof hooks); }
extern "C" void posse_request_exit(void) { exit_req = true; }
extern "C" int posse_exit_requested(void) { return exit_req ? 1 : 0; }
extern "C" uint64_t posse_frame_count(void) { return frames; }
extern "C" int posse_framebuffer(const uint32_t **px, int *w, int *h, int *pitch) {
  if (updating || fb.empty() || frames == 0) return 0;
  *px = &fb[0]; *w = (int)fb_w; *h = (int)fb_h; *pitch = (int)(fb_w * 4); return 1;
}
extern "C" void posse_frame_size(int *w, int *h) { if (w) *w = (int)fb_w; if (h) *h = (int)fb_h; }

void GFX_Events(void) {
  if (hooks.tick) hooks.tick(hooks.ctx);
  if (exit_req) throw 1; /* caught by catch(int) in the runner, like the upstream killswitch */
}
void GFX_SetPalette(Bitu, Bitu, GFX_PalEntry *) {}
Bitu GFX_GetBestMode(Bitu) { return GFX_CAN_32 | GFX_SCALING; }
Bitu GFX_GetRGB(Bit8u r, Bit8u g, Bit8u b) { return ((Bitu)r << 16) | ((Bitu)g << 8) | (Bitu)b; }
Bitu GFX_SetSize(Bitu w, Bitu h, Bitu, double, double, GFX_CallBack_t cb) {
  if (w == 0 || h == 0 || w > 2048 || h > 2048) return 0;
  if (updating) GFX_EndUpdate(0);
  fb_w = w; fb_h = h; gfx_cb = cb;
  fb.assign((size_t)w * h, 0);
  started = true; /* upstream GFX_SetSize ends with GFX_Start() when the surface is valid */
  return GFX_CAN_32 | GFX_SCALING;
}
void GFX_ResetScreen(void) { if (gfx_cb) gfx_cb(GFX_CallBackReset); }
void GFX_Start(void) { started = true; }
void GFX_Stop(void) { if (updating) GFX_EndUpdate(0); started = false; }
void GFX_SwitchFullScreen(void) {}
bool GFX_StartUpdate(Bit8u *&pixels, Bitu &pitch) {
  if (!started || updating || fb.empty()) return false;
  pixels = (Bit8u *)&fb[0]; pitch = fb_w * 4; updating = true; return true;
}
void GFX_EndUpdate(const Bit16u *) {
  if (!updating) return;
  updating = false; frames++;
  if (hooks.frame) hooks.frame(hooks.ctx, &fb[0], (int)fb_w, (int)fb_h, (int)(fb_w * 4), frames);
}
void GFX_GetSize(int &w, int &h, bool &fs) { w = (int)fb_w; h = (int)fb_h; fs = false; }
void GFX_LosingFocus(void) {}
void GFX_CaptureMouse(void) {}
void GFX_SetTitle(Bit32s, Bits, bool) {}
void GFX_ShowMsg(char const *format, ...) {
  char buf[512]; va_list ap; va_start(ap, format); vsnprintf(buf, sizeof buf, format, ap); va_end(ap);
  if (hooks.log) hooks.log(hooks.ctx, buf); else fprintf(stderr, "%s\n", buf);
}
void Mouse_AutoLock(bool) {}

void MAPPER_AddHandler(MAPPER_Handler *, MapKeys, Bitu, char const * const, char const * const) {}
void MAPPER_Init(void) {}
void MAPPER_StartUp(Section *) {}
void MAPPER_Run(bool) {}
void MAPPER_RunInternal() {}
void MAPPER_LosingFocus(void) {}
void MAPPER_UpdateJoysticks(void) {}

static void HEADLESS_StartUp(Section *) {}
/* Registers the [sdl] section so stock configs parse; values are accepted and ignored. */
void POSSE_Config_Add_Headless() {
  Section_prop *s = control->AddSection_prop("sdl", &HEADLESS_StartUp);
  s->Add_bool("fullscreen", Property::Changeable::Always, false);
  s->Add_string("output", Property::Changeable::Always, "surface");
  s->Add_bool("autolock", Property::Changeable::Always, false);
  s->Add_int("sensitivity", Property::Changeable::Always, 100);
  s->Add_bool("waitonerror", Property::Changeable::Always, false);
  s->Add_bool("usescancodes", Property::Changeable::Always, true);
}
