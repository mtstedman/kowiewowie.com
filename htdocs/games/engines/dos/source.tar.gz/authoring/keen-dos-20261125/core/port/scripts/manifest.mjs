// Posse DOS runtime: writes OUT/build-manifest.json during the build (called by build-native.sh
// after a successful link, before the binary is moved into place). Fails if the source tree changed
// while building, or (N4) if any linked object no longer equals the sha256 build-native.sh recorded
// right after compiling it (OBJ.o.objsha). Each TU entry binds objectSha256 == recorded sha and the
// sha256 of its .deps record. Usage: node manifest.mjs ROOT OUT START_DIGEST TMP_BINARY (config via env).
import { readFileSync, writeFileSync, renameSync, existsSync } from 'node:fs';
import { join, relative } from 'node:path';
import { buildInputs, sha } from './digest.mjs';
const [root, out, startDigest, tmpBin] = process.argv.slice(2);
const die = m => { console.error(m); process.exit(1); };
const end = buildInputs(root);
if (end.inputDigest !== startDigest) die(`build inputs changed during build: ${startDigest} -> ${end.inputDigest}`);
const e = process.env;
const bad = [];
const tus = readFileSync(join(out, 'obj/tus.txt'), 'utf8').split('\n').filter(Boolean).map(l => {
  const [source, object] = l.split('\t');
  const actual = sha(readFileSync(object));
  const rec = existsSync(object + '.objsha') ? readFileSync(object + '.objsha', 'utf8').trim() : null;
  if (!/^[0-9a-f]{64}$/.test(rec || '') || rec !== actual) bad.push(`${source}: object ${actual} recorded ${rec}`);
  return { source, object: relative(out, object), objectSha256: actual, compileRecordSha256: rec,
    depsSha256: sha(readFileSync(object + '.deps')) };
});
if (bad.length) die(`objects differ from compile-time records (N4); refusing manifest:\n${bad.join('\n')}`);
const objectSetDigest = sha(tus.map(t => `${t.source} ${t.objectSha256}`).join('\n'));
const bin = readFileSync(tmpBin);
const m = { format: 'posse-dos-build-manifest/1', builtAt: new Date().toISOString(), target: 'native',
  inputs: { files: end.files, inputDigest: end.inputDigest },
  compiler: { command: e.CXX, resolved: e.CXX_REAL, sha256: e.CXX_SHA, version: e.CXX_VERSION, cc1plus: e.CC1PLUS || null, cc1plusSha256: e.CC1PLUS_SHA || null },
  cxxflags: e.CXXFLAGS, ldflags: e.LDFLAGS, includeDirs: ['core/port/include', 'core/dosbox/include', '<directory of each translation unit>'],
  linkCommand: e.LINK_DESC,
  objectIntegrity: { scheme: 'sha256 recorded by build-native.sh immediately after compiling each object; re-verified before link and here after link',
    verifiedObjects: tus.length, objectSetDigest },
  translationUnits: tus,
  output: { name: 'posse-dosbox', bytes: bin.length, sha256: sha(bin) } };
writeFileSync(join(out, 'build-manifest.json.tmp'), JSON.stringify(m, null, 2) + '\n');
renameSync(join(out, 'build-manifest.json.tmp'), join(out, 'build-manifest.json'));
