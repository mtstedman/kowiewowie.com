// Posse DOS runtime: content digest of every browser build input: the upstream tree, the shared port layer
// (core/port/include, core/port/src, core/port/sources.txt) and core/web build/entry sources (not the UI).
import { readFileSync } from 'node:fs';
import { join, relative, sep, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { sha, walk } from '../port/scripts/digest.mjs';
export const WEB_BUILD_FILES = Object.freeze(['build-web.sh', 'web-digest.mjs', 'web-manifest.mjs', 'web_main.cpp', 'web_time.cpp']);
export function webBuildInputs(root) {
  const rel = p => relative(root, p).split(sep).join('/');
  const files = [...walk(join(root, 'core/dosbox')), ...walk(join(root, 'core/port/include')), ...walk(join(root, 'core/port/src')),
    join(root, 'core/port/sources.txt'), join(root, 'core/port/scripts/digest.mjs'), ...WEB_BUILD_FILES.map(f => join(root, 'core/web', f))]
    .map(p => [rel(p), sha(readFileSync(p))]).sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
  return { files: files.length, inputDigest: sha(files.map(([r, h]) => r + ' ' + h).join('\n')), list: files };
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) process.stdout.write(webBuildInputs(resolve(process.argv[2] || '.')).inputDigest + '\n');
