// Posse DOS runtime: real-browser smoke for the local launcher (bin/dos-web.mjs + web/*), driven over the
// Chrome DevTools Protocol with the locally installed chrome-headless-shell (no npm dependencies).
// node core/web/browser-smoke.mjs PACKAGE.zip EXE [CHROME]
// Loads the package through the real file input, selects EXE, starts the Wasm worker, waits for emulated
// time to advance, captures the canvas, sends keyboard events and records whether the screen responds.
// Wall-clock paced: this qualifies that the browser path runs and accepts input, not determinism or timing.
import { spawn } from 'node:child_process';
import { mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { join, resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { ROOT } from './node-host.mjs';
const [pkg, exe, chromeArg] = process.argv.slice(2);
const CHROME = chromeArg ?? `${process.env.HOME}/.cache/ms-playwright/chromium_headless_shell-1248/chrome-headless-shell-linux64/chrome-headless-shell`;
const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..*/, 'Z').toLowerCase();
const outDir = join(ROOT, `build/web/browser-smoke-${stamp}`), prof = join(outDir, 'profile');
mkdirSync(prof, { recursive: true });
const sleep = ms => new Promise(r => setTimeout(r, ms));
const procs = [];
const result = { format: 'posse-dos-browser-smoke/1', stamp, package: resolve(pkg), executable: exe, chrome: CHROME, steps: [], shots: [], console: [], ok: false };
const step = (name, v) => { result.steps.push({ name, t: Date.now(), ...v }); };
try {
  const server = spawn(process.execPath, [join(ROOT, 'bin/dos-web.mjs'), '--port', '0'], { cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'] }); procs.push(server);
  const url = await new Promise((res, rej) => { let s = ''; server.stdout.on('data', d => { s += d; try { res(JSON.parse(s.split('\n')[0]).url); } catch {} }); server.on('exit', c => rej(new Error('server exited ' + c))); setTimeout(() => rej(new Error('server start timeout')), 10000); });
  step('server', { url });
  const chrome = spawn(CHROME, ['--headless', '--no-sandbox', '--remote-debugging-port=0', `--user-data-dir=${prof}`, '--autoplay-policy=no-user-gesture-required', '--enable-unsafe-swiftshader', 'about:blank'], { stdio: ['ignore', 'ignore', 'pipe'] }); procs.push(chrome);
  const wsUrl = await new Promise((res, rej) => { let s = ''; chrome.stderr.on('data', d => { s += d; const m = s.match(/DevTools listening on (ws:\/\/\S+)/); if (m) res(m[1]); }); setTimeout(() => rej(new Error('no devtools endpoint: ' + s.slice(-400))), 15000); });
  const ws = new WebSocket(wsUrl); await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
  let id = 0; const pending = new Map();
  ws.onmessage = e => { const m = JSON.parse(e.data);
    if (m.id && pending.has(m.id)) { const p = pending.get(m.id); pending.delete(m.id); m.error ? p.rej(new Error(JSON.stringify(m.error))) : p.res(m.result); }
    else if (m.method === 'Runtime.consoleAPICalled' && result.console.length < 100) result.console.push({ type: m.params.type, text: m.params.args.map(a => a.value ?? a.description).join(' ').slice(0, 300) });
    else if (m.method === 'Runtime.exceptionThrown') result.console.push({ type: 'exception', text: JSON.stringify(m.params.exceptionDetails).slice(0, 500) }); };
  const send = (method, params = {}, sessionId) => new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params, sessionId })); });
  const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
  const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
  const S = (m, p) => send(m, p, sessionId);
  await S('Runtime.enable'); await S('Page.enable');
  const ev = async expr => { const r = await S('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }); if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails).slice(0, 400)); return r.result.value; };
  const waitFor = async (expr, ms, label) => { const t0 = Date.now(); for (;;) { const v = await ev(expr).catch(() => null); if (v) return v; if (Date.now() - t0 > ms) throw new Error(`timeout waiting for ${label}; status=${await ev("document.getElementById('status')?.textContent").catch(() => '?')}`); await sleep(100); } };
  const emulated = () => ev("(document.getElementById('status').textContent.match(/emulated ([\\d.]+) s/)||[])[1]||null").then(v => (v === null ? null : Number(v)));
  const shot = async label => { const v = await ev(`(() => { const c = document.getElementById('screen'); const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let nz = 0; for (let i = 0; i < d.length; i += 4) if (d[i] | d[i + 1] | d[i + 2]) nz++; return { w: c.width, h: c.height, png: c.toDataURL('image/png'), nonBlack: nz, rgba: Array.from(d.subarray(0, 0)) , all: btoa(String.fromCharCode.apply(null, d.subarray(0, 0))) }; })()`);
    const raw = await ev(`(() => { const c = document.getElementById('screen'); const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let h = 2166136261; for (let i = 0; i < d.length; i++) { h ^= d[i]; h = Math.imul(h, 16777619) >>> 0; } return h.toString(16); })()`);
    const png = Buffer.from(v.png.split(',')[1], 'base64'); const file = `${label}.png`; writeFileSync(join(outDir, file), png);
    const s = { label, emulatedS: await emulated(), width: v.w, height: v.h, nonBlackPixels: v.nonBlack, canvasHash: raw, pngSha256: createHash('sha256').update(png).digest('hex'), file };
    result.shots.push(s); return s; };
  await S('Page.navigate', { url });
  await waitFor("document.readyState === 'complete' && document.getElementById('build').textContent.length > 0", 15000, 'launcher ready');
  step('page', { crossOriginIsolated: await ev('crossOriginIsolated'), build: await ev("document.getElementById('build').textContent") });
  const { root } = await S('DOM.getDocument');
  const { nodeId } = await S('DOM.querySelector', { nodeId: root.nodeId, selector: '#file' });
  await S('DOM.setFileInputFiles', { nodeId, files: [resolve(pkg)] });
  await waitFor("document.getElementById('exe').options.length > 0", 15000, 'package inspected');
  step('loaded', { status: await ev("document.getElementById('status').textContent"), options: await ev("[...document.getElementById('exe').options].map(o => o.value)") });
  if (await ev("document.getElementById('start').disabled")) {
    await ev(`(() => { const s = document.getElementById('exe'); s.value = ${JSON.stringify(exe)}; s.dispatchEvent(new Event('change')); return true; })()`);
    await waitFor("!document.getElementById('start').disabled", 15000, 'executable selected');
  }
  step('selected', { status: await ev("document.getElementById('status').textContent") });
  const wall0 = Date.now();
  await ev("document.getElementById('start').click(), true");
  await waitFor("/emulated/.test(document.getElementById('status').textContent)", 20000, 'machine running');
  step('running', { status: await ev("document.getElementById('status').textContent") });
  await waitFor("Number((document.getElementById('status').textContent.match(/emulated ([\\d.]+) s/)||[])[1]) >= 10", 40000, 'emulated 10 s');
  const e10 = await emulated(); step('pace', { emulatedS: e10, wallS: (Date.now() - wall0) / 1000 });
  const a = await shot('t10-before-keys');
  await ev("document.getElementById('screen').focus(), true");
  const key = async (code, key, vk) => { await S('Input.dispatchKeyEvent', { type: 'keyDown', code, key, windowsVirtualKeyCode: vk }); await sleep(150); await S('Input.dispatchKeyEvent', { type: 'keyUp', code, key, windowsVirtualKeyCode: vk }); };
  await key('Space', ' ', 32); await sleep(2500);
  const b = await shot('after-space');
  await key('Enter', 'Enter', 13); await sleep(2500);
  const c = await shot('after-enter');
  await key('Escape', 'Escape', 27); await sleep(2500);
  const d = await shot('after-esc');
  step('log', { appLog: (await ev("document.getElementById('log').textContent")).slice(0, 1500), status: await ev("document.getElementById('status').textContent") });
  await ev("document.getElementById('stop').click(), true");
  await waitFor("/Stopped/.test(document.getElementById('status').textContent)", 10000, 'stop');
  step('stopped', { status: await ev("document.getElementById('status').textContent") });
  const hashes = new Set([a, b, c, d].map(s => s.canvasHash));
  result.checks = { crossOriginIsolated: result.steps.find(s => s.name === 'page').crossOriginIsolated === true, advanced: e10 >= 10,
    nonBlank: a.nonBlackPixels > 0, screenChangedAfterKeys: hashes.size > 1, distinctScreens: hashes.size, noExceptions: !result.console.some(x => x.type === 'exception' || x.type === 'error') };
  result.ok = Object.values(result.checks).every(v => v === true || typeof v === 'number');
} catch (e) { result.error = String(e.message || e); }
finally { for (const p of procs) try { p.kill('SIGKILL'); } catch {} await sleep(300); rmSync(prof, { recursive: true, force: true }); }
writeFileSync(join(outDir, 'result.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ ok: result.ok, error: result.error, checks: result.checks, outDir, steps: result.steps.map(s => ({ n: s.name, ...Object.fromEntries(Object.entries(s).filter(([k]) => !['name', 't', 'appLog'].includes(k))) })), shots: result.shots.map(({ label, emulatedS, width, height, nonBlackPixels, canvasHash }) => ({ label, emulatedS, width, height, nonBlackPixels, canvasHash })), console: result.console.slice(0, 10) }));
process.exit(result.ok ? 0 : 1);
