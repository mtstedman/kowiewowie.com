#!/usr/bin/env bash
# Posse DOS runtime: browser/Wasm build of the same DOSBox 0.74-3 machine sources + shared port layer.
# Usage: core/web/build-web.sh [OUTDIR]   (default build/web). Compiles inside the pinned local image
# emscripten/emsdk:4.0.22 (project mounted at its own path; writes only under OUTDIR).
# Browser-specific inputs: core/web/web_main.cpp (worker entry) and core/web/web_time.cpp (virtual calendar).
# core/port/src/posse_main.cpp and posse_time.cpp are native-only and are not compiled here.
# Invalidation mirrors build-native.sh: compile stamp (image id, emcc version, cxxflags, includes) + per-TU
# dependency shas; the link always reruns, so LDFLAGS changes never reuse a stale output.
# ENVIRONMENT=worker,node: the same artifact runs in a browser Web Worker and in node worker_threads (tests).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="${1:-$ROOT/build/web}"; mkdir -p "$OUT/obj"; OUT="$(cd "$OUT" && pwd)"
case "$OUT" in "$ROOT"/*) ;; *) echo "OUTDIR must be inside the project"; exit 1;; esac
IMAGE="${EMSDK_IMAGE:-emscripten/emsdk:4.0.22}"
IMAGE_ID="$(docker image inspect --format '{{.Id}}' "$IMAGE")" || { echo "image $IMAGE not present locally"; exit 1; }
CXXFLAGS="-O2 -g0 -std=gnu++11 -fno-strict-aliasing -fexceptions -Wno-deprecated -Wno-narrowing -w"
LDFLAGS="-O2 -fexceptions -sENVIRONMENT=worker,node -sMODULARIZE=1 -sEXPORT_NAME=PosseDosbox -sALLOW_MEMORY_GROWTH=1 -sINITIAL_MEMORY=67108864 -sSTACK_SIZE=2097152 -sFORCE_FILESYSTEM=1 -sEXPORTED_FUNCTIONS=_posse_web_start,_malloc,_free -sEXPORTED_RUNTIME_METHODS=FS,ccall,UTF8ToString,HEAPU8,HEAP16 -sEXIT_RUNTIME=0"
INC="-I$ROOT/core/port/include -I$ROOT/core/dosbox/include"
SRCS=()
while read -r s; do [[ -z "$s" || "$s" == \#* ]] && continue; SRCS+=("core/dosbox/src/$s"); done < "$ROOT/core/port/sources.txt"
SRCS+=(core/port/src/sdl_shim.cpp core/port/src/headless_gfx.cpp core/web/web_main.cpp core/web/web_time.cpp)
printf '%s\n' "${SRCS[@]}" > "$OUT/obj/srcs.txt"
START_DIGEST="$(node "$ROOT/core/web/web-digest.mjs" "$ROOT")"
rm -f "$OUT/build-manifest.json" "$OUT/posse-dosbox.js.tmp"
cat > "$OUT/obj/inner.sh" <<INNER
set -euo pipefail
cd "$ROOT"
EMV="\$(emcc --version | head -1)"
CONFIG="\$(printf 'image=%s\nemcc=%s\ncxxflags=%s\ninc=%s\n' "$IMAGE_ID" "\$EMV" "$CXXFLAGS" "$INC")"
if [[ ! -f "$OUT/obj/config.stamp" || "\$(cat "$OUT/obj/config.stamp")" != "\$CONFIG" ]]; then
  find "$OUT/obj" -name '*.o*' -delete; printf '%s' "\$CONFIG" > "$OUT/obj/config.stamp"; fi
echo "\$EMV" > "$OUT/obj/emcc-version.txt"
: > "$OUT/obj/compiled.log"
compile() { local s="\$1" o; o="$OUT/obj/\$(echo "\$1" | tr '/' '_').o"
  if [[ -f "\$o" && -s "\$o.deps" ]] && sha256sum --status -c "\$o.deps" 2>/dev/null; then return 0; fi
  rm -f "\$o" "\$o.deps" "\$o.d"; echo "compile \$s" >> "$OUT/obj/compiled.log"
  em++ $CXXFLAGS $INC -I"\$(dirname "$ROOT/\$s")" -MMD -MF "\$o.d" -c "$ROOT/\$s" -o "\$o" 2>"\$o.err" || { rm -f "\$o"; echo "FAIL \$s"; return 1; }
  sed -e 's/^[^:]*://' -e 's/\\\\\$//' "\$o.d" | tr ' ' '\n' | grep -v '^\$' | sort -u | xargs sha256sum > "\$o.deps"; }
export -f compile
fail=0; xargs -P "\$(nproc)" -I{} bash -c 'compile "\$@"' _ {} < "$OUT/obj/srcs.txt" || fail=1
cat "$OUT"/obj/*.err > "$OUT/errors.log" 2>/dev/null || true
[[ \$fail -eq 0 ]] || { echo "compile failures; see $OUT/errors.log"; exit 1; }
OBJS=(); while read -r s; do OBJS+=("$OUT/obj/\$(echo "\$s" | tr '/' '_').o"); done < "$OUT/obj/srcs.txt"
mapfile -t OBJS < <(printf '%s\n' "\${OBJS[@]}" | LC_ALL=C sort)
em++ -o "$OUT/stage/posse-dosbox.js" "\${OBJS[@]}" $LDFLAGS 2>"$OUT/link.log" || { echo "link failed; see $OUT/link.log"; exit 1; }
INNER
rm -rf "$OUT/stage"; mkdir -p "$OUT/stage"
docker run --rm -v "$ROOT:$ROOT" -e HOME=/tmp "$IMAGE" bash "$OUT/obj/inner.sh" || { rc=$?; docker run --rm -v "$ROOT:$ROOT" "$IMAGE" chown -R "$(id -u):$(id -g)" "$OUT"; exit $rc; }
docker run --rm -v "$ROOT:$ROOT" "$IMAGE" chown -R "$(id -u):$(id -g)" "$OUT"
export IMAGE IMAGE_ID CXXFLAGS LDFLAGS EMCC_VERSION="$(cat "$OUT/obj/emcc-version.txt")"
node "$ROOT/core/web/web-manifest.mjs" "$ROOT" "$OUT" "$START_DIGEST"
mv -f "$OUT/stage/posse-dosbox.js" "$OUT/stage/posse-dosbox.wasm" "$OUT/"
echo "built $OUT/posse-dosbox.{js,wasm} ($(wc -l < "$OUT/obj/compiled.log") TUs compiled)"
