/* Posse DOS runtime: minimal SDL 1.2 compatibility shim for the headless DOSBox build.
 * Only the subset referenced by retained (non-gui) DOSBox sources. Timing, audio and
 * CD/mutex entry points are implemented in core/port/src/sdl_shim.cpp and are driven
 * by the host frontend (no real SDL, no window, no threads). */
#ifndef POSSE_SDL_SHIM_H
#define POSSE_SDL_SHIM_H
#include <stdint.h>
#include <stddef.h>
#ifdef __cplusplus
extern "C" {
#endif
typedef uint8_t Uint8; typedef int8_t Sint8;
typedef uint16_t Uint16; typedef int16_t Sint16;
typedef uint32_t Uint32; typedef int32_t Sint32;
typedef uint64_t Uint64; typedef int64_t Sint64;
#define SDLCALL
#define SDL_MAJOR_VERSION 1
#define SDL_MINOR_VERSION 2
#define SDL_PATCHLEVEL 15
#define SDL_VERSIONNUM(X,Y,Z) ((X)*1000 + (Y)*100 + (Z))
#define SDL_COMPILEDVERSION SDL_VERSIONNUM(SDL_MAJOR_VERSION,SDL_MINOR_VERSION,SDL_PATCHLEVEL)
#define SDL_VERSION_ATLEAST(X,Y,Z) (SDL_COMPILEDVERSION >= SDL_VERSIONNUM(X,Y,Z))

Uint32 SDL_GetTicks(void);
void SDL_Delay(Uint32 ms);
const char *SDL_GetError(void);

#define AUDIO_S16LSB 0x8010
#define AUDIO_S16SYS AUDIO_S16LSB
typedef struct SDL_AudioSpec {
  int freq; Uint16 format; Uint8 channels; Uint8 silence;
  Uint16 samples; Uint16 padding; Uint32 size;
  void (SDLCALL *callback)(void *userdata, Uint8 *stream, int len);
  void *userdata;
} SDL_AudioSpec;
int SDL_OpenAudio(SDL_AudioSpec *desired, SDL_AudioSpec *obtained);
void SDL_PauseAudio(int pause_on);
void SDL_LockAudio(void);
void SDL_UnlockAudio(void);
void SDL_CloseAudio(void);

typedef struct SDL_mutex SDL_mutex;
SDL_mutex *SDL_CreateMutex(void);
void SDL_DestroyMutex(SDL_mutex *m);
int SDL_mutexP(SDL_mutex *m);
int SDL_mutexV(SDL_mutex *m);
#define SDL_LockMutex(m) SDL_mutexP(m)
#define SDL_UnlockMutex(m) SDL_mutexV(m)

/* CD-ROM: no physical drives are ever exposed by this runtime. */
#define SDL_MAX_TRACKS 99
#define SDL_AUDIO_TRACK 0x00
#define SDL_DATA_TRACK 0x04
typedef enum { CD_TRAYEMPTY, CD_STOPPED, CD_PLAYING, CD_PAUSED, CD_ERROR = -1 } CDstatus;
#define CD_INDRIVE(status) ((int)(status) > 0)
#define CD_FPS 75
#define FRAMES_TO_MSF(f, M,S,F) { int value = f; *(F) = value%CD_FPS; value /= CD_FPS; *(S) = value%60; value /= 60; *(M) = value; }
#define MSF_TO_FRAMES(M, S, F) ((M)*60*CD_FPS+(S)*CD_FPS+(F))
typedef struct SDL_CDtrack { Uint8 id; Uint8 type; Uint16 unused; Uint32 length; Uint32 offset; } SDL_CDtrack;
typedef struct SDL_CD { int id; CDstatus status; int numtracks; int cur_track; int cur_frame; SDL_CDtrack track[SDL_MAX_TRACKS+1]; } SDL_CD;
int SDL_CDNumDrives(void);
const char *SDL_CDName(int drive);
SDL_CD *SDL_CDOpen(int drive);
CDstatus SDL_CDStatus(SDL_CD *cdrom);
int SDL_CDPlayTracks(SDL_CD *cdrom, int start_track, int start_frame, int ntracks, int nframes);
int SDL_CDPlay(SDL_CD *cdrom, int start, int length);
int SDL_CDPause(SDL_CD *cdrom);
int SDL_CDResume(SDL_CD *cdrom);
int SDL_CDStop(SDL_CD *cdrom);
int SDL_CDEject(SDL_CD *cdrom);
void SDL_CDClose(SDL_CD *cdrom);
#ifdef __cplusplus
}
#endif
#endif
