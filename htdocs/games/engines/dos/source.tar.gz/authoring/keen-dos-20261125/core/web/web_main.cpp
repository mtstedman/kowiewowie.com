/* Posse DOS runtime: browser (dedicated Web Worker) frontend for the DOSBox 0.74-3 machine.
 * New Posse port code, GPL-2.0-or-later (links DOSBox). Browser counterpart of core/port/src/posse_main.cpp.
 * The machine sources and the shared port layer (core/port/src/sdl_shim.cpp, headless_gfx.cpp) are the same
 * files the native build compiles; only this entry point and web_time.cpp are browser-specific.
 * The machine loop blocks the worker. Worker -> page: postMessage {type:'frame'|'audio'|'clock'|'log'|'exit'}
 * ('clock' every 100 emulated ms).
 * Frames are XRGB8888 rows (pitch bytes); audio is S16 stereo at the mixer rate.
 * Page -> worker: self.posseCtl, an Int32Array over a SharedArrayBuffer:
 *   [0] key ring head (page writes), [1] key ring tail (worker writes), [2] state 0 run/1 pause/2 stop,
 *   [3] speed percent, [4] wake word, [16..271] ring entries (KBD_KEYS * 2 + down).
 * Clock: the same virtual emulated-ms clock as native, paced to performance.now() with Atomics.wait.
 * Interactive keyboard timing is wall-clock driven, so browser sessions are not reproducible evidence. */
#include "dosbox.h"
#include "control.h"
#include "keyboard.h"
#include "mapper.h"
#include "posse_host.h"
#include <emscripten.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string>
#include <vector>

void POSSE_Config_Add_Headless();

EM_JS(void, pw_frame, (const uint32_t *px, int w, int h, int pitch, uint32_t ms, double n), {
  const bytes = HEAPU8.slice(px, px + pitch * h);
  postMessage({ type: 'frame', w: w, h: h, pitch: pitch, ms: ms, n: n, data: bytes.buffer }, [bytes.buffer]);
});
EM_JS(void, pw_audio, (const int16_t *pcm, int frames, int rate), {
  const s = HEAP16.slice(pcm >> 1, (pcm >> 1) + frames * 2);
  postMessage({ type: 'audio', rate: rate, data: s.buffer }, [s.buffer]);
});
EM_JS(void, pw_clock, (uint32_t ms), { postMessage({ type: 'clock', ms: ms }); });
EM_JS(void, pw_log, (const char *m), { postMessage({ type: 'log', text: UTF8ToString(m) }); });
EM_JS(void, pw_exit, (const char *reason, const char *error, uint32_t ms), {
  postMessage({ type: 'exit', reason: UTF8ToString(reason), error: UTF8ToString(error), ms: ms });
});
EM_JS(int, pw_poll_key, (void), {
  const c = self.posseCtl; if (!c) return -1;
  const head = Atomics.load(c, 0), tail = Atomics.load(c, 1);
  if (head === tail) return -1;
  const v = Atomics.load(c, 16 + (tail & 255));
  Atomics.store(c, 1, (tail + 1) | 0);
  return v;
});
EM_JS(int, pw_pace, (uint32_t ms), {
  const c = self.posseCtl; if (!c) return 0;
  if (self.posseT0 === undefined) { self.posseT0 = performance.now(); self.posseMs0 = ms; }
  for (;;) {
    const st = Atomics.load(c, 2);
    if (st === 2) return 2;
    if (st === 1) { Atomics.wait(c, 4, Atomics.load(c, 4), 50); self.posseT0 = performance.now(); self.posseMs0 = ms; continue; }
    const speed = Math.max(10, Math.min(1000, Atomics.load(c, 3) || 100));
    const d = self.posseT0 + (ms - self.posseMs0) * 100 / speed - performance.now();
    if (d > 1) { Atomics.wait(c, 4, Atomics.load(c, 4), Math.min(d, 50)); continue; }
    if (d < -250) { self.posseT0 = performance.now(); self.posseMs0 = ms; }
    return 0;
  }
});

static uint32_t last_ms = 0xffffffffu;
static int rate = 0;
static double acc = 0;
static std::vector<int16_t> abuf;
static void on_frame(void *, const uint32_t *px, int w, int h, int pitch, uint64_t n) {
  pw_frame(px, w, h, pitch, posse_clock_now(), (double)n);
}
static void on_tick(void *) {
  uint32_t now = posse_clock_now();
  if (now == last_ms) return; /* once per emulated ms, like the native runner */
  last_ms = now;
  int k;
  while ((k = pw_poll_key()) >= 0) { int code = k >> 1; if (code > KBD_NONE && code < KBD_LAST) KEYBOARD_AddKey((KBD_KEYS)code, (k & 1) != 0); }
  if (!rate) rate = posse_audio_rate();
  if (rate) {
    acc += rate / 1000.0; int n = (int)acc;
    if (n > 0) { acc -= n; size_t o = abuf.size(); abuf.resize(o + (size_t)n * 2); if (posse_audio_pull(&abuf[o], n) != n) abuf.resize(o); }
    if (abuf.size() >= (size_t)(rate / 25) * 2) { pw_audio(&abuf[0], (int)(abuf.size() / 2), rate); abuf.clear(); }
  }
  if (now % 100 == 0) pw_clock(now);
  if (pw_pace(now) == 2) posse_request_exit();
}
static void on_log(void *, const char *m) { pw_log(m); }

/* Blocks until the DOS shell exits or the page sets state 2. conf is a host-generated DOSBox config in MEMFS. */
extern "C" EMSCRIPTEN_KEEPALIVE int posse_web_start(const char *conf) {
  setenv("TZ", "UTC0", 1); tzset();
  posse_clock_set_mode(0);
  PosseHostHooks hk = { on_frame, on_tick, on_log, 0 }; posse_set_hooks(&hk);
  std::string reason = "program-exit", error;
  const char *cargv[] = { "posse-dosbox" };
  int code = 0;
  try {
    CommandLine com_line(1, cargv);
    Config myconf(&com_line); control = &myconf;
    POSSE_Config_Add_Headless();
    DOSBOX_Init();
    if (!control->ParseConfigFile(conf)) { reason = "config-error"; code = 2; }
    else { control->Init(); MAPPER_Init(); control->StartUp(); }
  } catch (char *e) { reason = "machine-error"; error = e; code = 1; }
  catch (int) { reason = posse_exit_requested() ? "stopped" : "killswitch"; }
  if (!abuf.empty() && rate) { pw_audio(&abuf[0], (int)(abuf.size() / 2), rate); abuf.clear(); }
  pw_exit(reason.c_str(), error.c_str(), posse_clock_now());
  return code;
}
