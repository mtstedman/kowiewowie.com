// Posse DOS runtime: node worker_threads host for the browser/Wasm build (tests and parity checks).
// Mirrors the browser worker: same posse-dosbox.js/.wasm artifact, same message protocol, same MEMFS drive.
import { parentPort, workerData } from 'node:worker_threads';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname } from 'node:path';
globalThis.self = globalThis;
globalThis.postMessage = (m, t) => parentPort.postMessage(m, t);
self.posseCtl = new Int32Array(workerData.ctl);
const mod = { exports: {} };
new Function('module', 'exports', 'require', '__dirname', '__filename', readFileSync(workerData.js, 'utf8'))(
  mod, mod.exports, createRequire(workerData.js), dirname(workerData.js), workerData.js);
const M = await mod.exports({ wasmBinary: readFileSync(workerData.wasm),
  print: t => postMessage({ type: 'log', text: t }), printErr: t => postMessage({ type: 'log', text: t }) });
const mk = p => { try { M.FS.mkdir(p); } catch {} };
mk('/C');
for (const [dosPath, bytes] of workerData.drive) {
  const parts = dosPath.split('\\'); let d = '/C';
  for (const c of parts.slice(0, -1)) { d += '/' + c; mk(d); }
  const f = d + '/' + parts.at(-1); M.FS.writeFile(f, bytes); M.FS.utime(f, workerData.mtimeMs, workerData.mtimeMs);
}
M.FS.writeFile('/run.conf', workerData.conf);
M.FS.chdir('/'); // relative mount 'C' resolves to /C, matching the native instance-relative mount
const code = M.ccall('posse_web_start', 'number', ['string'], ['/run.conf']);
postMessage({ type: 'returned', code });
