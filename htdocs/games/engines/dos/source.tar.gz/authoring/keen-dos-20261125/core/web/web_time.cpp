/* Posse DOS runtime: deterministic calendar time for the browser build. New Posse port code, GPL-2.0-or-later.
 * Browser counterpart of core/port/src/posse_time.cpp (which uses a Linux syscall for wall mode). The web build
 * has only the virtual clock: 1992-01-01T00:00:00Z + elapsed emulated seconds. Uses the libc time_t
 * (64-bit in emscripten 4.x), so this definition matches the libc prototype exactly. */
#include <time.h>
#include "posse_host.h"
extern "C" time_t time(time_t *t) {
  time_t v = (time_t)POSSE_VIRTUAL_EPOCH + (time_t)(posse_clock_now() / 1000u);
  if (t) *t = v;
  return v;
}
