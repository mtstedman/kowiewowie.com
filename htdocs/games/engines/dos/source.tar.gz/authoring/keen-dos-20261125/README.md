# Posse DOS runtime

A reusable, source-maintained DOS execution package for Posse, modeled on the completed NES/SNES projects:
package intake/inspection, a source-built headless machine core, `run`/`validate` operations with native
evidence units, a local browser launcher built from the same sources, and an offline registration plan that
Root reviews and applies. Nothing here publishes anything.

## What is (and is not) in this tree
- **Original game bytes stay immutable and outside the code.** A DOS package (e.g. `inputs/commander-keen-1.zip`,
  sha256 `e6c304ca...`) is read in memory; each run copies members into a fresh per-run drive. The ZIP is never
  modified, extracted into the source tree or committed (`inputs/` is git-ignored).
- **The machine is DOSBox 0.74-3, built from source.** `core/dosbox/` is the unmodified upstream source
  (GPL-2.0-or-later, `core/dosbox/COPYING`; archive URL and per-file hashes in `core/upstream.json`).
  `core/port/` is the Posse headless port layer; `core/web/` is the Wasm entry. This is an emulator engine,
  **not** recovered or decompiled game source.
- `tools/dos/` (MZ/LZEXE unpacker) is optional analysis only; the runtime does not depend on it.

## Layout
| Path | Role |
|---|---|
| `lib/` | Generic package inspection (ZIP, 8.3 mapping, MZ/COM, packers), runner, operations |
| `bin/dos.mjs` | CLI: `inspect`, `run`, `validate` |
| `bin/dos-web.mjs` | Local browser launcher server |
| `core/` | Upstream DOSBox source, port layer, native and Wasm build scripts |
| `web/` | Launcher UI and worker |
| `agents/`, `agent-config/` | Operation tool templates, catalog, registration plan (Root applies) |
| `test/` | `npm test` (Node >= 22) |
| `handoffs/`, `milestones/`, `STATUS.md` | Reviews, evidence pointers, current state |

## Build
```sh
core/port/scripts/build-native.sh        # -> build/native/posse-dosbox + build-manifest.json (host g++)
node core/port/scripts/provenance.mjs    # exit 0 only if binary, manifest and current sources agree
core/web/build-web.sh                    # -> build/web (local image emscripten/emsdk:4.0.22)
npm test
```
Builds are reproducible on the same host/toolchain only; see `handoffs/root-native-n4-candidate-20261125.md`.

## Inspect and select an executable
Packages may hold several programs. This one has `CATALOG.EXE`, `DEALERS.EXE` (COM image), `KEEN1.EXE` and
`SWCBBS.EXE`; the game is **`KEEN1.EXE`**. Nothing is chosen implicitly.
```sh
node bin/dos.mjs inspect inputs/commander-keen-1.zip            # members, executables, machine profile
```

## Run and validate (native, deterministic)
```sh
node bin/dos.mjs run inputs/commander-keen-1.zip --exe KEEN1.EXE --run-id keen-a1 \
  --until-ms 8000 --shot-ms 2000,8000 [--input events.json] [--instance-root DIR]
node bin/dos.mjs validate inputs/commander-keen-1.zip --exe KEEN1.EXE --run-id keen-v1 --until-ms 4000
```
Units are native, not wall-clock:
- `--until-ms` and `--shot-ms`: **emulated** milliseconds. The tool schema allows `until_ms` 1..60000 and at
  most 32 shots.
- `--input`: JSON array of `{"ms": <emulated ms>, "key": <name>, "action": "down"|"up"}`.
- Artifacts per run: `result.json`, `out/summary.json`, `out/frames.tsv` (per-frame hash/mode log),
  `out/audio.wav`, PPM screenshots; the summary reports their sha256s and drive-file changes.
- `validate` runs the same request twice (`ID-a`, `ID-b`) and checks determinism, isolation and that the
  package is unchanged.

Runs are write-once evidence: use a fresh `--run-id` for each run; never edit or reuse an instance.

**Candidate mode vs checked runs.** Without a pin, `run`/`validate` are local candidate executions: the
report says `identity.mode: candidate` (manifest consistency only, not authentication). For evidence, pass
the Root-reviewed binary hash (see `handoffs/root-reviewed-native-candidate-20261125.json`):
```sh
  ... --expected-binary-sha256 HEX --pin-source handoffs/root-reviewed-native-candidate-20261125.json
```
Both flags are required together; a mismatch fails the run.

## Local browser launcher
```sh
node bin/dos-web.mjs [--port N]          # default http://127.0.0.1:8642/
```
Choose the ZIP, select `KEEN1.EXE`, Start. Keyboard, video and audio run in the page; timing is real time,
so use the native runner for reproducible evidence. The drive lives in tab memory only.

## Registration
`node agents/register.mjs` prints an offline plan (operation tools `dos-package-inspect`, `dos-core-run`,
`dos-core-validate` and their agents) and contacts nothing. Only Root applies it, after review, with
sha256-pinned anchors, a passing test suite, `provenance.mjs` exit 0 and semantic smoke runs. Registered
runtimes are frozen snapshots; this project never publishes or edits owner registrations itself.

Current state and limits: `STATUS.md`. Licence: DOSBox under GPL-2.0-or-later; game data is the user's own
package and is not distributed here.
