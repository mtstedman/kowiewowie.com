// Posse DOS runtime: launcher page. Loads a package via /api/load (generic inspector), starts the Wasm worker,
// renders XRGB8888 frames to a canvas, schedules S16 stereo audio and forwards keyboard scancodes via a SAB ring.
// Lifecycle: every load and every machine start is tagged; superseded load responses and messages from a replaced
// worker are ignored. A full 256-entry key ring stops the machine with an explicit error instead of dropping input.
'use strict';
const $ = id => document.getElementById(id);
const CODE = { Escape: 'esc', Tab: 'tab', Backspace: 'backspace', Enter: 'enter', Space: 'space', AltLeft: 'leftalt', AltRight: 'rightalt',
  ControlLeft: 'leftctrl', ControlRight: 'rightctrl', ShiftLeft: 'leftshift', ShiftRight: 'rightshift', CapsLock: 'capslock', ScrollLock: 'scrolllock',
  NumLock: 'numlock', Backquote: 'grave', Minus: 'minus', Equal: 'equals', Backslash: 'backslash', BracketLeft: 'leftbracket', BracketRight: 'rightbracket',
  Semicolon: 'semicolon', Quote: 'quote', Period: 'period', Comma: 'comma', Slash: 'slash', IntlBackslash: 'extra_lt_gt', PrintScreen: 'printscreen',
  Pause: 'pause', Insert: 'insert', Home: 'home', PageUp: 'pageup', Delete: 'delete', End: 'end', PageDown: 'pagedown', ArrowLeft: 'left', ArrowUp: 'up',
  ArrowDown: 'down', ArrowRight: 'right', NumpadDivide: 'kpdivide', NumpadMultiply: 'kpmultiply', NumpadSubtract: 'kpminus', NumpadAdd: 'kpplus',
  NumpadEnter: 'kpenter', NumpadDecimal: 'kpperiod' };
function keyName(code) {
  if (/^Key[A-Z]$/.test(code)) return code[3].toLowerCase();
  if (/^Digit[0-9]$/.test(code)) return code[5];
  if (/^F([1-9]|1[0-2])$/.test(code)) return code.toLowerCase();
  if (/^Numpad[0-9]$/.test(code)) return 'kp' + code[6];
  return CODE[code];
}
const RING = 256;
let build, keys, file = null, loaded = null, loadSeq = 0, session = null, worker = null, ctl = null, audio, nextT = 0, pending = null, paused = false;
const down = new Set(), sources = new Set();
const status = t => { $('status').textContent = t; };
const log = t => { const l = $('log'); l.textContent += t + '\n'; if (l.textContent.length > 20000) l.textContent = l.textContent.slice(-15000); };
async function api(url, opts) { const r = await fetch(url, opts); const j = await r.json(); if (!r.ok) throw new Error(j.error || r.status); return j; }
function setLoaded(r) { loaded = r; $('start').disabled = !(r && r.status === 'ready'); }
async function load(exe) {
  const seq = ++loadSeq, f = file, sel = $('exe');
  setLoaded(null); sel.disabled = true; status(exe ? `Loading ${exe}…` : `Inspecting ${f.name}…`);
  const q = new URLSearchParams({ kind: f.kind }); if (f.kind === 'exe') q.set('name', f.name); if (exe) q.set('exe', exe);
  let r;
  try { r = await api('/api/load?' + q, { method: 'POST', body: f.bytes }); }
  catch (e) { if (seq !== loadSeq) return; $('info').textContent = ''; if (exe) sel.disabled = false; else sel.innerHTML = ''; status('Load failed: ' + e.message); return; }
  if (seq !== loadSeq) return; // superseded by a later file or executable selection
  const { drive, conf, ...info } = r; $('info').textContent = JSON.stringify(info, null, 1) + (conf ? '\n--- run.conf ---\n' + conf : '');
  sel.innerHTML = '';
  if (r.status === 'select') sel.append(new Option('-- choose --', ''));
  for (const e of r.executables) { const o = new Option(`${e.dosPath} (${e.format}${e.rejected ? ', rejected' : ''})`, e.dosPath); o.disabled = !!e.rejected; sel.append(o); }
  if (r.candidateIdentity) sel.value = r.candidateIdentity.executable;
  sel.disabled = false; setLoaded(r);
  status(r.status === 'ready' ? `Ready: ${r.candidateIdentity.executable} (${r.candidateIdentity.executableSha256.slice(0, 12)}…)` : 'This package has several executables; choose one.');
}
function signal(c, st) { Atomics.store(c, 2, st); Atomics.add(c, 4, 1); Atomics.notify(c, 4); }
function failSession(s, msg) {
  if (s.failed) return; s.failed = msg; down.clear(); signal(s.ctl, 2);
  status('Stopped: ' + msg); log('error: ' + msg);
}
// Returns true only when the event was queued for the machine. Never overwrites or silently drops an entry.
function pushKey(name, isDown) {
  const s = session, code = keys[name]; if (code === undefined || !s || s.failed) return false;
  const c = s.ctl, head = Atomics.load(c, 0), tail = Atomics.load(c, 1);
  if (((head - tail) | 0) >= RING) { failSession(s, `keyboard queue overflow: ${RING} events pending; ${isDown ? 'press' : 'release'} of ${name} could not be delivered`); return false; }
  Atomics.store(c, 16 + (head & (RING - 1)), code * 2 + (isDown ? 1 : 0)); Atomics.store(c, 0, (head + 1) | 0); return true;
}
function releaseAll() { const ks = [...down]; down.clear(); for (const n of ks) pushKey(n, false); }
function stopWorker() { if (session) { releaseAll(); signal(session.ctl, 2); } }
function draw() {
  if (pending) { const m = pending; pending = null; const c = $('screen');
    if (c.width !== m.w || c.height !== m.h) { c.width = m.w; c.height = m.h; }
    const src = new Uint32Array(m.data, 0, (m.pitch / 4) * m.h), img = new ImageData(m.w, m.h), dst = new Uint32Array(img.data.buffer);
    for (let y = 0; y < m.h; y++) { const s = y * (m.pitch / 4), d = y * m.w;
      for (let x = 0; x < m.w; x++) { const v = src[s + x]; dst[d + x] = 0xff000000 | ((v >>> 16) & 255) | (v & 0xff00) | ((v & 255) << 16); } }
    c.getContext('2d').putImageData(img, 0, 0); }
  requestAnimationFrame(draw);
}
function playAudio(m) {
  if (!audio || $('mute').checked) return;
  const s = new Int16Array(m.data), n = s.length / 2, b = audio.createBuffer(2, n, m.rate), l = b.getChannelData(0), r = b.getChannelData(1);
  for (let i = 0; i < n; i++) { l[i] = s[i * 2] / 32768; r[i] = s[i * 2 + 1] / 32768; }
  const now = audio.currentTime; if (nextT < now + 0.03 || nextT > now + 0.4) nextT = now + 0.06;
  const src = audio.createBufferSource(); src.buffer = b; src.connect(audio.destination); src.onended = () => sources.delete(src);
  sources.add(src); src.start(nextT); nextT += b.duration;
}
function start() {
  if (!loaded || loaded.status !== 'ready') return;
  const prev = session;
  if (prev) { signal(prev.ctl, 2); prev.worker.terminate(); }
  for (const a of sources) try { a.stop(); } catch {} sources.clear();
  down.clear(); pending = null; nextT = 0; paused = false; $('pause').textContent = 'Pause';
  audio ??= new AudioContext(); audio.resume();
  const s = { id: (prev ? prev.id : 0) + 1, identity: loaded.candidateIdentity, ctl: new Int32Array(new SharedArrayBuffer(272 * 4)), failed: null };
  Atomics.store(s.ctl, 3, Number($('speed').value));
  s.worker = new Worker('/worker.js'); session = s; ctl = s.ctl; worker = s.worker;
  s.worker.onmessage = e => { if (session !== s) return; const m = e.data; // ignore anything from a replaced machine
    if (m.type === 'frame') pending = m; else if (m.type === 'audio') playAudio(m);
    else if (m.type === 'clock') { if (!s.failed) status(`Running ${s.identity.executable} · emulated ${(m.ms / 1000).toFixed(1)} s`); }
    else if (m.type === 'log') log(m.text); else if (m.type === 'started') { status('Machine started'); $('screen').focus(); }
    else if (m.type === 'exit') { s.exited = m; down.clear(); $('pause').disabled = $('stop').disabled = true;
      status(s.failed ? `Stopped: ${s.failed} (machine stopped at ${(m.ms / 1000).toFixed(1)} s)` : `Stopped: ${m.reason}${m.error ? ' — ' + m.error : ''} at ${(m.ms / 1000).toFixed(1)} s`); }
    else if (m.type === 'error') { status('Error: ' + m.message); log('error: ' + m.message); $('pause').disabled = $('stop').disabled = true; } };
  const drive = loaded.drive.map(([p, b64]) => [p, Uint8Array.from(atob(b64), ch => ch.charCodeAt(0))]);
  s.worker.postMessage({ type: 'start', ctl: s.ctl.buffer, build, conf: loaded.conf, drive, mtimeMs: loaded.mtimeMs });
  $('pause').disabled = $('stop').disabled = false;
}
addEventListener('DOMContentLoaded', async () => {
  if (!crossOriginIsolated) { status('This page must be served by bin/dos-web.mjs (needs cross-origin isolation for SharedArrayBuffer).'); return; }
  [build, keys] = await Promise.all([api('/api/build'), api('/api/keys')]);
  $('build').textContent = `wasm ${build.wasm.slice(0, 12)}… inputs ${build.inputDigest.slice(0, 12)}… ${build.toolchain.image}`;
  $('file').onchange = async () => { const f = $('file').files[0]; if (!f) return;
    const seq = ++loadSeq; setLoaded(null); $('exe').disabled = true;
    const bytes = await f.arrayBuffer(); if (seq !== loadSeq) return;
    file = { bytes, name: f.name, kind: /\.zip$/i.test(f.name) ? 'zip' : 'exe' }; await load(); };
  $('exe').onchange = () => { if ($('exe').value) load($('exe').value); else { ++loadSeq; setLoaded(null); } };
  $('start').onclick = start;
  $('stop').onclick = stopWorker;
  const c = $('screen');
  // Pause and Resume hand keyboard focus back to the screen so gameplay keys reach the machine without another click.
  $('pause').onclick = () => { const s = session; if (!s || s.failed || s.exited) return; paused = !paused; if (paused) releaseAll();
    signal(s.ctl, paused ? 1 : 0); $('pause').textContent = paused ? 'Resume' : 'Pause'; c.focus(); };
  $('speed').onchange = () => { if (ctl) Atomics.store(ctl, 3, Number($('speed').value)); };
  c.addEventListener('keydown', e => { const n = keyName(e.code); if (!n) return; e.preventDefault(); if (paused) return; // not queued while frozen
    if (e.repeat && down.has(n)) return; down.add(n); pushKey(n, true); });
  c.addEventListener('keyup', e => { const n = keyName(e.code); if (!n) return; e.preventDefault(); if (down.delete(n)) pushKey(n, false); });
  c.addEventListener('blur', releaseAll); c.addEventListener('click', () => c.focus());
  requestAnimationFrame(draw);
});
