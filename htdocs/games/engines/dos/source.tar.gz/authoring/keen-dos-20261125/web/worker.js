// Posse DOS runtime: browser Web Worker hosting the source-built Wasm DOSBox machine (core/web/web_main.cpp).
// The artifact is fetched, hashed with SubtleCrypto and compared with the build manifest before instantiation.
const hex = async b => [...new Uint8Array(await crypto.subtle.digest('SHA-256', b))].map(x => x.toString(16).padStart(2, '0')).join('');
onmessage = async e => {
  const m = e.data; if (m.type !== 'start') return;
  try {
    self.posseCtl = new Int32Array(m.ctl);
    const [js, wasm] = await Promise.all(['/web/posse-dosbox.js', '/web/posse-dosbox.wasm'].map(u => fetch(u).then(r => { if (!r.ok) throw new Error(`${u}: HTTP ${r.status}`); return r.arrayBuffer(); })));
    if (await hex(js) !== m.build.js || await hex(wasm) !== m.build.wasm) throw new Error('web artifact does not match its build manifest');
    importScripts(URL.createObjectURL(new Blob([js], { type: 'text/javascript' })));
    const M = await PosseDosbox({ wasmBinary: new Uint8Array(wasm), print: t => postMessage({ type: 'log', text: t }), printErr: t => postMessage({ type: 'log', text: t }) });
    const mk = p => { try { M.FS.mkdir(p); } catch {} };
    mk('/C');
    for (const [dosPath, bytes] of m.drive) {
      const parts = dosPath.split('\\'); let d = '/C';
      for (const c of parts.slice(0, -1)) { d += '/' + c; mk(d); }
      const f = d + '/' + parts[parts.length - 1]; M.FS.writeFile(f, bytes); M.FS.utime(f, m.mtimeMs, m.mtimeMs);
    }
    M.FS.writeFile('/run.conf', m.conf); M.FS.chdir('/');
    postMessage({ type: 'started' });
    const code = M.ccall('posse_web_start', 'number', ['string'], ['/run.conf']);
    postMessage({ type: 'returned', code });
  } catch (err) { postMessage({ type: 'error', message: String((err && err.message) || err) }); }
};
