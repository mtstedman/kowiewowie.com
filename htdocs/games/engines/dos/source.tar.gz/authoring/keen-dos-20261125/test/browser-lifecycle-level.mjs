// Real-browser closed-loop level entry: replays the native probe3 title->map prefix as focused CDP key events timed by
// the page's emulated clock, then holds Right like a player watching the screen and lets go once the canvas matches the
// native frame at the level entrance; presses Ctrl, captures, then Pause/Resume with NO screen click and holds Right.
// Evidence only (wall-clock paced browser); compares with the frozen native probe3 PNGs. node test/browser-lifecycle-level.mjs [WEB_ROOT]
import fs from 'node:fs'; import path from 'node:path'; import { createHash } from 'node:crypto'; import { fileURLToPath } from 'node:url';
import { openBrowser, sleep } from './browser-lifecycle-cdp.mjs'; import { same, ascii, topColors, readPng } from './browser-lifecycle-png.mjs'; import { KEEN as KR } from './fixtures.mjs';
const ROOT = fileURLToPath(new URL('../', import.meta.url)).replace(/\/$/, ''), WEB = path.resolve(process.argv[2] || ROOT);
const KEEN = KR instanceof URL ? fileURLToPath(KR) : String(KR);
const NAT = path.join(ROOT, 'verification/web-candidate-20261125t192958z/out/gameplay-probe3');
const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..*/, 'Z').toLowerCase();
const OUT = path.join(ROOT, `build/lifecycle-20261125/level-${stamp}`); fs.mkdirSync(OUT, { recursive: true });
const sha = b => createHash('sha256').update(b).digest('hex');
const N = { gate: readPng(path.join(NAT, 'game-shot-00035000.png')), level: readPng(path.join(NAT, 'game-shot-00037800.png')) };
const R = { format: 'posse-dos-browser-lifecycle-level/1', stamp, webRoot: WEB, packageSha256Before: sha(fs.readFileSync(KEEN)), events: [], shots: [] };
const b = await openBrowser({ root: WEB, profileDir: path.join(OUT, 'profile') }); R.servedWasm = b.server.wasm;
const { ev, waitFor, click, keyDown, keyUp, setFile } = b; const P = {};
const emuAt = ms => ev(`new Promise(r => { const f = () => window.__ms >= ${ms} ? r(window.__ms) : setTimeout(f, 2); f(); })`);
const key = async (dir, code, ms) => { const at = await emuAt(ms); await (dir === 'down' ? keyDown(code) : keyUp(code)); R.events.push([code, dir, ms, at, await ev('document.activeElement.id')]); };
const grab = async label => { const v = await ev("(() => { const c = $('screen'); const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let s = ''; for (let i = 0; i < d.length; i += 8192) s += String.fromCharCode.apply(null, d.subarray(i, i + 8192)); return { w: c.width, h: c.height, b: btoa(s), png: c.toDataURL('image/png'), ms: window.__ms }; })()");
  const rgba = Buffer.from(v.b, 'base64'), px = Buffer.alloc(v.w * v.h * 3); for (let i = 0, j = 0; i < rgba.length; i += 4, j += 3) { px[j] = rgba[i]; px[j + 1] = rgba[i + 1]; px[j + 2] = rgba[i + 2]; }
  const png = Buffer.from(v.png.split(',')[1], 'base64'); fs.writeFileSync(path.join(OUT, label + '.png'), png); const p = P[label] = { w: v.w, h: v.h, px };
  const s = { label, emuMs: v.ms, w: v.w, h: v.h, pngSha256: sha(png), top: topColors(p), vsNativeGate35000: same(p, N.gate), vsNativeLevel37800: same(p, N.level) }; R.shots.push(s); return s; };
try {
  await b.open(); await setFile(KEEN); await waitFor("$('exe').options.length > 0 && !$('exe').disabled", 20000);
  await ev("(() => { const s = $('exe'); s.value = 'KEEN1.EXE'; s.dispatchEvent(new Event('change')); return true; })()"); await waitFor("!$('start').disabled", 20000);
  await click('start'); await waitFor('session && session.worker', 5000);
  await ev("window.__ms = 0, session.worker.addEventListener('message', e => { if (e.data.type === 'frame' || e.data.type === 'clock') window.__ms = Math.max(window.__ms, e.data.ms); }), true");
  await waitFor('window.__ms > 2000', 30000); await click('screen');
  for (const [c, d, u] of [['Space', 12001, 12201], ['Enter', 15201, 15401], ['Enter', 18401, 18501], ['ArrowDown', 22001, 22301], ['ControlLeft', 23001, 23201]]) { await key('down', c, d); await key('up', c, u); }
  await emuAt(33001); await sleep(30); await grab('a-map-33001');
  await ev(`window.__T = Uint8Array.from(atob(${JSON.stringify(N.gate.px.toString('base64'))}), c => c.charCodeAt(0)), window.__sim = () => { const c = $('screen'); if (c.width !== 320 || c.height !== 200) return 0; const d = c.getContext('2d').getImageData(0, 0, 320, 200).data, T = window.__T; let s = 0; for (let i = 0, j = 0; i < d.length; i += 4, j += 3) if (d[i] === T[j] && d[i + 1] === T[j + 1] && d[i + 2] === T[j + 2]) s++; return s / 64000; }, true`);
  await key('down', 'ArrowRight', 33101);
  const hit = R.hit = await ev("new Promise(r => { let best = 0, bestMs = 0; const f = () => { const s = __sim(); if (s > best) { best = s; bestMs = __ms; } if (s >= 0.985) return r({ s, ms: __ms, best, bestMs }); if (best >= 0.95 && s < best - 0.02) return r({ s, ms: bestMs, best, bestMs, passedPeak: true }); if (__ms > 36500) return r({ s, ms: bestMs, best, bestMs, timeout: true }); setTimeout(f, 3); }; f(); })");
  await grab('b-gate-match');
  const rel = hit.ms + 101; await key('up', 'ArrowRight', rel); await key('down', 'ControlLeft', rel + 100); await key('up', 'ControlLeft', rel + 400);
  await emuAt(rel + 2700); await sleep(30); await grab('c-after-ctrl'); await emuAt(rel + 3500); await sleep(30); await grab('d-after-ctrl-later');
  await click('pause'); await sleep(800); const paused = await ev("({ paused, active: document.activeElement.id, ms: __ms })"); await click('pause');
  const resumed = await ev("({ paused, active: document.activeElement.id, head: Atomics.load(ctl, 0) })");
  await keyDown('ArrowRight'); await sleep(1000); await keyUp('ArrowRight'); await sleep(400);
  R.resume = { paused, resumed, pushed: (await ev('Atomics.load(ctl, 0)')) - resumed.head, ringConsumed: await ev('Atomics.load(ctl, 0) === Atomics.load(ctl, 1)') };
  await grab('e-after-resume-right'); R.resume.changedFrac = +(1 - same(P['d-after-ctrl-later'], P['e-after-resume-right'])).toFixed(3);
  await click('stop'); await waitFor('session.exited', 10000); R.exit = await ev('session.exited.reason');
} catch (e) { R.error = String(e.message || e); } finally { R.console = b.console; await b.close(); }
R.packageSha256After = sha(fs.readFileSync(KEEN)); fs.writeFileSync(path.join(OUT, 'result.json'), JSON.stringify(R, null, 1) + '\n');
for (const l of ['b-gate-match', 'd-after-ctrl-later', 'e-after-resume-right']) if (P[l]) console.log(`### browser ${l}\n${ascii(P[l])}`);
console.log(JSON.stringify({ out: OUT, error: R.error, wasm: R.servedWasm, hit: R.hit, shots: R.shots, resume: R.resume, exit: R.exit, maxLagMs: Math.max(...R.events.map(e => e[3] - e[2])), focus: [...new Set(R.events.map(e => e[4]))], pkgSame: R.packageSha256After === R.packageSha256Before, console: R.console.filter(c => c.type !== 'log').slice(0, 5) }));
