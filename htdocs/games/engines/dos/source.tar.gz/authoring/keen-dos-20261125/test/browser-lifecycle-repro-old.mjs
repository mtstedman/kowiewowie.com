// Behavioural reproduction of launcher lifecycle hazards in any served UI tree (real headless Chrome, fresh port).
// node test/browser-lifecycle-repro-old.mjs WEB_ROOT   (used against the frozen verifier snapshot's old web/app.js)
import fs from 'node:fs'; import path from 'node:path'; import { fileURLToPath } from 'node:url';
import { openBrowser, sleep } from './browser-lifecycle-cdp.mjs'; import { KEEN as KR } from './fixtures.mjs';
const ROOT = fileURLToPath(new URL('../', import.meta.url)).replace(/\/$/, ''), WEB = path.resolve(process.argv[2] || ROOT);
const KEEN = KR instanceof URL ? fileURLToPath(KR) : String(KR), OUT = path.join(ROOT, 'build/lifecycle-20261125'), bad = path.join(OUT, 'not-a-package.zip');
const b = await openBrowser({ root: WEB, profileDir: path.join(OUT, `profile-repro-${process.pid}`) }); const { ev, waitFor, click, setFile } = b;
const R = { format: 'posse-dos-browser-lifecycle-repro/1', webRoot: WEB, at: new Date().toISOString() };
const choose = v => ev(`(() => { const s = $('exe'); s.value = ${JSON.stringify(v)}; s.dispatchEvent(new Event('change')); return true; })()`);
const st = () => ev("({ startDisabled: $('start').disabled, loadedExe: loaded && loaded.candidateIdentity ? loaded.candidateIdentity.executable : null, value: $('exe').value, status: $('status').textContent })");
const emuAtLeast = s => waitFor(`Number(($('status').textContent.match(/emulated ([\\d.]+) s/) || [])[1]) >= ${s}`, 30000, 'emulated ' + s);
try {
  await b.open(); R.wasm = b.server.wasm;
  await ev("(() => { const of = window.fetch.bind(window); window.__hook = null; window.fetch = (u, o) => String(u).startsWith('/api/load') && window.__hook ? window.__hook(String(u), () => of(u, o)) : of(u, o); return true; })()");
  await setFile(KEEN); await waitFor("$('exe').options.length > 1", 20000); const opts = await ev("[...$('exe').options].filter(o => o.value && !o.disabled).map(o => o.value)");
  await choose('KEEN1.EXE'); await waitFor("!$('start').disabled", 20000);
  await setFile(bad); await waitFor("/Load failed/.test($('status').textContent)", 15000); R.afterBadPackage = await st();
  await setFile(KEEN); await waitFor("/choose one/.test($('status').textContent)", 20000);
  const other = opts.find(v => v !== 'KEEN1.EXE'); R.otherChoice = other;
  await ev("window.__hook = (u, go) => /exe=KEEN1/.test(u) ? new Promise(r => setTimeout(r, 1500)).then(go) : go(), true");
  await choose('KEEN1.EXE'); R.duringSlowLoad = await st(); await sleep(50); await choose(other); await sleep(2500); R.afterLaterSelection = { lastUserChoice: other, ...(await st()) };
  await ev('window.__hook = null, true'); await choose('KEEN1.EXE'); await waitFor("loaded.candidateIdentity && loaded.candidateIdentity.executable === 'KEEN1.EXE'", 20000);
  await click('start'); await emuAtLeast(2);
  R.restart = await ev("(() => { down.add('right'); pending = { w: 7, h: 7, pitch: 28, data: new ArrayBuffer(196) }; start(); return { downAfterRestart: [...down], injectedPendingCarried: pending !== null && pending.w === 7 }; })()");
  await emuAtLeast(2); const n0 = b.console.length;
  await setFile(KEEN); await sleep(1700); await sleep(800);
  R.newLoadWhileRunning = { exceptions: b.console.slice(n0).filter(c => c.type === 'exception').length, first: (b.console.slice(n0).find(c => c.type === 'exception') || {}).text?.slice(0, 200) ?? null };
  await click('pause'); await sleep(300);
  R.overflow = await ev("(() => { const p0 = (Atomics.load(ctl, 0) - Atomics.load(ctl, 1)) | 0; let t = 0; for (let i = 0; i < 300; i++) if (pushKey('a', i % 2 === 0)) t++; return { pendingBefore: p0, calls: 300, returnedTrue: t, pendingAfter: (Atomics.load(ctl, 0) - Atomics.load(ctl, 1)) | 0 }; })()");
  R.overflow.silentlyLost = R.overflow.returnedTrue - (R.overflow.pendingAfter - R.overflow.pendingBefore);
  await click('stop');
} catch (e) { R.error = String(e.message || e); } finally { await b.close(); }
const f = path.join(OUT, `repro-${path.basename(path.dirname(WEB)) || 'root'}-${Date.now()}.json`); fs.writeFileSync(f, JSON.stringify(R, null, 1) + '\n'); console.log(f); console.log(JSON.stringify(R));
