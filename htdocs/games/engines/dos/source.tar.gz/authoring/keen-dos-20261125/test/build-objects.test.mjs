// N4 object-content integrity and N3 partial-output cleanup for the native build/entrypoint.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const S = path.join(ROOT, 'core/port/scripts');
const sha = b => createHash('sha256').update(b).digest('hex');
const shaf = p => sha(fs.readFileSync(p));
const BIN = path.join(ROOT, 'build/native/posse-dosbox');
const tmp = p => fs.mkdtempSync(path.join(ROOT, 'build', p));

function fakeBuild(rec) {
  const r = tmp('test-manifest-');
  for (const d of ['core/dosbox', 'core/port/scripts', 'out/obj']) fs.mkdirSync(path.join(r, d), { recursive: true });
  fs.writeFileSync(path.join(r, 'core/dosbox/a.cpp'), 'int a;\n');
  const o = path.join(r, 'out/obj/core_dosbox_a.cpp.o');
  fs.writeFileSync(o, 'OBJECT-BYTES');
  fs.writeFileSync(o + '.deps', 'x  y\n');
  if (rec !== undefined) fs.writeFileSync(o + '.objsha', rec);
  fs.writeFileSync(path.join(r, 'out/obj/tus.txt'), `core/dosbox/a.cpp\t${o}\n`);
  fs.writeFileSync(path.join(r, 'out/posse-dosbox.tmp'), 'BIN');
  const dg = spawnSync(process.execPath, [path.join(S, 'digest.mjs'), r], { encoding: 'utf8' }).stdout.trim();
  const res = spawnSync(process.execPath, [path.join(S, 'manifest.mjs'), r, path.join(r, 'out'), dg, path.join(r, 'out/posse-dosbox.tmp')], { encoding: 'utf8', env: { ...process.env, CXX: 'g++' } });
  const mp = path.join(r, 'out/build-manifest.json');
  const m = fs.existsSync(mp) ? JSON.parse(fs.readFileSync(mp, 'utf8')) : null;
  fs.rmSync(r, { recursive: true, force: true });
  return { res, m, objSha: sha('OBJECT-BYTES') };
}

test('manifest binds compile-time object records', () => {
  const { res, m, objSha } = fakeBuild(sha('OBJECT-BYTES') + '\n');
  assert.equal(res.status, 0, res.stderr);
  const t = m.translationUnits[0];
  assert.equal(t.objectSha256, objSha); assert.equal(t.compileRecordSha256, objSha);
  assert.equal(t.depsSha256, sha('x  y\n'));
  assert.equal(m.objectIntegrity.verifiedObjects, 1);
  assert.equal(m.objectIntegrity.objectSetDigest, sha(`core/dosbox/a.cpp ${objSha}`));
});
for (const [name, rec] of [['substituted object', 'f'.repeat(64)], ['missing record', undefined], ['malformed record', 'not-a-hash']]) {
  test(`manifest refuses ${name} (N4)`, () => {
    const { res, m } = fakeBuild(rec);
    assert.equal(res.status, 1); assert.equal(m, null);
    assert.match(res.stderr, /objects differ from compile-time records/);
  });
}

test('N4 probe: substituted object is rebuilt, never linked with stale flags', { timeout: 600000 }, () => {
  const P = tmp('test-n4-');
  try {
    fs.cpSync(path.join(ROOT, 'core'), path.join(P, 'core'), { recursive: true });
    const build = () => spawnSync('bash', [path.join(P, 'core/port/scripts/build-native.sh')], { encoding: 'utf8' });
    const B = path.join(P, 'build/native'), O = path.join(B, 'obj/core_port_src_posse_time.cpp.o');
    const log = f => fs.readFileSync(path.join(B, 'obj', f), 'utf8').split('\n').filter(Boolean);
    let r = build(); assert.equal(r.status, 0, r.stdout + r.stderr);
    const clean = shaf(path.join(B, 'posse-dosbox')), rec = fs.readFileSync(O + '.objsha', 'utf8').trim();
    assert.equal(shaf(O), rec);
    const live = path.join(ROOT, 'build/native/build-manifest.json');
    if (fs.existsSync(live)) assert.equal(JSON.parse(fs.readFileSync(live, 'utf8')).output.sha256, clean, 'same-host rebuild reproduces live candidate');
    const sub = path.join(P, 'subst.o');
    const c = spawnSync('g++', ['-O0', '-g', '-std=gnu++11', '-w', `-I${P}/core/port/include`, `-I${P}/core/dosbox/include`, '-c', `${P}/core/port/src/posse_time.cpp`, '-o', sub]);
    assert.equal(c.status, 0);
    assert.notEqual(shaf(sub), rec);
    fs.copyFileSync(sub, O);
    r = build(); assert.equal(r.status, 0, r.stdout + r.stderr);
    assert.deepEqual(log('altered.log'), ['altered core/port/src/posse_time.cpp']);
    assert.deepEqual(log('compiled.log'), ['compile core/port/src/posse_time.cpp']);
    assert.equal(shaf(O), rec); assert.equal(shaf(path.join(B, 'posse-dosbox')), clean);
    const m = JSON.parse(fs.readFileSync(path.join(B, 'build-manifest.json'), 'utf8'));
    const t = m.translationUnits.find(x => x.source === 'core/port/src/posse_time.cpp');
    assert.equal(t.objectSha256, rec); assert.equal(m.output.sha256, clean);
    fs.copyFileSync(sub, O); fs.rmSync(O + '.objsha');
    r = build(); assert.equal(r.status, 0);
    assert.deepEqual(log('altered.log'), ['unrecorded core/port/src/posse_time.cpp']);
    assert.equal(shaf(path.join(B, 'posse-dosbox')), clean);
    r = build(); assert.equal(r.status, 0); assert.equal(log('compiled.log').length, 0); assert.equal(log('altered.log').length, 0);
  } finally { fs.rmSync(P, { recursive: true, force: true }); }
});

for (const blocked of ['frames.tsv', 'audio.pcm']) {
  test(`N3: output-open failure on ${blocked} leaves no partial outputs`, { skip: !fs.existsSync(BIN) }, () => {
    const T = tmp('test-n3-');
    try {
      fs.copyFileSync(BIN, path.join(T, 'core')); fs.chmodSync(path.join(T, 'core'), 0o755);
      fs.writeFileSync(path.join(T, 'c.conf'), '[sdl]\n');
      fs.mkdirSync(path.join(T, 'out/' + blocked), { recursive: true });
      const r = spawnSync(path.join(T, 'core'), ['--conf', path.join(T, 'c.conf'), '--until-ms', '100', '--out', path.join(T, 'out')], { encoding: 'utf8', timeout: 60000 });
      assert.equal(r.status, 4, r.stderr); assert.match(r.stderr, /cannot open outputs/);
      assert.deepEqual(fs.readdirSync(path.join(T, 'out')), [blocked]);
      assert.ok(fs.statSync(path.join(T, 'out', blocked)).isDirectory());
    } finally { fs.rmSync(T, { recursive: true, force: true }); }
  });
}

const LIVE_MF = path.join(ROOT, 'build/native/build-manifest.json');
test('provenance verifies object records and refuses a substituted object (N4)', { skip: !fs.existsSync(LIVE_MF) || !fs.existsSync(BIN) }, () => {
  const T = tmp('test-prov-');
  try {
    fs.cpSync(path.join(ROOT, 'build/native'), T, { recursive: true });
    const prov = () => spawnSync(process.execPath, [path.join(S, 'provenance.mjs'), T], { encoding: 'utf8', timeout: 120000 });
    let r = prov(); assert.equal(r.status, 0, r.stderr);
    const p = JSON.parse(r.stdout), m = JSON.parse(fs.readFileSync(path.join(T, 'build-manifest.json'), 'utf8'));
    assert.equal(p.build.objectIntegrity.objectSetDigest, m.objectIntegrity.objectSetDigest);
    assert.equal(p.build.objectIntegrity.objectsPresentAndMatching, m.translationUnits.length);
    const O = path.join(T, 'obj/core_port_src_posse_time.cpp.o');
    fs.appendFileSync(O, Buffer.from([0]));
    r = prov(); assert.equal(r.status, 1); assert.equal(r.stdout, ''); assert.match(r.stderr, /manifest records/);
    fs.copyFileSync(path.join(ROOT, 'build/native/obj/core_port_src_posse_time.cpp.o'), O);
    fs.writeFileSync(O + '.objsha', 'f'.repeat(64) + '\n');
    r = prov(); assert.equal(r.status, 1); assert.match(r.stderr, /compile record/);
    const m2 = { ...m }; delete m2.objectIntegrity; fs.writeFileSync(path.join(T, 'build-manifest.json'), JSON.stringify(m2));
    r = prov(); assert.equal(r.status, 1); assert.match(r.stderr, /no object-integrity records/);
  } finally { fs.rmSync(T, { recursive: true, force: true }); }
});
