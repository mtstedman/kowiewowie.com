// Real-browser gameplay walk: replays the native probe3 key schedule as focused CDP keyboard events timed by the
// page's own emulated clock, captures the canvas and compares it pixel-for-pixel with the native probe3 PNGs.
// Then pauses in place, resumes WITHOUT clicking the screen and holds Right. Evidence only, not qualification.
// node test/browser-lifecycle-gameplay.mjs [WEB_ROOT]
import fs from 'node:fs'; import path from 'node:path'; import { inflateSync } from 'node:zlib'; import { createHash } from 'node:crypto'; import { fileURLToPath } from 'node:url';
import { openBrowser, sleep } from './browser-lifecycle-cdp.mjs';
import { KEEN as KR } from './fixtures.mjs';
const ROOT = fileURLToPath(new URL('../', import.meta.url)).replace(/\/$/, ''), WEB_ROOT = path.resolve(process.argv[2] || ROOT);
const KEEN = KR instanceof URL ? fileURLToPath(KR) : String(KR);
const NAT = path.join(ROOT, 'verification/web-candidate-20261125t192958z/out/gameplay-probe3');
const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..*/, 'Z').toLowerCase();
const OUT = path.join(ROOT, `build/lifecycle-20261125/gameplay-${stamp}`); fs.mkdirSync(OUT, { recursive: true });
const sha = b => createHash('sha256').update(b).digest('hex');
function readPng(f) { const b = fs.readFileSync(f); let o = 8, w, h; const idat = [];
  while (o < b.length) { const n = b.readUInt32BE(o), t = b.toString('ascii', o + 4, o + 8), d = b.subarray(o + 8, o + 8 + n);
    if (t === 'IHDR') { w = d.readUInt32BE(0); h = d.readUInt32BE(4); if (d[8] !== 8 || d[9] !== 2) throw new Error('unexpected png'); } if (t === 'IDAT') idat.push(d); o += 12 + n; }
  const raw = inflateSync(Buffer.concat(idat)), px = Buffer.alloc(w * h * 3);
  for (let y = 0; y < h; y++) { if (raw[y * (w * 3 + 1)] !== 0) throw new Error('filtered png'); raw.copy(px, y * w * 3, y * (w * 3 + 1) + 1, (y + 1) * (w * 3 + 1)); } return { w, h, px }; }
const same = (a, b) => { if (!a || !b || a.w !== b.w || a.h !== b.h) return null; let s = 0; for (let i = 0; i < a.px.length; i += 3) if (a.px[i] === b.px[i] && a.px[i + 1] === b.px[i + 1] && a.px[i + 2] === b.px[i + 2]) s++; return +(s / (a.w * a.h)).toFixed(3); };
function ascii(p, W = 56, H = 16) { const ch = ' .:-=+*#%@'; let s = ''; for (let y = 0; y < H; y++) { for (let x = 0; x < W; x++) { let t = 0, n = 0;
  for (let yy = Math.floor(y * p.h / H); yy < Math.floor((y + 1) * p.h / H); yy++) for (let xx = Math.floor(x * p.w / W); xx < Math.floor((x + 1) * p.w / W); xx++) { const i = (yy * p.w + xx) * 3; t += .3 * p.px[i] + .59 * p.px[i + 1] + .11 * p.px[i + 2]; n++; }
  s += ch[Math.min(9, Math.floor(t / n / 25.6))]; } s += '\n'; } return s; }
const ev2 = (k, d, u) => [{ ms: d, code: k, a: 'down' }, { ms: u, code: k, a: 'up' }];
const SH = [22951, 24001, 33001, 35000, 36600, 37800];
const plan = [...ev2('Space', 12001, 12201), ...ev2('Enter', 15201, 15401), ...ev2('Enter', 18401, 18501), ...ev2('ArrowDown', 22001, 22301), ...ev2('ControlLeft', 23001, 23201),
  ...ev2('ArrowRight', 33101, 35101), ...ev2('ControlLeft', 35201, 35501), ...ev2('ArrowRight', 35601, 36601), ...ev2('AltLeft', 36701, 36901), ...SH.map(ms => ({ ms, shot: true }))].sort((a, b) => a.ms - b.ms);
const R = { format: 'posse-dos-browser-lifecycle-gameplay/1', stamp, webRoot: WEB_ROOT, servedWasm: null, packageSha256Before: sha(fs.readFileSync(KEEN)), events: [], shots: [] };
const b = await openBrowser({ root: WEB_ROOT, profileDir: path.join(OUT, 'profile') }); R.servedWasm = b.server.wasm;
const { ev, waitFor, click, keyDown, keyUp, setFile } = b; const P = {};
const grab = async label => { const v = await ev("(() => { const c = $('screen'); const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let s = ''; for (let i = 0; i < d.length; i += 8192) s += String.fromCharCode.apply(null, d.subarray(i, i + 8192)); return { w: c.width, h: c.height, b: btoa(s), png: c.toDataURL('image/png'), ms: window.__ms }; })()");
  const rgba = Buffer.from(v.b, 'base64'), px = Buffer.alloc(v.w * v.h * 3); for (let i = 0, j = 0; i < rgba.length; i += 4, j += 3) { px[j] = rgba[i]; px[j + 1] = rgba[i + 1]; px[j + 2] = rgba[i + 2]; }
  const png = Buffer.from(v.png.split(',')[1], 'base64'); fs.writeFileSync(path.join(OUT, label + '.png'), png); const p = P[label] = { w: v.w, h: v.h, px };
  const s = { label, emuMs: v.ms, w: v.w, h: v.h, pngSha256: sha(png), colors: new Set(Array.from({ length: v.w * v.h }, (_, i) => px.readUIntBE(i * 3, 3))).size }; R.shots.push(s); return s; };
try {
  await b.open(); await setFile(KEEN); await waitFor("$('exe').options.length > 0 && !$('exe').disabled", 20000);
  await ev("(() => { const s = $('exe'); s.value = 'KEEN1.EXE'; s.dispatchEvent(new Event('change')); return true; })()"); await waitFor("!$('start').disabled", 20000);
  await click('start'); await waitFor('session && session.worker', 5000);
  await ev("window.__ms = 0, session.worker.addEventListener('message', e => { if (e.data.type === 'frame' || e.data.type === 'clock') window.__ms = Math.max(window.__ms, e.data.ms); }), true");
  await waitFor('window.__ms > 2000', 30000); await click('screen');
  for (const e of plan) { const at = await ev(`new Promise(r => { const f = () => window.__ms >= ${e.ms} ? r(window.__ms) : setTimeout(f, 2); f(); })`);
    if (e.shot) { await sleep(30); await grab('b-' + e.ms); continue; }
    await (e.a === 'down' ? keyDown(e.code) : keyUp(e.code)); R.events.push({ ...e, at, active: await ev('document.activeElement.id') }); }
  await sleep(500); const pre = await grab('c-before-pause');
  await click('pause'); await sleep(1000); const paused = await ev("({ paused, active: document.activeElement.id, ms: window.__ms })"); await click('pause');
  const resumed = await ev("({ paused, active: document.activeElement.id, head: Atomics.load(ctl, 0) })");
  await keyDown('ArrowRight'); await sleep(1000); await keyUp('ArrowRight'); await sleep(300);
  R.resume = { paused, resumed, pushedAfterResume: (await ev('Atomics.load(ctl, 0)')) - resumed.head };
  const post = await grab('c-after-resume-right'); R.resume.changedPixelsFrac = +(1 - same(P['c-before-pause'], P['c-after-resume-right'])).toFixed(3);
  await click('stop'); await waitFor('session.exited', 10000); R.exit = await ev('session.exited.reason');
} catch (e) { R.error = String(e.message || e); } finally { R.console = b.console; await b.close(); }
const NM = { map: readPng(path.join(NAT, 'game-shot-00022951.png')), level: readPng(path.join(NAT, 'game-shot-00037800.png')) };
for (const s of R.shots) { const nf = path.join(NAT, `game-shot-${String(s.label.slice(2)).padStart(8, '0')}.png`); const p = P[s.label];
  s.vsNativeSameMs = fs.existsSync(nf) ? same(p, readPng(nf)) : null; s.vsNativeMap22951 = same(p, NM.map); s.vsNativeLevel37800 = same(p, NM.level); }
R.events = R.events.map(e => [e.code, e.a, e.ms, e.at, e.active]); R.packageSha256After = sha(fs.readFileSync(KEEN));
fs.writeFileSync(path.join(OUT, 'result.json'), JSON.stringify(R, null, 1) + '\n');
for (const l of ['b-37800', 'c-after-resume-right']) if (P[l]) console.log(`### browser ${l}\n${ascii(P[l])}`);
console.log('### native 37800\n' + ascii(NM.level));
console.log(JSON.stringify({ out: OUT, error: R.error, servedWasm: R.servedWasm, shots: R.shots, resume: R.resume, exit: R.exit, maxLagMs: Math.max(...R.events.map(e => e[3] - e[2])), focus: [...new Set(R.events.map(e => e[4]))], pkgSame: R.packageSha256After === R.packageSha256Before, console: R.console.filter(c => c.type !== 'log').slice(0, 5) }));
