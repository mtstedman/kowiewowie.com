// Real headless-Chrome lifecycle regressions for web/app.js: focus after Pause/Resume, paused keys, load
// supersession/failure, restart isolation from a replaced worker, and explicit key-ring overflow.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { KEEN as KEEN_REF } from './fixtures.mjs';
import { CHROME, openBrowser, sleep } from './browser-lifecycle-cdp.mjs';
const ROOT = fileURLToPath(new URL('../', import.meta.url)).replace(/\/$/, '');
const KEEN = KEEN_REF instanceof URL ? fileURLToPath(KEEN_REF) : String(KEEN_REF);
const skip = [CHROME, path.join(ROOT, 'build/web/build-manifest.json'), KEEN].some(f => !fs.existsSync(f)) && 'needs chrome-headless-shell, build/web and the original package';
const sha = f => createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const OUT = path.join(ROOT, "build/lifecycle-20261125");
// POSSE_LIFECYCLE_ROOT serves another tree (e.g. the frozen verifier snapshot) to reproduce defects in older UI code.
const WEB_ROOT = path.resolve(process.env.POSSE_LIFECYCLE_ROOT || ROOT);
const SERVED = ['web/app.js', 'web/worker.js', 'web/index.html', 'web/style.css', 'bin/dos-web.mjs', 'lib/web/launcher.mjs', 'build/web/posse-dosbox.js', 'build/web/posse-dosbox.wasm', 'build/web/build-manifest.json'];
test('browser lifecycle (real headless Chrome)', { skip, timeout: 300000 }, async t => {
  fs.mkdirSync(OUT, { recursive: true });
  const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..*/, 'Z').toLowerCase();
  const rec = { format: 'posse-dos-browser-lifecycle/1', stamp, served: Object.fromEntries(SERVED.map(f => [f, sha(path.join(WEB_ROOT, f))])), webRoot: WEB_ROOT, packageSha256Before: sha(KEEN), r: {} };
  const bad = path.join(OUT, 'not-a-package.zip'); fs.writeFileSync(bad, 'this is not a zip archive\n');
  const b = await openBrowser({ root: WEB_ROOT, profileDir: path.join(OUT, `profile-${process.pid}`) }); rec.server = b.server;
  const { ev, waitFor, click, press, keyDown, keyUp, setFile } = b;
  const ring = () => ev("({ head: ctl ? Atomics.load(ctl, 0) : null, tail: ctl ? Atomics.load(ctl, 1) : null, paused, active: document.activeElement && document.activeElement.id, down: [...down] })");
  const emu = () => ev("Number(($('status').textContent.match(/emulated ([\\d.]+) s/) || [])[1] ?? NaN)");
  const choose = v => ev(`(() => { const s = $('exe'); s.value = ${JSON.stringify(v)}; s.dispatchEvent(new Event('change')); return true; })()`);
  const ui = () => ev("({ start: $('start').disabled, sel: $('exe').disabled, value: $('exe').value, loadedNull: loaded === null, exe: loaded && loaded.candidateIdentity ? loaded.candidateIdentity.executable : null, status: $('status').textContent })");
  const ready = exe => waitFor(`loaded && loaded.status === 'ready' && loaded.candidateIdentity.executable === ${JSON.stringify(exe)} && !$('start').disabled`, 20000, 'ready ' + exe);
  try {
    await b.open();
    await ev("(() => { const of = window.fetch.bind(window); window.__hook = null; window.fetch = (u, o) => String(u).startsWith('/api/load') && window.__hook ? window.__hook(String(u), () => of(u, o)) : of(u, o); return true; })()");
    await t.test('loads: failure and in-flight loads disable Start; superseded responses lose', async () => {
      await setFile(KEEN); await waitFor("$('exe').options.length > 0 && !$('exe').disabled", 20000);
      const opts = await ev("[...$('exe').options].filter(o => o.value && !o.disabled).map(o => o.value)"); rec.r.options = opts;
      assert.equal((await ui()).start, true);
      await choose('KEEN1.EXE'); await ready('KEEN1.EXE');
      await setFile(bad); await waitFor("/Load failed/.test($('status').textContent)", 15000); const f1 = rec.r.badPackage = await ui();
      assert.equal(f1.start, true); assert.equal(f1.loadedNull, true);
      await setFile(KEEN); await waitFor("$('exe').options.length > 0 && !$('exe').disabled", 20000); await choose('KEEN1.EXE'); await ready('KEEN1.EXE');
      await ev("window.__hook = (u, go) => /exe=KEEN1/.test(u) ? new Promise(r => setTimeout(r, 1500)).then(go) : go(), true");
      await choose('KEEN1.EXE'); const inflight = rec.r.inflight = await ui(); assert.equal(inflight.start, true); assert.equal(inflight.loadedNull, true);
      const other = opts.find(v => v !== 'KEEN1.EXE'); rec.r.other = other ?? null;
      if (other) { await choose(other); await waitFor("!$('exe').disabled", 20000); await sleep(2300);
        const fin = rec.r.afterStale = await ui(); assert.equal(fin.value, other); assert.notEqual(fin.exe, 'KEEN1.EXE'); assert.doesNotMatch(fin.status, /KEEN1\.EXE/); }
      await ev("window.__hook = () => Promise.resolve(new Response(JSON.stringify({ error: 'injected load failure' }), { status: 400, headers: { 'content-type': 'application/json' } })), true");
      await choose('KEEN1.EXE'); await waitFor("/Load failed/.test($('status').textContent)", 10000); const f2 = rec.r.injectedFailure = await ui();
      assert.equal(f2.start, true); assert.equal(f2.loadedNull, true); assert.equal(f2.sel, false);
      await ev('window.__hook = null, true'); await choose('KEEN1.EXE'); await ready('KEEN1.EXE');
    });
    await t.test('pause/resume keep keyboard focus on the screen; paused keys are not queued; order kept', async () => {
      await click('start'); await waitFor("/emulated/.test($('status').textContent)", 30000); await waitFor("Number(($('status').textContent.match(/emulated ([\\d.]+) s/) || [])[1]) >= 3", 30000);
      assert.equal((await ring()).active, 'screen');
      await click('pause'); await sleep(300); const p0 = await ring(), e0 = await emu();
      await press('ArrowLeft'); await press('Space'); await sleep(800); const p1 = await ring(), e1 = await emu();
      await click('pause'); await sleep(100); const q0 = await ring(); const m0 = await emu(); await sleep(1200); const m1 = await emu();
      const h0 = (await ring()).head; await keyDown('ArrowRight'); await keyDown('ControlLeft'); await sleep(120); await keyUp('ArrowRight'); await keyUp('ControlLeft');
      const q1 = await ring(); const vals = await ev(`Array.from({ length: ${q1.head - h0} }, (_, i) => Atomics.load(ctl, 16 + ((${h0} + i) & 255)))`);
      const K = await ev('({ r: keys.right, c: keys.leftctrl })');
      await waitFor('Atomics.load(ctl, 0) === Atomics.load(ctl, 1)', 3000, 'ring consumed');
      rec.r.pause = { p0, p1, e0, e1, q0, resumeEmuAdvanceS: m1 - m0, vals, audio: await ev('audio && audio.state') };
      assert.equal(p0.paused, true); assert.equal(p0.active, 'screen'); assert.equal(p1.head, p0.head); assert.equal(p1.paused, true); assert.equal(e1, e0);
      assert.equal(q0.paused, false); assert.equal(q0.active, 'screen'); assert.ok(m1 - m0 >= 0.8, `advance ${m1 - m0}`);
      assert.deepEqual(vals, [K.r * 2 + 1, K.c * 2 + 1, K.r * 2, K.c * 2]);
    });
    await t.test('restart clears held keys and pending frame; replaced worker messages are ignored', async () => {
      const rs = rec.r.restart = await ev(`(() => { down.add('right'); pending = { w: 7, h: 7, pitch: 28, data: new ArrayBuffer(196) }; const p = session; start();
        const r = { downAfter: down.size, pendingCleared: pending === null, replaced: session !== p, id: session.id, ringHead: Atomics.load(ctl, 0) };
        p.worker.onmessage({ data: { type: 'clock', ms: 987600 } }); p.worker.onmessage({ data: { type: 'frame', w: 7, h: 7, pitch: 28, data: new ArrayBuffer(196) } });
        p.worker.onmessage({ data: { type: 'exit', reason: 'stale', error: '', ms: 1 } });
        r.status = $('status').textContent; r.pendingAfterStale = pending === null; r.pauseDisabled = $('pause').disabled; return r; })()`);
      assert.equal(rs.downAfter, 0); assert.equal(rs.pendingCleared, true); assert.equal(rs.replaced, true); assert.equal(rs.ringHead, 0);
      assert.doesNotMatch(rs.status, /987\.6|stale/); assert.equal(rs.pendingAfterStale, true); assert.equal(rs.pauseDisabled, false);
      await waitFor(`session.id === ${rs.id} && Number(($('status').textContent.match(/emulated ([\\d.]+) s/) || [])[1]) >= 2`, 30000, 'restarted machine runs');
    });
    await t.test('a full key ring stops the machine with an explicit error instead of dropping input', async () => {
      await click('pause'); await sleep(300);
      const o = rec.r.overflow = await ev("(() => { const free = 256 - ((Atomics.load(ctl, 0) - Atomics.load(ctl, 1)) | 0); let ok = 0; while (ok < 300 && pushKey('a', ok % 2 === 0)) ok++; return { free, ok, after: pushKey('a', false), failed: session.failed }; })()");
      assert.equal(o.ok, o.free); assert.equal(o.after, false); assert.match(o.failed, /keyboard queue overflow/);
      await waitFor("session.exited && $('pause').disabled", 15000, 'overflow exit'); const x = rec.r.overflowExit = await ev("({ reason: session.exited.reason, status: $('status').textContent })");
      assert.equal(x.reason, 'stopped'); assert.match(x.status, /Stopped: keyboard queue overflow/);
    });
  } finally { rec.console = b.console; rec.packageSha256After = sha(KEEN); fs.writeFileSync(path.join(OUT, `browser-lifecycle-${stamp}.json`), JSON.stringify(rec, null, 1) + '\n'); await b.close(); }
  assert.equal(rec.packageSha256After, rec.packageSha256Before);
  assert.ok(!rec.console.some(c => c.type === 'exception'), JSON.stringify(rec.console));
});
