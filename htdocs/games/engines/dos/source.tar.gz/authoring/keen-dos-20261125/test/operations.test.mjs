// Regression tests for the bounded run/validate operations (lib/runner/operations.mjs, bin/dos.mjs run|validate)
// and the dos-core-run / dos-core-validate tool template paths. Native units: emulated ms, PPM shots, key events.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { runOperation, validateOperation } from '../lib/runner/operations.mjs';
import { runtimeInventory } from '../agents/inventory.mjs';
import { toolSchema } from '../agents/catalog.mjs';
import { operationSmokeBuilders } from '../agents/operation-smoke.mjs';
import { KEEN as KEEN_REF } from './fixtures.mjs';
const KEEN = KEEN_REF instanceof URL ? fileURLToPath(KEEN_REF) : String(KEEN_REF);
const ROOT = fileURLToPath(new URL('../', import.meta.url)).replace(/\/$/, '');
const NO = !fs.existsSync(KEEN) || !fs.existsSync(path.join(ROOT, 'build/native/build-manifest.json'));
const TMP = path.join(ROOT, `build/test-ops-${process.pid}-${Date.now()}`);
fs.mkdirSync(TMP, { recursive: true });
const bytes = v => Buffer.byteLength(JSON.stringify(v));
// Explicit reviewed pin for the template tests: read from Root's review record, never from the binary's own manifest/inventory.
const REVIEW = path.join(ROOT, 'handoffs/root-reviewed-native-candidate-20261125.json');
const PIN = fs.existsSync(REVIEW) ? { sha256: JSON.parse(fs.readFileSync(REVIEW, 'utf8')).binarySha256, source: 'test: handoffs/root-reviewed-native-candidate-20261125.json' } : null;

test('run: compact ok result in native units, exact identity, under the handoff limit; run IDs immutable', { skip: NO }, async () => {
  const r = await runOperation({ instanceRoot: TMP, runId: 'op-a', packageFile: KEEN, executable: 'KEEN1.EXE', untilMs: 3500, shotsMs: [0, 3500] });
  assert.equal(r.format, 'dos-run-summary/1'); assert.equal(r.ok, true); assert.equal(r.exit, 'until-ms');
  assert.equal(r.candidateIdentity.executable, 'KEEN1.EXE'); assert.equal(r.shots.length, 2);
  assert.ok(r.shots.every(s => /^[a-f0-9]{64}$/.test(s.sha256)));
  assert.deepEqual(r.video.modes.map(m => [m.width, m.height]), [[640, 400], [320, 200]]);
  assert.match(r.audio.wavSha256, /^[a-f0-9]{64}$/); assert.ok(bytes(r) < 7168, String(bytes(r)));
  await assert.rejects(runOperation({ instanceRoot: TMP, runId: 'op-a', packageFile: KEEN, executable: 'KEEN1.EXE', untilMs: 10 }), /already exists/);
  await assert.rejects(runOperation({ instanceRoot: TMP, runId: 'op-b', packageFile: KEEN, executable: 'KEEN1.EXE', untilMs: 10, shotsMs: Array.from({ length: 33 }, (_, i) => i) }), /at most 32/);
  assert.ok(!fs.existsSync(path.join(TMP, 'op-b')), 'rejected parameters write nothing');
});

test('validate: two fresh instances agree on frames, modes, audio, shots and drive changes; package unchanged', { skip: NO }, async () => {
  const v = await validateOperation({ instanceRoot: TMP, runId: 'val', packageFile: KEEN, executable: 'KEEN1.EXE', untilMs: 3500, shotsMs: [1000, 3500] });
  assert.equal(v.ok, true, JSON.stringify(v.checks.filter(c => !c.passed)));
  assert.ok(['frames-log-identical', 'audio-identical', 'shots-identical', 'instances-isolated', 'package-unchanged'].every(n => v.checks.find(c => c.name === n)?.passed));
  assert.ok(v.unsupported.some(u => /checkpoint/.test(u)));
  assert.ok(fs.existsSync(path.join(TMP, 'val-a')) && fs.existsSync(path.join(TMP, 'val-b')));
  assert.ok(bytes(v) < 7168);
});

test('CLI run reports a failed run (nonexistent exe) as an error with no instance', { skip: NO }, () => {
  const r = spawnSync(process.execPath, [path.join(ROOT, 'bin/dos.mjs'), 'run', KEEN, '--exe', 'NOPE.EXE', '--run-id', 'cli-x', '--until-ms', '100', '--instance-root', TMP], { encoding: 'utf8' });
  assert.equal(r.status, 1); assert.match(r.stderr, /not a package executable/); assert.ok(!fs.existsSync(path.join(TMP, 'cli-x')));
  const u = spawnSync(process.execPath, [path.join(ROOT, 'bin/dos.mjs'), 'run', KEEN, '--exe', 'KEEN1.EXE', '--run-id', 'cli-y', '--frames', '2'], { encoding: 'utf8' });
  assert.equal(u.status, 1); assert.match(u.stderr, /Unknown/);
});

test('tool template run/validate: schema-matched inputs, structured errors, compact results', { skip: NO || !PIN }, () => {
  const { inventory } = runtimeInventory(ROOT);
  const T = fs.readFileSync(path.join(ROOT, 'agents/tool-template.mjs'), 'utf8');
  const tool = op => { const f = path.join(TMP, `${op}-tool.mjs`); fs.writeFileSync(f, T.replace('__DOS_TOOL_CONFIG__', () => JSON.stringify({ operation: op, root: ROOT, inventory, outputRoot: path.join(TMP, 'tool-runs'), node: process.execPath, readRoots: [ROOT], binaryPin: PIN }))); return f; };
  const call = (f, i) => { const r = spawnSync(process.execPath, [f], { input: JSON.stringify(i), encoding: 'utf8', timeout: 170000 }); assert.equal(r.status, 0, r.stderr); return JSON.parse(r.stdout); };
  const run = tool('run');
  const keys = path.join(TMP, 'keys.json'); fs.writeFileSync(keys, JSON.stringify([{ ms: 3600, key: 'space', action: 'down' }, { ms: 3700, key: 'space', action: 'up' }]));
  const ok = call(run, { package_path: KEEN, executable: 'KEEN1.EXE', run_id: 't-run', until_ms: 4000, shots_ms: [4000], input_path: keys });
  assert.equal(ok.status, 'ok'); assert.equal(ok.result.ok, true); assert.deepEqual(ok.result.input, { keysParsed: 2, keysSent: 2 });
  for (const [bad, re] of [[{ frames: 2 }, /Invalid input fields/], [{ until_ms: 60001 }, /until_ms/], [{ shots_ms: [5000] }, /shots_ms/], [{ state_path: '/x' }, /Invalid input fields/]]) {
    const e = call(run, { package_path: KEEN, executable: 'KEEN1.EXE', run_id: 't-bad', until_ms: 1000, ...bad });
    assert.equal(e.status, 'error'); assert.equal(e.error.code, 'invalid_input'); assert.match(e.error.message, re);
  }
  assert.equal(call(run, { package_path: KEEN, executable: 'KEEN1.EXE', run_id: 't-run', until_ms: 10 }).error.code, 'runtime_failed');
  const v = call(tool('validate'), { package_path: KEEN, executable: 'KEEN1.EXE', run_id: 't-val', until_ms: 2000 });
  assert.equal(v.status, 'ok'); assert.equal(v.result.ok, true);
  // The catalog schema accepts exactly what the template accepts.
  const s = toolSchema('run');
  assert.deepEqual(Object.keys(s.properties).sort(), ['executable', 'input_path', 'machine', 'package_path', 'run_id', 'shots_ms', 'until_ms']);
  assert.deepEqual(s.required, ['package_path', 'executable', 'run_id', 'until_ms']);
});

test('operation smoke builders give fresh run ids and require the inspected identity', () => {
  const b = operationSmokeBuilders('20261125x');
  const c = b.run({ name: 'dos-core-run' }, { packagePath: '/p.zip', expected: { executable: 'A.EXE' } });
  assert.equal(c.input.run_id, 'smoke-dos-core-run-20261125x'); assert.equal(c.input.until_ms, 1000);
  assert.deepEqual(c.expect.runIdentity, { executable: 'A.EXE' });
  assert.throws(() => operationSmokeBuilders('Bad Stamp'), /stamp/);
});

test('late keyboard event is rejected before any instance is written', { skip: NO }, async () => {
  const input = [{ ms: 100, key: 'space', action: 'down' }, { ms: 5000, key: 'space', action: 'up' }];
  await assert.rejects(runOperation({ instanceRoot: TMP, runId: 'late-k', packageFile: KEEN, executable: 'KEEN1.EXE', untilMs: 1000, input }), /Input 1: ms 5000 is after untilMs 1000/);
  assert.ok(!fs.existsSync(path.join(TMP, 'late-k')), 'late input wrote nothing');
});

test('wrong independent expected pin rejects even a self-consistent manifest', { skip: NO }, async () => {
  const m = JSON.parse(fs.readFileSync(path.join(ROOT, 'build/native/build-manifest.json'), 'utf8'));
  const actual = (await import('node:crypto')).createHash('sha256').update(fs.readFileSync(path.join(ROOT, 'build/native/posse-dosbox'))).digest('hex');
  assert.equal(m.output.sha256, actual, 'precondition: manifest is self-consistent with the binary');
  const wrong = actual.replace(/^./, c => (c === '0' ? '1' : '0'));
  await assert.rejects(runOperation({ instanceRoot: TMP, runId: 'pin-x', packageFile: KEEN, executable: 'KEEN1.EXE', untilMs: 100, expectedBinarySha256: wrong, pinSource: 'test: deliberately wrong pin' }), /does not match the reviewed expected identity/);
  assert.ok(!fs.existsSync(path.join(TMP, 'pin-x')), 'pin mismatch wrote nothing');
  await assert.rejects(validateOperation({ instanceRoot: TMP, runId: 'pin-v', packageFile: KEEN, executable: 'KEEN1.EXE', untilMs: 100, expectedBinarySha256: wrong, pinSource: 'test' }), /reviewed expected identity/);
  assert.ok(!fs.existsSync(path.join(TMP, 'pin-v-a')));
});

test('runtime snapshot relocation: generated tools run/validate from a read-only copy of the inventory only', { skip: NO || !PIN }, () => {
  const { inventory, nativeBinarySha256 } = runtimeInventory(ROOT);
  assert.equal(nativeBinarySha256, PIN.sha256, 'inventoried binary is the reviewed one');
  const snap = path.join(TMP, 'snap');
  fs.mkdirSync(snap, { mode: 0o700 });
  for (const [n, d] of Object.entries(inventory)) {
    const f = path.join(snap, n); fs.mkdirSync(path.dirname(f), { recursive: true, mode: 0o700 });
    fs.writeFileSync(f, fs.readFileSync(path.join(ROOT, n)), { flag: 'wx', mode: 0o400 });
  }
  assert.equal(fs.statSync(path.join(snap, 'build/native/posse-dosbox')).mode & 0o777, 0o400);
  assert.ok(!fs.existsSync(path.join(snap, 'build/instances')) && !fs.existsSync(path.join(snap, 'test')));
  const T = fs.readFileSync(path.join(ROOT, 'agents/tool-template.mjs'), 'utf8');
  const out = path.join(TMP, 'snap-out');
  const tool = (op, pin) => { const f = path.join(TMP, `snap-${op}-${pin.sha256.slice(0, 4)}.mjs`); fs.writeFileSync(f, T.replace('__DOS_TOOL_CONFIG__', () => JSON.stringify({ operation: op, root: snap, inventory, outputRoot: out, node: process.execPath, readRoots: [snap, path.dirname(KEEN)], binaryPin: pin }))); return f; };
  const call = (f, i) => { const r = spawnSync(process.execPath, [f], { input: JSON.stringify(i), encoding: 'utf8', timeout: 170000, cwd: TMP }); assert.equal(r.status, 0, r.stderr); return JSON.parse(r.stdout); };
  const zipBefore = fs.readFileSync(KEEN);
  const r = call(tool('run', PIN), { package_path: KEEN, executable: 'KEEN1.EXE', run_id: 'snap-run', until_ms: 2000, shots_ms: [2000] });
  assert.equal(r.status, 'ok', JSON.stringify(r.error)); assert.equal(r.result.ok, true);
  assert.equal(r.result.binarySha256, PIN.sha256); assert.equal(r.result.identity.mode, 'authenticated');
  assert.ok(r.result.evidence.instanceDir.startsWith(out + path.sep));
  const rec = fs.readFileSync(path.join(r.result.evidence.instanceDir, 'result.json'), 'utf8');
  assert.ok(rec.includes(path.join(snap, 'build/native/build-manifest.json')), 'manifest read from the snapshot');
  assert.ok(!rec.includes(path.join(ROOT, 'build/native')), 'no dev build-path dependency');
  assert.equal(fs.statSync(path.join(r.result.evidence.instanceDir, 'posse-dosbox')).mode & 0o777, 0o500);
  const v = call(tool('validate', PIN), { package_path: KEEN, executable: 'KEEN1.EXE', run_id: 'snap-val', until_ms: 2000 });
  assert.equal(v.status, 'ok', JSON.stringify(v.error)); assert.equal(v.result.ok, true);
  assert.ok(v.result.checks.every(c => c.passed), JSON.stringify(v.result.checks.filter(c => !c.passed)));
  // Mismatch: a wrong reviewed pin refuses the self-consistent snapshot binary before any instance is written.
  const wrong = { sha256: PIN.sha256.replace(/^./, c => (c === '0' ? '1' : '0')), source: 'test: wrong pin' };
  const e = call(tool('run', wrong), { package_path: KEEN, executable: 'KEEN1.EXE', run_id: 'snap-bad', until_ms: 100 });
  assert.equal(e.status, 'error'); assert.equal(e.error.code, 'runtime_failed'); assert.match(e.error.message, /reviewed expected identity/);
  assert.ok(!fs.existsSync(path.join(out, 'snap-bad')));
  // Tampered snapshot file fails the inventory integrity check.
  const pj = path.join(snap, 'package.json'); fs.chmodSync(pj, 0o600); fs.appendFileSync(pj, ' ');
  assert.equal(call(tool('run', PIN), { package_path: KEEN, executable: 'KEEN1.EXE', run_id: 'snap-tamper', until_ms: 100 }).error.code, 'runtime_integrity');
  assert.ok(fs.readFileSync(KEEN).equals(zipBefore), 'original ZIP unchanged');
});
