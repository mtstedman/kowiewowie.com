import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { TOOLS, AGENTS, COORDINATOR, toolSchema, ENGINEER_DOMAINS } from '../agents/catalog.mjs';
import { runtimeInventory } from '../agents/inventory.mjs';
import { KEEN } from './fixtures.mjs';

const root = fileURLToPath(new URL('../', import.meta.url)).replace(/\/$/, '');
function validate(schema, value) { // minimal JSON-schema subset used by our tool schemas
  if (Object.keys(value).some(k => !schema.properties[k])) return false;
  if (schema.required.some(k => value[k] === undefined)) return false;
  return Object.entries(value).every(([k, v]) => { const p = schema.properties[k];
    if (p.type === 'integer') return Number.isInteger(v) && v >= p.minimum && v <= p.maximum;
    if (p.type === 'array') return Array.isArray(v) && v.length <= p.maxItems && (!p.uniqueItems || new Set(v).size === v.length) && v.every(x => Number.isInteger(x) && x >= p.items.minimum && x <= p.items.maximum);
    if (typeof v !== 'string') return false;
    if (p.enum && !p.enum.includes(v)) return false;
    return (!p.pattern || new RegExp(p.pattern).test(v)) && (!p.maxLength || v.length <= p.maxLength); });
}

test('tool schemas: inspect optional executable, run/validate require executable and run_id', () => {
  const inspect = toolSchema('inspect'), run = toolSchema('run'), val = toolSchema('validate');
  assert.ok(validate(inspect, { package_path: '/x.zip' }));
  assert.ok(validate(inspect, { package_path: '/x.zip', executable: 'KEEN1.EXE', expected_format: 'dos-mz', machine: 'pc-svga' }));
  assert.ok(validate(inspect, { package_path: '/x.zip', executable: 'C:\\GAMES\\KEEN1.EXE' }));
  for (const bad of [{ package_path: 'rel.zip' }, { package_path: '/x.zip', executable: 'README.TXT' }, { package_path: '/x.zip', executable: 'LONGFILENAME.EXE' }, { package_path: '/x.zip', machine: 'amiga' }, { package_path: '/x.zip', frames: 5 }])
    assert.equal(validate(inspect, bad), false, JSON.stringify(bad));
  assert.equal(validate(run, { package_path: '/x.zip', run_id: 'a' }), false);
  assert.equal(validate(val, { package_path: '/x.zip', executable: 'A.EXE' }), false);
  assert.ok(validate(run, { package_path: '/x.zip', executable: 'A.EXE', run_id: 'r-1', until_ms: 1000, shots_ms: [0, 1000], input_path: '/k.json' }));
  assert.ok(validate(val, { package_path: '/x.zip', executable: 'A.EXE', run_id: 'r', until_ms: 500 }));
  // Native units only: no frame counts, drive or machine-state inputs; until_ms is required and bounded.
  for (const bad of [{ frames: 60 }, { state_path: '/s.json' }, { drive_path: '/d' }, { until_ms: 0 }, { until_ms: 60001 }, { shots_ms: [1, 1] }, { shots_ms: Array(33).fill(0).map((_, i) => i) }, { expected_format: 'dos-mz' }])
    assert.equal(validate(run, { package_path: '/x.zip', executable: 'A.EXE', run_id: 'r', until_ms: 100, ...bad }), false, JSON.stringify(bad));
  assert.equal(validate(run, { package_path: '/x.zip', executable: 'A.EXE', run_id: 'r' }), false);
  assert.equal(validate(val, { package_path: '/x.zip', executable: 'A.EXE', run_id: 'r', until_ms: 10, state_path: '/s.json' }), false);
});

test('agent catalog wiring is consistent and title-free', () => {
  const names = new Set(TOOLS.map(t => t.name));
  for (const a of AGENTS) for (const t of a.definition.tools) assert.ok(names.has(t), t);
  const bindings = new Set([...AGENTS.map(a => `${a.definition.name}-invoke`), ...ENGINEER_DOMAINS.map(d => `dos-${d}-engineer-invoke`)]);
  for (const t of COORDINATOR.tools) assert.ok(names.has(t) || bindings.has(t), t);
  assert.ok(!COORDINATOR.tools.includes('dos-coordinator-invoke'));
  const text = JSON.stringify([AGENTS, COORDINATOR, TOOLS]);
  assert.doesNotMatch(text, /keen|ckeen|lzexe-unpack/i);
  for (const a of [...AGENTS.map(a => a.definition), COORDINATOR]) { assert.equal(a.schema, 'bossy.agent.v1'); assert.deepEqual(a.scope, { kind: 'sandbox' }); }
});

test('tool template enforces integrity, fields and read roots; inspect works', { skip: !fs.existsSync(KEEN) && 'input absent' }, () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dos-tool-'));
  const { inventory } = runtimeInventory(root);
  const config = { operation: 'inspect', root, inventory, outputRoot: path.join(dir, 'out'), node: process.execPath, readRoots: [root] };
  const tool = path.join(dir, 'tool.mjs');
  fs.writeFileSync(tool, fs.readFileSync(new URL('../agents/tool-template.mjs', import.meta.url), 'utf8').replace('__DOS_TOOL_CONFIG__', JSON.stringify(config)));
  const call = input => JSON.parse(spawnSync(process.execPath, [tool], { input: JSON.stringify(input), encoding: 'utf8' }).stdout);
  const pkg = fileURLToPath(KEEN);
  const listed = call({ package_path: pkg });
  assert.equal(listed.status, 'ok');
  assert.equal(listed.result.package.selection, 'required');
  const chosen = call({ package_path: pkg, executable: 'KEEN1.EXE', expected_format: 'dos-mz' });
  assert.equal(chosen.result.package.candidateIdentity.executable, 'KEEN1.EXE');
  assert.match(call({ package_path: pkg, executable: 'KEEN1.EXE', expected_format: 'dos-com' }).error.message, /format mismatch/);
  assert.match(call({ package_path: pkg, run_id: 'x' }).error.message, /Invalid input fields/);
  assert.match(call({ package_path: pkg, executable: '--machine' }).error.message, /Invalid executable/);
  assert.match(call({ package_path: '/etc/hostname' }).error.message, /outside DOS tool read roots/);
  // Tampered inventory pin is refused before execution.
  const bad = { ...config, inventory: { ...inventory, 'package.json': '0'.repeat(64) } };
  fs.writeFileSync(tool, fs.readFileSync(new URL('../agents/tool-template.mjs', import.meta.url), 'utf8').replace('__DOS_TOOL_CONFIG__', JSON.stringify(bad)));
  assert.match(call({ package_path: pkg }).error.message, /integrity mismatch/);
  fs.rmSync(dir, { recursive: true, force: true });
});

test('registration plan mode is offline and only activates implemented tools', () => {
  const r = spawnSync(process.execPath, [path.join(root, 'agents/register.mjs')], { encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
  const plan = JSON.parse(r.stdout);
  assert.equal(plan.format, 'dos-registration-plan/1');
  assert.deepEqual(plan.tools.map(t => t.name), ['dos-package-inspect', 'dos-core-run', 'dos-core-validate']);
  assert.deepEqual(plan.deferredTools, []);
  assert.deepEqual(plan.agents, ['dos-mz-manager', 'dos-com-manager', 'dos-core-runner', 'dos-validator']);
  for (const t of plan.tools.filter(t => t.operation !== 'inspect')) assert.ok(t.smoke && t.smoke.input.until_ms === 1000 && /^smoke-/.test(t.smoke.input.run_id) && t.smoke.expect.runIdentity, t.name);
  assert.match(plan.runtimeDigest, /^[a-f0-9]{64}$/);
  assert.ok(!fs.existsSync(path.join(root, 'agents/registration.json')));
});
