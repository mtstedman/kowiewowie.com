// Focused regressions for verification/package-review-1.md D1-D6 (package layer).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { deflateRawSync } from 'node:zlib';
import { inspectPackage, dosComponent } from '../lib/package/inspect.mjs';
import { readZip } from '../lib/package/zip.mjs';
import { inspectMz } from '../lib/package/mz.mjs';
import { crc32 } from '../lib/package/crc32.mjs';
import { PackageManager } from '../lib/package/PackageManager.mjs';
import { runtimeInventory } from '../agents/inventory.mjs';
import { makeZip, makeMz, KEEN } from './fixtures.mjs';

const ROOT = fileURLToPath(new URL('../', import.meta.url)).replace(/\/$/, '');
const com = Buffer.from([0xb4, 0x4c, 0xcd, 0x21]);
const keenSkip = !fs.existsSync(KEEN) && 'input absent';

// ZIP writer with independently settable local fields and optional data descriptors.
function buildZip(files) {
  const locals = [], centrals = []; let offset = 0;
  for (const f of files) {
    const name = Buffer.from(f.name, 'latin1'), data = Buffer.from(f.data);
    const method = f.method ?? 0, body = method === 8 ? deflateRawSync(data) : data;
    const c = { flags: f.flags ?? 0, method, crc: crc32(data), csize: body.length, usize: data.length };
    const l = { ...c, ...(f.local ?? {}) };
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(l.flags, 6); lh.writeUInt16LE(l.method, 8);
    lh.writeUInt32LE(l.crc, 14); lh.writeUInt32LE(l.csize, 18); lh.writeUInt32LE(l.usize, 22); lh.writeUInt16LE(name.length, 26);
    let dd = Buffer.alloc(0);
    if (f.descriptor) {
      const d = { ...c, ...(f.descriptorValues ?? {}) }, v = Buffer.alloc(12);
      v.writeUInt32LE(d.crc, 0); v.writeUInt32LE(d.csize, 4); v.writeUInt32LE(d.usize, 8);
      dd = f.descriptor === 'signed' ? Buffer.concat([Buffer.from([0x50, 0x4b, 0x07, 0x08]), v]) : v;
    }
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(c.flags, 8); ch.writeUInt16LE(c.method, 10);
    ch.writeUInt32LE(c.crc, 16); ch.writeUInt32LE(c.csize, 20); ch.writeUInt32LE(c.usize, 24); ch.writeUInt16LE(name.length, 28); ch.writeUInt32LE(offset, 42);
    locals.push(lh, name, body, dd); centrals.push(ch, name);
    offset += 30 + name.length + body.length + dd.length;
  }
  const cd = Buffer.concat(centrals), eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(files.length, 8); eocd.writeUInt16LE(files.length, 10);
  eocd.writeUInt32LE(cd.length, 12); eocd.writeUInt32LE(offset, 16);
  return Buffer.concat([...locals, cd, eocd]);
}
// Independent reader (CPython zipfile, isolated mode) for fixtures we accept; null if unavailable.
function pythonAccepts(zip) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dos-zip-fix-'));
  try {
    const file = path.join(dir, 'a.zip'); fs.writeFileSync(file, zip);
    const r = spawnSync('python3', ['-I', '-c', 'import sys,zipfile; z=zipfile.ZipFile(sys.argv[1]); assert z.testzip() is None; print(len(z.infolist()))', file], { encoding: 'utf8' });
    return r.error ? null : r.status === 0;
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}

test('D1 package identity binds root/mount semantics and executable selection', () => {
  const zip = makeZip([{ name: 'GAME/GAME.EXE', data: makeMz() }, { name: 'GAME/SETUP.COM', data: com }]);
  const pm = new PackageManager();
  const auto = pm.importBytes(zip), flat = pm.importBytes(zip, { root: '' });
  assert.equal(auto.metadata.root, 'GAME'); assert.equal(flat.metadata.root, '');
  assert.notEqual(auto.key, flat.key);
  assert.deepEqual([...pm.drive(auto.key).keys()].sort(), ['GAME.EXE', 'SETUP.COM']);
  assert.deepEqual([...pm.drive(flat.key).keys()].sort(), ['GAME\\GAME.EXE', 'GAME\\SETUP.COM']);
  assert.deepEqual(Object.keys(auto.metadata.packageIdentity).sort(), ['abi', 'archiveSha256', 'contentDigest', 'executable', 'machine', 'root']);
  const mounted = inspectPackage(zip, { executable: 'GAME.EXE' }).metadata.candidateIdentity;
  const nested = inspectPackage(zip, { root: '', executable: 'GAME\\GAME.EXE' }).metadata.candidateIdentity;
  assert.equal(nested.executableSha256, mounted.executableSha256);
  assert.equal(mounted.root, 'GAME'); assert.equal(nested.root, '');
  assert.notDeepEqual(nested, mounted);
  const sel = pm.importBytes(zip, { executable: 'GAME.EXE' });
  assert.notEqual(sel.key, auto.key);
  assert.equal(sel.metadata.packageIdentity.executable, 'GAME.EXE');
  assert.deepEqual([...pm.drive(auto.key).keys()].sort(), ['GAME.EXE', 'SETUP.COM']);
});

test('D1 re-import resolving to an owned key keeps the first package', () => {
  const zip = makeZip([{ name: 'GAME/GAME.EXE', data: makeMz() }, { name: 'GAME/DATA.DAT', data: Buffer.from('data') }]);
  const pm = new PackageManager();
  const first = pm.importBytes(zip);
  assert.equal(first.reimported, false);
  const owned = pm.metadata(first.key);
  for (const options of [{}, { root: 'GAME' }, { root: 'GAME/' }, { expectedFormat: 'dos-mz' }]) {
    const again = pm.importBytes(Buffer.from(zip), options);
    assert.equal(again.key, first.key, JSON.stringify(options));
    assert.equal(again.reimported, true);
    assert.equal(again.metadata, owned);
    assert.equal(pm.metadata(first.key), owned);
  }
  assert.deepEqual([...pm.drive(first.key).keys()].sort(), ['DATA.DAT', 'GAME.EXE']);
});

test('D1 Commander Keen archive: auto root and flat root are distinct owned packages', { skip: keenSkip }, () => {
  const pm = new PackageManager(); const bytes = fs.readFileSync(KEEN);
  const a = pm.importBytes(bytes); const before = [...pm.drive(a.key).keys()]; const meta = pm.metadata(a.key);
  const b = pm.importBytes(bytes, { root: '' });
  assert.notEqual(a.key, b.key);
  assert.deepEqual([...pm.drive(a.key).keys()], before); assert.equal(pm.metadata(a.key), meta);
  assert.ok(before.includes('KEEN1.EXE'));
  assert.ok([...pm.drive(b.key).keys()].every(k => k.startsWith('CKEEN1\\')));
  const again = pm.importBytes(bytes);
  assert.equal(again.key, a.key); assert.equal(again.reimported, true); assert.equal(again.metadata, meta);
});

test('D2 non-ASCII names are rejected before ASCII case mapping', () => {
  for (const s of ['\u017fwcbbs.exe', 'k\u0131en1.exe', '\u00dfa.exe', '\ufb01le.dat', 'caf\u00e9.exe', 'A\u0000.EXE', 'A\tB.EXE']) assert.equal(dosComponent(s), null, JSON.stringify(s));
  assert.equal(dosComponent('swcbbs.exe'), 'SWCBBS.EXE');
  const zip = makeZip([{ name: 'SWCBBS.EXE', data: com }]);
  for (const s of ['\u017fwcbbs.exe', 'SWCBB\u017f.EXE']) assert.throws(() => inspectPackage(zip, { executable: s }), /not a package executable/, JSON.stringify(s));
  assert.equal(inspectPackage(zip, { executable: 'c:\\swcbbs.exe' }).metadata.executable, 'SWCBBS.EXE');
  const utf8 = s => Buffer.from(s, 'utf8').toString('latin1');
  const m = inspectPackage(makeZip([{ name: 'A.COM', data: com }, { name: utf8('\u017fwcbbs.exe'), data: com, flags: 0x800 }, { name: utf8('k\u0131en1.exe'), data: com, flags: 0x800 }])).metadata;
  assert.deepEqual(m.members.map(x => x.dosPath), ['A.COM']);
  assert.deepEqual(m.excluded.map(x => x.archivePath).sort(), ['k\u0131en1.exe', '\u017fwcbbs.exe']);
});

test('D3/D4 new-header probe follows the declared header extent, not e_lfarlc', () => {
  for (const sig of ['PE', 'NE', 'LE', 'LX']) {
    for (const lfarlc of [0x1c, 0x40]) {
      const b = makeMz({ newHeader: sig }); b.writeUInt16LE(lfarlc, 24);
      assert.throws(() => inspectMz(b), /Unsupported executable format/, `${sig} lfarlc=${lfarlc}`);
    }
  }
  // 0x20-byte header: bytes at file offset 0x3C belong to the image, not e_lfanew.
  const img = Buffer.alloc(0x40); img.writeUInt32LE(0x40, 0x1c); img.write('NE', 0x20, 'latin1');
  for (const lfarlc of [0x1c, 0x40]) {
    const b = makeMz({ image: img }); b.writeUInt16LE(lfarlc, 24);
    assert.equal(inspectMz(b).format, 'dos-mz', `lfarlc=${lfarlc}`);
  }
  // 0x50-byte header whose relocation table covers 0x3C: entry bytes are not e_lfanew.
  const mz = crlc => {
    const h = Buffer.alloc(0x50), image = Buffer.from([0x50, 0x45, 0, 0, 0xb8, 0x00, 0x4c, 0xcd, 0x21]), total = h.length + image.length;
    h.write('MZ', 0, 'latin1'); h.writeUInt16LE(total % 512, 2); h.writeUInt16LE(Math.ceil(total / 512), 4); h.writeUInt16LE(crlc, 6);
    h.writeUInt16LE(5, 8); h.writeUInt16LE(0x1c, 24); h.writeUInt32LE(0x50, 0x3c);
    return Buffer.concat([h, image]);
  };
  assert.equal(inspectMz(mz(12)).relocations, 12);
  assert.throws(() => inspectMz(mz(0)), /Unsupported executable format: Windows PE/);
  // A PE signature needs its two trailing zero bytes.
  const notPe = makeMz({ newHeader: 'PE' }); notPe[notPe.length - 1] = 1;
  assert.equal(inspectMz(notPe).format, 'dos-mz');
});

test('D5 operation tool returns structured errors for oversized and malformed stdin', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dos-tool-fix-'));
  try {
    const { inventory } = runtimeInventory(ROOT);
    const config = { operation: 'inspect', root: ROOT, inventory, outputRoot: path.join(dir, 'out'), node: process.execPath, readRoots: [ROOT] };
    const tool = path.join(dir, 'tool.mjs');
    fs.writeFileSync(tool, fs.readFileSync(path.join(ROOT, 'agents/tool-template.mjs'), 'utf8').replace('__DOS_TOOL_CONFIG__', JSON.stringify(config)));
    const call = input => {
      const r = spawnSync(process.execPath, [tool], { input, encoding: 'utf8', timeout: 30000 });
      assert.equal(r.status, 0, r.stderr); assert.equal(r.stderr, '');
      return JSON.parse(r.stdout);
    };
    for (const size of [16385, 20000, 1024 * 1024]) {
      const out = call(JSON.stringify({ package_path: '/x.zip', root: 'x'.repeat(size) }));
      assert.equal(out.status, 'error', String(size)); assert.match(out.error.message, /exceeds 16 KiB/);
    }
    // Exactly at the limit is read and validated normally.
    const exact = call(JSON.stringify({ package_path: '/nonexistent/x.zip' }).padEnd(16384, ' '));
    assert.equal(exact.status, 'error'); assert.doesNotMatch(exact.error.message, /exceeds/);
    for (const bad of ['', '{not json', 'null', '[]']) assert.equal(call(bad).status, 'error', JSON.stringify(bad));
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});

const REJECT = /ZIP rejected: (local\/central|missing or inconsistent data descriptor)/;
test('D6 local headers must agree with the central directory', () => {
  const data = Buffer.from('hello, local header '.repeat(8));
  for (const method of [0, 8]) {
    const good = buildZip([{ name: 'A.COM', data: com, method }, { name: 'B.DAT', data, method }]);
    assert.deepEqual(readZip(good).entries.map(e => e.bytes.toString('hex')), [com.toString('hex'), data.toString('hex')]);
    const py = pythonAccepts(good); if (py !== null) assert.equal(py, true, `python method ${method}`);
    for (const [label, local] of [['CRC', { crc: 0xdeadbeef }], ['compressed size', { csize: 1 }], ['uncompressed size', { usize: 1 }], ['method', { method: method === 0 ? 8 : 0 }], ['UTF-8 flag', { flags: 0x800 }], ['descriptor flag', { flags: 0x8 }], ['zero CRC without descriptor', { crc: 0 }]])
      assert.throws(() => readZip(buildZip([{ name: 'A.COM', data: com, method, local }])), REJECT, `${label} method ${method}`);
  }
});

test('D6 data-descriptor members (flag bit 3) are handled explicitly', () => {
  const data = Buffer.from('descriptor payload '.repeat(20));
  const zero = { crc: 0, csize: 0, usize: 0 };
  const accepted = [
    ['signed descriptor, zero local fields', [{ name: 'A.COM', data: com, flags: 8, local: zero, descriptor: 'signed' }]],
    ['unsigned descriptor, zero local fields', [{ name: 'A.COM', data: com, flags: 8, local: zero, descriptor: 'unsigned' }]],
    ['descriptor with real local fields', [{ name: 'A.COM', data: com, flags: 8, descriptor: 'signed' }]],
    ['deflated members with descriptors', [{ name: 'A.COM', data: com, method: 8, flags: 8, local: zero, descriptor: 'signed' }, { name: 'B.DAT', data, method: 8, flags: 8, local: zero, descriptor: 'unsigned' }]],
  ];
  for (const [label, files] of accepted) {
    const zip = buildZip(files);
    const entries = readZip(zip).entries;
    assert.deepEqual(entries.map(e => e.name), files.map(f => f.name), label);
    entries.forEach((e, i) => assert.ok(e.bytes.equals(Buffer.from(files[i].data)), label));
    const py = pythonAccepts(zip); if (py !== null) assert.equal(py, true, `python ${label}`);
  }
  const rejected = [
    ['flag set but no descriptor', [{ name: 'A.COM', data: com, flags: 8, local: zero }]],
    ['flag set, no descriptor, next member follows', [{ name: 'A.COM', data: com, flags: 8, local: zero }, { name: 'B.DAT', data }]],
    ['descriptor CRC mismatch', [{ name: 'A.COM', data: com, flags: 8, local: zero, descriptor: 'signed', descriptorValues: { crc: 1 } }]],
    ['descriptor size mismatch', [{ name: 'A.COM', data: com, flags: 8, local: zero, descriptor: 'unsigned', descriptorValues: { usize: 99 } }]],
    ['non-zero local CRC disagrees', [{ name: 'A.COM', data: com, flags: 8, local: { crc: 1 }, descriptor: 'signed' }]],
    ['bit 3 only in central', [{ name: 'A.COM', data: com, flags: 8, local: { flags: 0 }, descriptor: 'signed' }]],
    ['bit 3 only in local', [{ name: 'A.COM', data: com, flags: 0, local: { flags: 8 }, descriptor: 'signed' }]],
  ];
  for (const [label, files] of rejected) assert.throws(() => readZip(buildZip(files)), REJECT, label);
});
