import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { buildConfig, serializeInput, splitDosPath, KEYS } from '../lib/runner/conf.mjs';
import { diffDrive, DosRunner, DEFAULT_BINARY } from '../lib/runner/DosRunner.mjs';

test('config is derived from explicit machine profile and inspected format', () => {
  const c = buildConfig({ driveDir: '/tmp/x/C', executable: 'GAMES\\RUN.EXE', format: 'dos-mz', machine: 'pc-svga' });
  assert.match(c, /\[dosbox\]\nmachine=svga_s3/);
  assert.match(c, /mount c "\/tmp\/x\/C"\nc:\ncd \\GAMES\nRUN.EXE\nexit\n$/);
  assert.match(buildConfig({ driveDir: '/d', executable: 'GO.BAT', format: 'dos-batch', machine: 'pc-svga' }), /call GO.BAT/);
});
test('config rejects unknown machine, format, unsafe paths', () => {
  assert.throws(() => buildConfig({ driveDir: '/d', executable: 'A.EXE', format: 'dos-mz', machine: 'amiga' }), /Machine profile/);
  assert.throws(() => buildConfig({ driveDir: '/d', executable: 'A.EXE', format: 'win-pe', machine: 'pc-svga' }), /Unsupported executable format/);
  assert.match(buildConfig({ driveDir: 'C', executable: 'A.EXE', format: 'dos-mz', machine: 'pc-svga' }), /mount c "C"/);
  for (const d of ['../C', 'a/b', 'C D', '']) assert.throws(() => buildConfig({ driveDir: d, executable: 'A.EXE', format: 'dos-mz', machine: 'pc-svga' }), /short relative name or an absolute path/, d);
  assert.throws(() => buildConfig({ driveDir: '/d"\nexit', executable: 'A.EXE', format: 'dos-mz', machine: 'pc-svga' }), /quotes/);
  assert.throws(() => splitDosPath('A.EXE & DEL *'), /Invalid DOS/);
  assert.throws(() => splitDosPath('..\\A.EXE'), /Invalid DOS/);
});
test('input serialization validates key, action and time', () => {
  assert.equal(serializeInput([{ ms: 5, key: 'enter', action: 'down' }, { ms: 9, key: 'enter', action: 'up' }]), '5 enter down\n9 enter up\n');
  assert.equal(serializeInput([]), '');
  assert.throws(() => serializeInput([{ ms: 1, key: 'bogus', action: 'down' }]), /unsupported key/);
  assert.throws(() => serializeInput([{ ms: -1, key: 'a', action: 'down' }]), /non-negative/);
  assert.throws(() => serializeInput([{ ms: 1, key: 'a', action: 'tap' }]), /down or up/);
  assert.ok(KEYS.includes('space') && KEYS.includes('lctrl'));
});
test('drive diff separates created, modified, deleted game files', () => {
  const before = new Map([['A.CK1', Uint8Array.of(1)], ['B.CK1', Uint8Array.of(2)]]);
  const after = new Map([['A.CK1', Buffer.of(1)], ['B.CK1', Buffer.of(3)], ['SAVED1.CK1', Buffer.of(4)]]);
  const d = diffDrive(before, after);
  assert.deepEqual(d.created.map(f => f.dosPath), ['SAVED1.CK1']);
  assert.deepEqual(d.modified.map(f => f.dosPath), ['B.CK1']);
  assert.deepEqual(diffDrive(before, new Map([['A.CK1', Buffer.of(1)]])).deleted.map(f => f.dosPath), ['B.CK1']);
});
test('runner rejects bad run parameters before touching the machine', async () => {
  const r = new DosRunner({ binary: '/nonexistent' });
  await assert.rejects(r.run({ packageFile: 'x.zip', untilMs: 0, instance: 'a' }), /untilMs/);
  await assert.rejects(r.run({ packageFile: 'x.zip', untilMs: 10, instance: '../x' }), /instance/);
  await assert.rejects(r.run({ packageFile: 'x.zip', untilMs: 10, shotsMs: [20], instance: 'a' }), /shotsMs/);
});
