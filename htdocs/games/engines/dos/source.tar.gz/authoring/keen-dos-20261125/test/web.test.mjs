// Regression tests for the browser/Wasm candidate: artifact authentication, generic launcher package loading,
// key-code mapping, hash compatibility and native-vs-Wasm frame parity on the same original package.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { PackageManager } from '../lib/package/PackageManager.mjs';
import { buildConfig, KEYS } from '../lib/runner/conf.mjs';
import { DosRunner } from '../lib/runner/DosRunner.mjs';
import { loadPackage, kbdKeyMap, singleFileZip } from '../lib/web/launcher.mjs';
import { authenticateWeb, runWasm, fnv64 } from '../core/web/node-host.mjs';
import { KEEN as KEEN_REF } from './fixtures.mjs';
const KEEN = KEEN_REF instanceof URL ? fileURLToPath(KEEN_REF) : String(KEEN_REF);
const ROOT = fileURLToPath(new URL('../', import.meta.url)).replace(/\/$/, '');
const HAVE_WEB = fs.existsSync(path.join(ROOT, 'build/web/build-manifest.json'));
const HAVE_KEEN = fs.existsSync(KEEN);
const TMP = path.join(ROOT, `build/test-web-${process.pid}-${Date.now()}`); fs.mkdirSync(TMP, { recursive: true });

test('fnv64 is bit-identical to the native frame hash (including its offset basis)', () => {
  const u8 = new Uint8Array(16); for (let i = 0; i < 16; i++) u8[i] = (i * 37 + 11) & 255;
  assert.equal(fnv64(u8, 4, 1, 16), 'c8a0c26925cea803'); // value printed by the native fnv() for this buffer
  assert.equal(fnv64(u8, 2, 2, 8), 'c8a0c26925cea803');
});

test('key map comes from the compiled KBD_KEYS enum and covers every native input key name', () => {
  const m = kbdKeyMap(ROOT);
  assert.equal(m['1'], 1); assert.equal(m.esc, m.f12 + 1);
  const alias = { lalt: 'leftalt', ralt: 'rightalt', lctrl: 'leftctrl', rctrl: 'rightctrl', lshift: 'leftshift', rshift: 'rightshift' };
  for (const k of KEYS) assert.ok(Number.isInteger(m[alias[k] ?? k]), k);
});

test('launcher loading is generic: selection required, explicit ready, bare executables wrapped in memory', { skip: !HAVE_KEEN }, () => {
  const zip = fs.readFileSync(KEEN);
  const sel = loadPackage(zip, { kind: 'zip' });
  assert.equal(sel.status, 'select'); assert.equal(sel.drive, undefined); assert.equal(sel.executables.length, 4);
  const ready = loadPackage(zip, { kind: 'zip', executable: 'KEEN1.EXE' });
  assert.equal(ready.status, 'ready'); assert.equal(ready.candidateIdentity.executableSha256, '8b3f829f7eeab18a7fbf9d539967e9ae9c856258aa78efc0531fa922df71c4a2');
  assert.match(ready.conf, /mount c "C"\nc:\nKEEN1\.EXE\nexit\n$/); assert.equal(ready.drive.length, 48);
  assert.throws(() => loadPackage(zip, { kind: 'zip', executable: 'NOPE.EXE' }), /not a package executable/);
  const com = Buffer.from([0xb4, 0x4c, 0xcd, 0x21]); // mov ah,4c; int 21
  const one = loadPackage(com, { kind: 'exe', name: 'tiny.com' });
  assert.equal(one.status, 'ready'); assert.equal(one.wrapped.name, 'TINY.COM'); assert.equal(one.candidateIdentity.format, 'dos-com');
  assert.throws(() => loadPackage(com, { kind: 'exe', name: 'toolongname.com' }), /8\.3|Invalid/);
  assert.ok(singleFileZip('A.COM', com).length > com.length);
  assert.equal(fs.readFileSync(KEEN).equals(zip), true);
});

test('web artifact is authenticated against its build manifest; a tampered copy is refused', { skip: !HAVE_WEB }, () => {
  const a = authenticateWeb();
  assert.equal(a.manifest.format, 'posse-dos-web-build-manifest/1'); assert.match(a.manifest.toolchain.imageId, /^sha256:/);
  const d = path.join(TMP, 'tampered'); fs.mkdirSync(d);
  for (const f of ['build-manifest.json', 'posse-dosbox.js', 'posse-dosbox.wasm']) fs.copyFileSync(path.join(ROOT, 'build/web', f), path.join(d, f));
  authenticateWeb(d);
  const w = fs.readFileSync(path.join(d, 'posse-dosbox.wasm')); w[w.length - 1] ^= 1; fs.writeFileSync(path.join(d, 'posse-dosbox.wasm'), w);
  assert.throws(() => authenticateWeb(d), /does not match/);
});

test('Wasm build reproduces the native frame log, resolution changes and frame count from 0 ms', { skip: !HAVE_WEB || !HAVE_KEEN }, async () => {
  const pm = new PackageManager(); const { key, metadata } = await pm.importFile(KEEN, { executable: 'KEEN1.EXE' });
  const id = metadata.candidateIdentity;
  const conf = buildConfig({ driveDir: 'C', executable: id.executable, format: id.format, machine: id.machine });
  const web = await runWasm({ drive: pm.drive(key), conf, untilMs: 4000 });
  const nat = await new DosRunner({ instanceRoot: TMP }).run({ packageFile: KEEN, executable: 'KEEN1.EXE', untilMs: 4000, instance: 'parity' });
  const nf = fs.readFileSync(path.join(nat.instanceDir, 'out/frames.tsv'), 'utf8').trim().split('\n').slice(1).map(l => l.split('\t'));
  assert.equal(web.frames.length, nf.length);
  web.frames.forEach((f, i) => assert.deepEqual([f.n, f.ms, f.w, f.h, f.hash], nf[i].map((v, j) => (j < 4 ? Number(v) : v)), `frame ${i}`));
  assert.deepEqual(web.modes, nat.summary.modes);
  assert.equal(web.exit.reason, 'stopped'); assert.equal(web.audioNonzero, nat.summary.audioNonzeroSamples);
});

test('launcher server: loopback only, cross-origin isolated, generic load API, writes nothing', { skip: !HAVE_WEB || !HAVE_KEEN }, async () => {
  const p = spawn(process.execPath, [path.join(ROOT, 'bin/dos-web.mjs'), '--port', '0'], { cwd: ROOT });
  try {
    const url = await new Promise((res, rej) => { let s = ''; p.stdout.on('data', d => { s += d; try { res(JSON.parse(s.split('\n')[0]).url); } catch {} }); setTimeout(() => rej(new Error('no server')), 10000); });
    assert.match(url, /^http:\/\/127\.0\.0\.1:\d+\/$/);
    const page = await fetch(url);
    assert.equal(page.headers.get('cross-origin-opener-policy'), 'same-origin'); assert.equal(page.headers.get('cross-origin-embedder-policy'), 'require-corp');
    const b = await (await fetch(url + 'api/build')).json(); assert.equal(b.wasm, authenticateWeb().manifest.output.wasm.sha256);
    const r = await (await fetch(url + 'api/load?kind=zip&exe=KEEN1.EXE', { method: 'POST', body: fs.readFileSync(KEEN) })).json();
    assert.equal(r.status, 'ready'); assert.equal(r.candidateIdentity.executable, 'KEEN1.EXE');
    const bad = await fetch(url + 'api/load?kind=zip', { method: 'POST', body: Buffer.from('not a zip') }); assert.equal(bad.status, 400);
    assert.equal((await fetch(url + 'nope')).status, 404);
  } finally { p.kill(); }
});
