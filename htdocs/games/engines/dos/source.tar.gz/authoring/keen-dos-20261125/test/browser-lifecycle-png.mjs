// Browser-test helper: decode unfiltered 8-bit RGB PNGs (as written by the verifier probes and canvas re-encodes are NOT
// supported), compare pixels and render coarse ASCII for evidence review in a terminal.
import fs from 'node:fs'; import { inflateSync } from 'node:zlib';
export function readPng(f) { const b = fs.readFileSync(f); let o = 8, w, h, ct; const idat = [];
  while (o < b.length) { const n = b.readUInt32BE(o), t = b.toString('ascii', o + 4, o + 8), d = b.subarray(o + 8, o + 8 + n);
    if (t === 'IHDR') { w = d.readUInt32BE(0); h = d.readUInt32BE(4); ct = d[9]; if (d[8] !== 8 || ct !== 2) throw new Error('unexpected png ' + f); } if (t === 'IDAT') idat.push(d); o += 12 + n; }
  const raw = inflateSync(Buffer.concat(idat)), px = Buffer.alloc(w * h * 3);
  for (let y = 0; y < h; y++) { if (raw[y * (w * 3 + 1)] !== 0) throw new Error('filtered png ' + f); raw.copy(px, y * w * 3, y * (w * 3 + 1) + 1, (y + 1) * (w * 3 + 1)); } return { w, h, px }; }
export const same = (a, b) => { if (!a || !b || a.w !== b.w || a.h !== b.h) return null; let s = 0; for (let i = 0; i < a.px.length; i += 3) if (a.px[i] === b.px[i] && a.px[i + 1] === b.px[i + 1] && a.px[i + 2] === b.px[i + 2]) s++; return +(s / (a.w * a.h)).toFixed(3); };
export function ascii(p, W = 56, H = 16) { const ch = ' .:-=+*#%@'; let s = ''; for (let y = 0; y < H; y++) { for (let x = 0; x < W; x++) { let t = 0, n = 0;
  for (let yy = Math.floor(y * p.h / H); yy < Math.floor((y + 1) * p.h / H); yy++) for (let xx = Math.floor(x * p.w / W); xx < Math.floor((x + 1) * p.w / W); xx++) { const i = (yy * p.w + xx) * 3; t += .3 * p.px[i] + .59 * p.px[i + 1] + .11 * p.px[i + 2]; n++; }
  s += ch[Math.min(9, Math.floor(t / n / 25.6))]; } s += '\n'; } return s; }
export function topColors(p, k = 4) { const m = new Map(); for (let i = 0; i < p.px.length; i += 3) { const c = p.px.readUIntBE(i, 3).toString(16).padStart(6, '0'); m.set(c, (m.get(c) || 0) + 1); }
  return [...m].sort((a, b) => b[1] - a[1]).slice(0, k).map(([c, n]) => `${c}:${(n / (p.w * p.h)).toFixed(2)}`).join(' '); }
