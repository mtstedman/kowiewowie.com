import { deflateRawSync } from 'node:zlib';
import { crc32 } from '../lib/package/crc32.mjs';

// Minimal ZIP writer for synthetic fixtures. Options allow deliberate corruption.
export function makeZip(files, { comment = '', method = 8, corrupt = {} } = {}) {
  const locals = [], centrals = []; let offset = 0;
  for (const f of files) {
    const name = Buffer.from(f.name, 'latin1');
    const data = Buffer.from(f.data ?? []);
    const m = f.method ?? method;
    const body = m === 8 ? deflateRawSync(data) : data;
    const crc = f.crc ?? crc32(data);
    const flags = f.flags ?? 0;
    const lh = Buffer.alloc(30);
    lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(flags, 6); lh.writeUInt16LE(m, 8);
    lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(body.length, 18); lh.writeUInt32LE(f.usize ?? data.length, 22); lh.writeUInt16LE(name.length, 26);
    const ch = Buffer.alloc(46);
    ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(flags, 8); ch.writeUInt16LE(m, 10);
    ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(f.csize ?? body.length, 20); ch.writeUInt32LE(f.usize ?? data.length, 24);
    ch.writeUInt16LE(name.length, 28); ch.writeUInt32LE(f.localOffset ?? offset, 42);
    locals.push(lh, name, body); centrals.push(ch, name);
    offset += 30 + name.length + body.length;
  }
  const cd = Buffer.concat(centrals), c = Buffer.from(comment, 'latin1');
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0); eocd.writeUInt16LE(corrupt.disk ?? 0, 4);
  eocd.writeUInt16LE(files.length, 8); eocd.writeUInt16LE(corrupt.count ?? files.length, 10);
  eocd.writeUInt32LE(cd.length, 12); eocd.writeUInt32LE(offset, 16); eocd.writeUInt16LE(c.length, 20);
  return Buffer.concat([...locals, cd, eocd, c]);
}
// Small real-mode MZ executable: header (2 paragraphs) + image.
export function makeMz({ image = Buffer.from([0xb8, 0x00, 0x4c, 0xcd, 0x21]), cs = 0, ip = 0, ss = 0, sp = 0x100, minalloc = 16, newHeader = null, declareExtra = 0 } = {}) {
  const header = Buffer.alloc(newHeader ? 0x40 : 0x20);
  let tail = Buffer.alloc(0);
  if (newHeader) { tail = Buffer.concat([Buffer.from(newHeader, 'latin1'), Buffer.alloc(2)]); header.writeUInt32LE(header.length + image.length, 0x3c); }
  const total = header.length + image.length + declareExtra;
  header.write('MZ', 0, 'latin1');
  header.writeUInt16LE(total % 512, 2); header.writeUInt16LE(Math.ceil(total / 512), 4);
  header.writeUInt16LE(0, 6); header.writeUInt16LE(header.length / 16, 8); header.writeUInt16LE(minalloc, 10); header.writeUInt16LE(0xffff, 12);
  header.writeUInt16LE(ss, 14); header.writeUInt16LE(sp, 16); header.writeUInt16LE(ip, 20); header.writeUInt16LE(cs, 22);
  header.writeUInt16LE(newHeader ? 0x40 : 0x1c, 24);
  return Buffer.concat([header, image, tail]);
}
export const KEEN = new URL('../inputs/commander-keen-1.zip', import.meta.url);
export const KEEN_SHA256 = 'e6c304ca1963120aca2b321b06faac355bef097416b92b2b7364e4d9c3b032d7';
