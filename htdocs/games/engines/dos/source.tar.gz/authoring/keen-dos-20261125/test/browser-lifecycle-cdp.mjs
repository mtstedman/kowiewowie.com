// Browser-test helper: a fresh bin/dos-web.mjs on an ephemeral loopback port plus chrome-headless-shell driven over
// the Chrome DevTools Protocol (no npm dependencies). Real mouse/keyboard events go through Input.dispatch*.
import { spawn } from 'node:child_process';
import { mkdirSync, rmSync } from 'node:fs';
import { join } from 'node:path';
export const CHROME = process.env.POSSE_CHROME || `${process.env.HOME}/.cache/ms-playwright/chromium_headless_shell-1248/chrome-headless-shell-linux64/chrome-headless-shell`;
export const sleep = ms => new Promise(r => setTimeout(r, ms));
const VK = { ArrowLeft: ['ArrowLeft', 37], ArrowUp: ['ArrowUp', 38], ArrowRight: ['ArrowRight', 39], ArrowDown: ['ArrowDown', 40], Space: [' ', 32],
  Enter: ['Enter', 13], Escape: ['Escape', 27], ControlLeft: ['Control', 17, 1], AltLeft: ['Alt', 18, 1], KeyA: ['a', 65] };
export async function openBrowser({ root, profileDir }) {
  mkdirSync(profileDir, { recursive: true });
  const procs = [], consoleLog = [];
  const close = async () => { for (const p of procs) try { p.kill('SIGKILL'); } catch {} await sleep(300); rmSync(profileDir, { recursive: true, force: true }); };
  try {
    const server = spawn(process.execPath, [join(root, 'bin/dos-web.mjs'), '--port', '0'], { cwd: root, stdio: ['ignore', 'pipe', 'pipe'] }); procs.push(server);
    const info = await new Promise((res, rej) => { let s = ''; server.stdout.on('data', d => { s += d; try { res(JSON.parse(s.split('\n')[0])); } catch {} });
      server.on('exit', c => rej(new Error('server exited ' + c))); setTimeout(() => rej(new Error('server start timeout')), 15000); });
    const chrome = spawn(CHROME, ['--headless', '--no-sandbox', '--remote-debugging-port=0', `--user-data-dir=${profileDir}`, '--autoplay-policy=no-user-gesture-required',
      '--enable-unsafe-swiftshader', 'about:blank'], { stdio: ['ignore', 'ignore', 'pipe'] }); procs.push(chrome);
    const wsUrl = await new Promise((res, rej) => { let s = ''; chrome.stderr.on('data', d => { s += d; const m = s.match(/DevTools listening on (ws:\/\/\S+)/); if (m) res(m[1]); });
      setTimeout(() => rej(new Error('no devtools endpoint')), 15000); });
    const ws = new WebSocket(wsUrl); await new Promise((r, j) => { ws.onopen = r; ws.onerror = j; });
    let id = 0; const pend = new Map();
    ws.onmessage = e => { const m = JSON.parse(e.data);
      if (m.id && pend.has(m.id)) { const p = pend.get(m.id); pend.delete(m.id); m.error ? p.rej(new Error(JSON.stringify(m.error))) : p.res(m.result); }
      else if (m.method === 'Runtime.consoleAPICalled' && consoleLog.length < 100) consoleLog.push({ type: m.params.type, text: m.params.args.map(a => a.value ?? a.description).join(' ').slice(0, 300) });
      else if (m.method === 'Runtime.exceptionThrown') consoleLog.push({ type: 'exception', text: JSON.stringify(m.params.exceptionDetails).slice(0, 500) }); };
    const send = (method, params = {}, sessionId) => new Promise((res, rej) => { const i = ++id; pend.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params, sessionId })); });
    const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });
    const S = (m, p) => send(m, p, sessionId);
    await S('Runtime.enable'); await S('Page.enable');
    await S('Emulation.setDeviceMetricsOverride', { width: 1280, height: 1000, deviceScaleFactor: 1, mobile: false });
    const ev = async expr => { const r = await S('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }); if (r.exceptionDetails) throw new Error(JSON.stringify(r.exceptionDetails).slice(0, 400)); return r.result.value; };
    const waitFor = async (expr, ms, label = expr) => { const t0 = Date.now(); for (;;) { const v = await ev(expr).catch(() => null); if (v) return v;
      if (Date.now() - t0 > ms) throw new Error(`timeout waiting for ${label}; status=${await ev("document.getElementById('status').textContent").catch(() => '?')}`); await sleep(100); } };
    const open = async () => { await S('Page.navigate', { url: info.url }); await waitFor("document.readyState === 'complete' && document.getElementById('build').textContent.length > 0", 20000, 'launcher ready'); };
    const click = async elId => { const r = await ev(`(() => { const r = document.getElementById(${JSON.stringify(elId)}).getBoundingClientRect(); return { x: r.x + r.width / 2, y: r.y + r.height / 2 }; })()`);
      for (const type of ['mousePressed', 'mouseReleased']) await S('Input.dispatchMouseEvent', { type, x: r.x, y: r.y, button: 'left', clickCount: 1 }); await sleep(50); };
    const keyEvent = (type, code) => { const [key, vk, location = 0] = VK[code]; return S('Input.dispatchKeyEvent', { type, code, key, windowsVirtualKeyCode: vk, nativeVirtualKeyCode: vk, location }); };
    const keyDown = c => keyEvent('keyDown', c), keyUp = c => keyEvent('keyUp', c);
    const press = async (c, hold = 120) => { await keyDown(c); await sleep(hold); await keyUp(c); };
    const setFile = async f => { const { root: r } = await S('DOM.getDocument'); const { nodeId } = await S('DOM.querySelector', { nodeId: r.nodeId, selector: '#file' }); await S('DOM.setFileInputFiles', { nodeId, files: [f] }); };
    const shotPng = async () => Buffer.from((await ev("document.getElementById('screen').toDataURL('image/png')")).split(',')[1], 'base64');
    return { server: info, S, ev, waitFor, open, click, keyDown, keyUp, press, setFile, shotPng, console: consoleLog, close };
  } catch (e) { await close(); throw e; }
}
