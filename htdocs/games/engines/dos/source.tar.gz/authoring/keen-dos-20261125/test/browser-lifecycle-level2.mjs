// Real-browser closed-loop level-entry attempt (evidence only). Like a player watching the screen: replays the native
// probe3 title->map prefix as focused CDP key events timed by the page's emulated clock, records where the browser
// frame differs from the native frame (bounding box), walks Right while watching for the native level-gate frame or a
// stall, retries with small Up/Down taps (bounded), presses Ctrl, captures, then Pause/Resume with NO screen click.
// node test/browser-lifecycle-level2.mjs [WEB_ROOT]
import fs from 'node:fs'; import path from 'node:path'; import { createHash } from 'node:crypto'; import { fileURLToPath } from 'node:url';
import { openBrowser, sleep } from './browser-lifecycle-cdp.mjs'; import { same, ascii, topColors, readPng } from './browser-lifecycle-png.mjs'; import { KEEN as KR } from './fixtures.mjs';
const ROOT = fileURLToPath(new URL('../', import.meta.url)).replace(/\/$/, ''), WEB = path.resolve(process.argv[2] || ROOT);
const KEEN = KR instanceof URL ? fileURLToPath(KR) : String(KR);
const NAT = path.join(ROOT, 'verification/web-candidate-20261125t192958z/out/gameplay-probe3');
const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..*/, 'Z').toLowerCase();
const OUT = path.join(ROOT, `build/lifecycle-20261125/level2-${stamp}`); fs.mkdirSync(OUT, { recursive: true });
const sha = b => createHash('sha256').update(b).digest('hex');
const N = { A: readPng(path.join(NAT, 'game-shot-00022951.png')), G: readPng(path.join(NAT, 'game-shot-00035000.png')), L: readPng(path.join(NAT, 'game-shot-00037800.png')) };
const R = { format: 'posse-dos-browser-lifecycle-level2/1', stamp, webRoot: WEB, packageSha256Before: sha(fs.readFileSync(KEEN)), events: [], probes: [], walks: [], shots: [] };
const b = await openBrowser({ root: WEB, profileDir: path.join(OUT, 'profile') }); R.servedWasm = b.server.wasm;
const { ev, waitFor, click, keyDown, keyUp, setFile } = b; const P = {};
const emuAt = ms => ev(`new Promise(r => { const f = () => window.__ms >= ${ms} ? r(window.__ms) : setTimeout(f, 2); f(); })`);
const now = () => ev('window.__ms');
const key = async (dir, code, ms) => { const at = ms == null ? await now() : await emuAt(ms); await (dir === 'down' ? keyDown(code) : keyUp(code)); R.events.push([code, dir, ms, at, await ev('document.activeElement.id')]); };
const tap = async (code, hold = 60) => { await key('down', code); await sleep(hold); await key('up', code); };
const cmp = n => ev(`(() => { const c = __cmp(${JSON.stringify(n)}); return { ...c, h: __hash(), ms: __ms }; })()`);
const grab = async label => { const v = await ev("(() => { const c = $('screen'); const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let s = ''; for (let i = 0; i < d.length; i += 8192) s += String.fromCharCode.apply(null, d.subarray(i, i + 8192)); return { w: c.width, h: c.height, b: btoa(s), png: c.toDataURL('image/png'), ms: window.__ms }; })()");
  const rgba = Buffer.from(v.b, 'base64'), px = Buffer.alloc(v.w * v.h * 3); for (let i = 0, j = 0; i < rgba.length; i += 4, j += 3) { px[j] = rgba[i]; px[j + 1] = rgba[i + 1]; px[j + 2] = rgba[i + 2]; }
  const png = Buffer.from(v.png.split(',')[1], 'base64'); fs.writeFileSync(path.join(OUT, label + '.png'), png); const p = P[label] = { w: v.w, h: v.h, px };
  const s = { label, emuMs: v.ms, pngSha256: sha(png), top: topColors(p), vsNatMap22951: same(p, N.A), vsNatGate35000: same(p, N.G), vsNatLevel37800: same(p, N.L) }; R.shots.push(s); return s; };
async function walkRight(tag, maxMs = 6000) {
  const t0 = await now(); await key('down', 'ArrowRight'); let best = 0, bestMs = 0, lastH = null, stillMs = t0, res, r;
  for (;;) { await sleep(20); r = await cmp('G'); if (r.s > best) { best = r.s; bestMs = r.ms; }
    if (r.s >= 0.985) { res = 'match'; break; } if (best >= 0.95 && r.s < best - 0.02) { res = 'passed-peak'; break; }
    if (r.h !== lastH) { lastH = r.h; stillMs = r.ms; } else if (r.ms - stillMs > 800) { res = 'stall'; break; }
    if (r.ms - t0 > maxMs) { res = 'timeout'; break; } }
  await key('up', 'ArrowRight'); const w = { tag, res, best: +best.toFixed(4), bestMs, endMs: r.ms, bbox: r.bb }; R.walks.push(w); await grab('walk-' + tag); return w; }
try {
  await b.open(); await setFile(KEEN); await waitFor("$('exe').options.length > 0 && !$('exe').disabled", 20000);
  await ev("(() => { const s = $('exe'); s.value = 'KEEN1.EXE'; s.dispatchEvent(new Event('change')); return true; })()"); await waitFor("!$('start').disabled", 20000);
  await click('start'); await waitFor('session && session.worker', 5000);
  await ev("window.__ms = 0, session.worker.addEventListener('message', e => { if (e.data.type === 'frame' || e.data.type === 'clock') window.__ms = Math.max(window.__ms, e.data.ms); }), true");
  const T = Object.fromEntries(Object.entries(N).map(([k, p]) => [k, p.px.toString('base64')]));
  await ev(`(() => { window.__tg = {}; for (const [k, v] of Object.entries(${JSON.stringify(T)})) window.__tg[k] = Uint8Array.from(atob(v), c => c.charCodeAt(0));
    window.__px = () => { const c = $('screen'); return c.width === 320 && c.height === 200 ? c.getContext('2d').getImageData(0, 0, 320, 200).data : null; };
    window.__cmp = n => { const d = __px(); if (!d) return { s: 0, bb: null }; const T = __tg[n]; let s = 0, x0 = 999, y0 = 999, x1 = -1, y1 = -1;
      for (let i = 0, j = 0, p = 0; i < d.length; i += 4, j += 3, p++) { if (d[i] === T[j] && d[i + 1] === T[j + 1] && d[i + 2] === T[j + 2]) s++; else { const x = p % 320, y = (p / 320) | 0; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; } }
      return { s: s / 64000, bb: x1 < 0 ? null : [x0, y0, x1, y1] }; };
    window.__hash = () => { const d = __px(); if (!d) return 0; let h = 2166136261; for (let i = 0; i < d.length; i += 4) { h ^= d[i] ^ (d[i + 1] << 8) ^ (d[i + 2] << 16); h = Math.imul(h, 16777619) >>> 0; } return h; }; return true; })()`);
  await waitFor('window.__ms > 2000', 30000); await click('screen');
  for (const [c, d, u] of [['Space', 12001, 12201], ['Enter', 15201, 15401], ['Enter', 18401, 18501], ['ArrowDown', 22001, 22301]]) { await key('down', c, d); await key('up', c, u); }
  await emuAt(22951); R.probes.push({ at: 'map-22951', ...(await cmp('A')) }); await grab('a-map-22951');
  await key('down', 'ControlLeft', 23001); await key('up', 'ControlLeft', 23201);
  await emuAt(33001); await grab('b-dialog-33001'); await emuAt(33101);
  let w = await walkRight('1'), tries = 0;
  for (const [code, n] of [['ArrowUp', 1], ['ArrowDown', 2], ['ArrowUp', 2], ['ArrowDown', 3]]) { if (w.res === 'match' || w.res === 'passed-peak' || tries >= 4) break; tries++;
    for (let i = 0; i < n; i++) await tap(code, 90); await sleep(200); R.probes.push({ at: `after-${code}x${n}`, ...(await cmp('G')) }); w = await walkRight(`${tries + 1}-${code}x${n}`); }
  await sleep(150); const g = await grab('c-before-ctrl'); const tc = await now(); await key('down', 'ControlLeft'); await sleep(300); await key('up', 'ControlLeft');
  await emuAt(tc + 2600); await grab('d-after-ctrl-2600'); await emuAt(tc + 3400); await grab('e-after-ctrl-3400');
  await click('pause'); await sleep(800); const paused = await ev("({ paused, active: document.activeElement.id, ms: __ms })"); await click('pause');
  const resumed = await ev("({ paused, active: document.activeElement.id, head: Atomics.load(ctl, 0) })");
  await keyDown('ArrowRight'); await sleep(1000); await keyUp('ArrowRight'); await sleep(400);
  R.resume = { paused, resumed, pushed: (await ev('Atomics.load(ctl, 0)')) - resumed.head, ringConsumed: await ev('Atomics.load(ctl, 0) === Atomics.load(ctl, 1)') };
  await grab('f-after-resume-right'); R.resume.changedFrac = +(1 - same(P['e-after-ctrl-3400'], P['f-after-resume-right'])).toFixed(3);
  await click('stop'); await waitFor('session.exited', 10000); R.exit = await ev('session.exited.reason');
} catch (e) { R.error = String(e.message || e); } finally { R.console = b.console; await b.close(); }
R.packageSha256After = sha(fs.readFileSync(KEEN)); fs.writeFileSync(path.join(OUT, 'result.json'), JSON.stringify(R, null, 1) + '\n');
for (const l of ['a-map-22951', 'c-before-ctrl', 'e-after-ctrl-3400', 'f-after-resume-right']) if (P[l]) console.log(`### browser ${l}\n${ascii(P[l])}`);
console.log('### native 22951\n' + ascii(N.A));
console.log(JSON.stringify({ out: OUT, error: R.error, wasm: R.servedWasm, probes: R.probes, walks: R.walks, shots: R.shots.map(s => [s.label, s.emuMs, s.top, s.vsNatMap22951, s.vsNatGate35000, s.vsNatLevel37800]), resume: R.resume, exit: R.exit, focus: [...new Set(R.events.map(e => e[4]))], pkgSame: R.packageSha256After === R.packageSha256Before, console: R.console.filter(c => c.type !== 'log').slice(0, 5) }));
