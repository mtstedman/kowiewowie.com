// Tooling tests: compact native tool-result contract (agents/tool-template.mjs)
// and the exact-owned resume/upgrade registration flow (agents/registration-flow.mjs)
// driven offline by a fake automation owner that executes the real generated tool code.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import * as catalog from '../agents/catalog.mjs';
import { runtimeInventory } from '../agents/inventory.mjs';
import { buildPlan, applyRegistration, evaluateSmoke, validateAnchor, validatePrevious, loadPrevious, anchorSha256, HANDOFF_LIMIT, RESULT_BUDGET, MUTATING, STATE_FORMAT } from '../agents/registration-flow.mjs';
import { operationSmokeBuilders } from '../agents/operation-smoke.mjs';
import { makeZip } from './fixtures.mjs';

const ROOT = fileURLToPath(new URL('../', import.meta.url)).replace(/\/$/, '');
const KEEN = path.join(ROOT, 'inputs/commander-keen-1.zip');
const HAVE_KEEN = fs.existsSync(KEEN);
const NO_KEEN = !HAVE_KEEN && 'supplied archive absent';
const TEMPLATE = fs.readFileSync(path.join(ROOT, 'agents/tool-template.mjs'), 'utf8');
const ANCHOR = JSON.parse(fs.readFileSync(path.join(ROOT, 'agent-config/intake-partial-registration.json'), 'utf8'));
const sha = s => createHash('sha256').update(s).digest('hex');
const { inventory, digest: runtimeDigest } = runtimeInventory(ROOT);
const TMP = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'dos-tooling-')));
test.after(() => fs.rmSync(TMP, { recursive: true, force: true }));
let seq = 0;
const fresh = label => path.join(TMP, `${label}-${++seq}`);

function writeTool(extra = {}, inv = inventory, root = ROOT) {
  const config = { operation: 'inspect', root, inventory: inv, outputRoot: path.join(TMP, 'out'), node: process.execPath, readRoots: [ROOT, TMP], ...extra };
  const file = path.join(TMP, `tool-${++seq}.mjs`);
  fs.writeFileSync(file, TEMPLATE.replace('__DOS_TOOL_CONFIG__', () => JSON.stringify(config)));
  return file;
}
function callRaw(tool, stdin) {
  const r = spawnSync(process.execPath, [tool], { input: stdin, encoding: 'utf8', timeout: 60000 });
  assert.equal(r.status, 0, r.stderr); assert.equal(r.stderr, '');
  const text = r.stdout.trimEnd();
  assert.ok(!text.includes('\n'), 'exactly one JSON line');
  return { out: JSON.parse(text), bytes: Buffer.byteLength(text) };
}
const call = (tool, input) => callRaw(tool, JSON.stringify(input));
function assertError(r, code, pattern) {
  assert.equal(r.out.status, 'error', JSON.stringify(r.out).slice(0, 300));
  assert.equal(r.out.error.code, code, r.out.error.message);
  if (pattern) assert.match(r.out.error.message, pattern);
  assert.ok(!('result' in r.out), 'errors carry no partial result');
  assert.ok(r.bytes < HANDOFF_LIMIT);
}

let SMOKE = null;
if (HAVE_KEEN) {
  const { PackageManager } = await import('../lib/package/PackageManager.mjs');
  const { metadata } = await new PackageManager().importFile(KEEN, { executable: 'KEEN1.EXE' });
  SMOKE = { packagePath: KEEN, expected: { ...metadata.candidateIdentity } };
}
const GRANTS = [{ standalone: true }, { repo_path: '/scope/canonical' }, { repo_path: '/scope/worktree' }];
// The registration-engine scenarios below were written for an inspect-only catalog; keep them exactly that way
// now that run/validate are implemented (their planning is covered in test/operations.test.mjs).
const INSPECT_ONLY = { ...catalog, TOOLS: catalog.TOOLS.map(t => (t.operation === 'inspect' ? t : { ...t, implemented: false })) };
const makePlan = (cat = INSPECT_ONLY, extra = {}) => buildPlan({ source: ROOT, catalog: cat, template: TEMPLATE, inventory, runtimeDigest, runtimeRoot: ROOT,
  outputRoot: path.join(TMP, 'out'), readRoots: [ROOT], node: process.execPath, smoke: SMOKE, grantScopes: GRANTS, ...extra });

// ---------------- native tool-result contract ----------------
test('normal selection: explicit KEEN1.EXE keeps exact identity within the native budget', { skip: NO_KEEN }, () => {
  const r = call(writeTool(), { package_path: KEEN, executable: 'KEEN1.EXE', expected_format: 'dos-mz' });
  assert.equal(r.out.status, 'ok');
  const res = r.out.result;
  assert.ok(r.bytes <= RESULT_BUDGET && r.bytes < HANDOFF_LIMIT, String(r.bytes));
  assert.equal(res.format, 'dos-inspection-summary/1');
  assert.deepEqual(res.package.candidateIdentity, SMOKE.expected);
  assert.equal(res.package.archiveSha256, SMOKE.expected.archiveSha256);
  assert.equal(res.package.contentDigest, SMOKE.expected.contentDigest);
  assert.equal(res.package.selection, 'explicit');
  assert.equal(res.package.executable, 'KEEN1.EXE');
  assert.equal(res.package.packageIdentity.executable, 'KEEN1.EXE');
  assert.equal(res.selected.sha256, SMOKE.expected.executableSha256);
  assert.equal(res.selected.format, 'dos-mz');
  assert.match(JSON.stringify(res.selected), /LZEXE/);
  assert.equal(res.package.executables[0].dosPath, 'KEEN1.EXE');
  assert.equal(res.counts.members, res.package.files);
  assert.equal(res.counts.executables, res.package.executables.length);
  assert.equal(res.counts.excluded, 1);
  assert.equal(res.package.excluded.length, 1);
  assert.match(res.package.excluded[0].reason, /8\.3/);
  assert.ok(res.package.machineProfile);
  assert.deepEqual({ identity: res.completeness.identity, listsComplete: res.completeness.listsComplete, membersListed: res.completeness.membersListed }, { identity: true, listsComplete: true, membersListed: 0 });
  assert.equal(res.completeness.omitted.members, res.counts.members);
  assert.ok(res.limitations.some(l => /member inventory is omitted/.test(l)));
  // The full per-file inventory remains available from the CLI.
  const cli = spawnSync(process.execPath, [path.join(ROOT, 'bin/dos.mjs'), 'inspect', KEEN, '--exe', 'KEEN1.EXE'], { encoding: 'utf8' });
  const full = JSON.parse(cli.stdout);
  assert.equal(full.package.members.length, res.counts.members);
  assert.ok(Buffer.byteLength(cli.stdout) > HANDOFF_LIMIT, 'the full document is what overflowed the handoff');
});

test('normal selection: no executable reports selection=required and never chooses', { skip: NO_KEEN }, () => {
  const r = call(writeTool(), { package_path: KEEN });
  assert.equal(r.out.status, 'ok');
  const res = r.out.result;
  assert.equal(res.package.selection, 'required');
  assert.equal(res.package.executable, null);
  assert.equal(res.package.candidateIdentity, null);
  assert.equal(res.selected, null);
  assert.equal(res.package.executables.length, res.counts.executables);
  assert.ok(res.counts.executables > 1);
  assert.ok(res.limitations.some(l => /choose one explicitly/.test(l)));
});

test('8 KiB boundary: exact budget fits, one byte less shortens lists explicitly, too small is an explicit error', { skip: NO_KEEN }, () => {
  const input = { package_path: KEEN, executable: 'KEEN1.EXE' };
  const n = call(writeTool(), input).bytes;
  assert.ok(n >= 1000 && n <= RESULT_BUDGET);
  const exact = call(writeTool({ resultBudget: n }), input);
  assert.equal(exact.bytes, n); assert.equal(exact.out.result.completeness.listsComplete, true);
  const under = call(writeTool({ resultBudget: n - 1 }), input);
  assert.equal(under.out.status, 'ok');
  assert.ok(under.bytes <= n - 1);
  const c = under.out.result.completeness;
  assert.equal(c.listsComplete, false);
  assert.equal(c.omitted.executables + c.omitted.excluded > 0, true);
  assert.equal(c.executablesListed + c.omitted.executables, under.out.result.counts.executables);
  assert.equal(c.excludedListed + c.omitted.excluded, under.out.result.counts.excluded);
  assert.deepEqual(under.out.result.package.candidateIdentity, SMOKE.expected);
  assert.ok(under.out.result.limitations.some(l => /Lists shortened/.test(l)));
  const max = call(writeTool({ resultBudget: HANDOFF_LIMIT }), input);
  assert.equal(max.out.status, 'ok');
  assertError(call(writeTool({ resultBudget: HANDOFF_LIMIT + 1 }), input), 'config', /512\.\.8192/);
  assertError(call(writeTool({ resultBudget: 511 }), input), 'config');
  const small = call(writeTool({ resultBudget: 512 }), input);
  assertError(small, 'result_too_large', /No truncated result/);
  assert.ok(small.out.error.details.bytes > 512);
  assert.equal(small.out.error.details.counts.members, max.out.result.counts.members);
});

test('larger packages: many executables/exclusions are shortened with exact counts, selected first', () => {
  const com = Buffer.from([0xb8, 0x00, 0x4c, 0xcd, 0x21]);
  const files = [];
  for (let i = 0; i < 120; i++) files.push({ name: `GAME/P${String(i).padStart(3, '0')}.COM`, data: com });
  for (let i = 0; i < 60; i++) files.push({ name: `GAME/excluded-long-file-name-${i}.txt`, data: Buffer.from('x') });
  const zip = path.join(TMP, 'many.zip');
  fs.writeFileSync(zip, makeZip(files));
  const tool = writeTool();
  const r = call(tool, { package_path: zip, executable: 'P077.COM' });
  assert.equal(r.out.status, 'ok', JSON.stringify(r.out).slice(0, 300));
  assert.ok(r.bytes <= RESULT_BUDGET);
  const res = r.out.result;
  assert.deepEqual(res.counts, { members: 120, executables: 120, rejectedExecutables: 0, excluded: 60 });
  assert.equal(res.package.executables[0].dosPath, 'P077.COM');
  assert.equal(res.package.candidateIdentity.executable, 'P077.COM');
  assert.equal(res.completeness.listsComplete, false);
  assert.equal(res.completeness.executablesListed + res.completeness.omitted.executables, 120);
  assert.equal(res.completeness.excludedListed + res.completeness.omitted.excluded, 60);
  const none = call(tool, { package_path: zip });
  assert.equal(none.out.status, 'ok');
  assert.equal(none.out.result.package.selection, 'required');
  assert.equal(none.out.result.counts.executables, 120);
  assert.ok(none.bytes <= RESULT_BUDGET);
});

test('malformed input and runtime failures are structured errors with codes', { skip: NO_KEEN }, () => {
  const tool = writeTool();
  assertError(callRaw(tool, ''), 'invalid_json');
  assertError(callRaw(tool, '{not json'), 'invalid_json');
  assertError(callRaw(tool, 'null'), 'invalid_input', /Invalid input fields/);
  assertError(callRaw(tool, '[]'), 'invalid_input', /Invalid input fields/);
  assertError(callRaw(tool, JSON.stringify({ package_path: '/x.zip', root: 'x'.repeat(20000) })), 'input_too_large', /exceeds 16 KiB/);
  assertError(call(tool, { package_path: KEEN, run_id: 'x' }), 'invalid_input', /Invalid input fields/);
  assertError(call(tool, { package_path: KEEN, executable: '--machine' }), 'invalid_input', /Invalid executable/);
  assertError(call(tool, { package_path: 'relative.zip' }), 'invalid_input', /absolute/);
  assertError(call(tool, { package_path: '/etc/hostname' }), 'invalid_input', /read roots/);
  assertError(call(tool, { package_path: path.join(ROOT, 'inputs/does-not-exist.zip') }), 'invalid_input');
  assertError(call(tool, { package_path: KEEN, executable: 'KEEN1.EXE', expected_format: 'dos-com' }), 'runtime_failed', /^Executable format mismatch/);
  assertError(call(tool, { package_path: KEEN, executable: 'NOPE.EXE' }), 'runtime_failed', /not a package executable/);
  assertError(call(tool, { package_path: path.join(ROOT, 'package.json') }), 'runtime_failed');
  assertError(call(writeTool({}, { ...inventory, 'package.json': '0'.repeat(64) }), { package_path: KEEN }), 'runtime_integrity', /integrity mismatch/);
});

test('runtime output that is oversized or inconsistent is never passed through', () => {
  const fake = fs.realpathSync(fs.mkdtempSync(path.join(TMP, 'fake-runtime-')));
  fs.mkdirSync(path.join(fake, 'bin'));
  const script = "import fs from 'node:fs'; process.stdout.write(fs.readFileSync(process.argv[3], 'utf8'));\n";
  fs.writeFileSync(path.join(fake, 'bin/dos.mjs'), script);
  const tool = writeTool({ readRoots: [TMP] }, { 'bin/dos.mjs': sha(script) }, fake);
  const h = c => c.repeat(64);
  const doc = (over = {}) => ({ format: 'dos-inspection/1', package: { system: 'dos', abi: 'posse-dos-package/1', archiveSha256: h('a'), archiveBytes: 10, archiveComment: '', root: '', contentDigest: h('b'), machine: 'pc-svga', machineProfile: {}, files: 1, totalBytes: 5,
    members: [{ dosPath: 'A.COM', bytes: 5, sha256: h('c') }], excluded: [], executables: [{ dosPath: 'A.COM', sha256: h('c'), format: 'dos-com' }], selection: 'explicit', executable: 'A.COM', format: 'dos-com', packageIdentity: {},
    candidateIdentity: { archiveSha256: h('a'), root: '', contentDigest: h('b'), executable: 'A.COM', executableSha256: h('c'), format: 'dos-com', machine: 'pc-svga' }, ...over } });
  const run = (name, body) => { const f = path.join(fake, name); fs.writeFileSync(f, typeof body === 'string' ? body : JSON.stringify(body)); return call(tool, { package_path: f }); };
  assert.equal(run('ok.json', doc()).out.status, 'ok');
  const huge = run('huge.json', doc({ root: 'R'.repeat(9000) }));
  assertError(huge, 'result_too_large', /native handoff budget/);
  assert.ok(huge.out.error.details.bytes > RESULT_BUDGET);
  assertError(run('garbage.json', 'not json'), 'runtime_output_invalid');
  assertError(run('count.json', doc({ files: 2 })), 'runtime_output_invalid', /member count/);
  const bad = doc(); bad.package.candidateIdentity.executableSha256 = h('d');
  assertError(run('identity.json', bad), 'runtime_output_invalid', /inconsistent/);
  assertError(run('format.json', { format: 'other', package: {} }), 'runtime_output_invalid');
});

// ---------------- registration flow ----------------
// FakeOwner mirrors the response shapes of the local owner source (read only, never imported):
// AutomationOwner.js dispatch; ScriptToolRegistry.{list,show,create,code,saveCode,saveManifest,test,grant};
// AutomationService.grant records {id,tool,digest,scope,repo_id,roles,operations,unattended,enabled};
// AgentDefinitionStore.{list,save}; AgentToolRuntime.pin. Owner failures throw, as AutomationOwnerClient
// rejects {ok:false} frames; quirks[method] model non-throwing failures, malformed responses and races.
const LEGACY = '// legacy tool: returns the full inspection document (pre-fix behaviour)';
const FLAGMAP = { executable: '--exe', machine: '--machine', expected_format: '--format', root: '--root' };
function legacyRun(input) {
  const args = [path.join(ROOT, 'bin/dos.mjs'), 'inspect', input.package_path];
  for (const [k, f] of Object.entries(FLAGMAP)) if (input[k] !== undefined) args.push(f, input[k]);
  const r = spawnSync(process.execPath, args, { encoding: 'utf8' });
  return r.status === 0 ? { status: 'ok', result: JSON.parse(r.stdout) } : { status: 'error', error: { message: r.stderr } };
}
const codeFiles = new Map();
function runCode(code, input) {
  if (code === LEGACY) return legacyRun(input);
  if (!codeFiles.has(code)) { const f = path.join(TMP, `owner-tool-${codeFiles.size}.mjs`); fs.writeFileSync(f, code); codeFiles.set(code, f); }
  return JSON.parse(spawnSync(process.execPath, [codeFiles.get(code)], { input: JSON.stringify(input), encoding: 'utf8', timeout: 240000 }).stdout);
}
const repoId = p => `repo-${sha(String(p)).slice(0, 16)}`;
const ownerError = (message, code) => Object.assign(new Error(message), { code });
class FakeOwner {
  constructor({ scripts = [], agents = [], legacyAgent = false, quirks = {} } = {}) {
    this.scripts = new Map(scripts.map(s => [s.name, { grants: [], code: null, published: null, ...structuredClone(s) }]));
    this.agents = new Map(agents.map(a => [a.name, structuredClone(a)]));
    this.legacyAgent = legacyAgent; this.quirks = quirks; this.calls = [];
  }
  rehash(s) { s.digest = sha(JSON.stringify([s.manifest, s.code])); }
  get(name) { const s = this.scripts.get(name); if (!s) throw ownerError(`No script tool named ${name}`, 'script_not_found'); return s; }
  status(s) {
    const pin = s.manifest.invoke_agent;
    const ready = s.published === s.digest && (!pin || this.agents.get(pin.name)?.digest === pin.digest);
    return { name: s.name, description: s.manifest.description, effect: s.manifest.effect, digest: s.digest, published_digest: s.published, tested: ready, stale: !!s.published && !ready, secrets: [], dir: `/owner/tools/${s.name}` };
  }
  show(name, repoPath) {
    const s = this.get(name);
    return structuredClone({ ...this.status(s), manifest: s.manifest, grants: s.grants, ...(typeof repoPath === 'string' && path.isAbsolute(repoPath) ? { context_repo_id: repoId(repoPath) } : {}) });
  }
  pin(t) {
    const a = this.agents.get(t?.name); if (!a) throw ownerError(`No agent named ${t?.name}`, 'agent_not_found');
    if (t.digest && t.digest !== a.digest) throw ownerError('Selected agent changed; reload its definition', 'agent_changed');
    return { name: a.name, digest: a.digest };
  }
  async request(method, p = {}) {
    this.calls.push({ method, params: structuredClone(p) });
    const q = this.quirks[method];
    if (q) { const r = await q.call(this, p); if (r !== undefined) return r; }
    return this.handle(method, p);
  }
  handle(method, p) {
    switch (method) {
      case 'script.list': return [...this.scripts.values()].map(s => this.status(s));
      case 'agent.definition.list': return [...this.agents.values()].map(a => structuredClone({ name: a.name, definition: a.definition, digest: a.digest, storage: 'central_db', errors: [] }));
      case 'script.show': return this.show(p.name, p.repo_path);
      case 'script.code.get': { const s = this.get(p.name); if (s.manifest.invoke_agent) throw ownerError(`${p.name} invokes an agent and has no script`, 'script_invalid'); return { name: s.name, code: s.code, digest: s.digest }; }
      case 'script.create': {
        const spec = p.spec, agent = spec.template === 'agent';
        if (this.scripts.has(spec.name)) throw ownerError(`/owner/tools/${spec.name} already exists; edit it or pick another name`, 'script_invalid');
        const manifest = { schema: 'posse.script_tool.v1', name: spec.name, description: spec.description, ...(agent ? { invoke_agent: this.pin(spec.invoke_agent) } : { entry: 'run.mjs', interpreter: 'node' }),
          params: spec.input_schema, output_schema: agent ? { type: 'object' } : spec.output_schema, env: [], effect: agent ? 'write' : spec.effect, timeout_seconds: spec.timeout_seconds, max_output_bytes: 65536 };
        const s = { name: spec.name, manifest, code: agent ? null : '// placeholder', grants: [], published: null };
        this.rehash(s); this.scripts.set(s.name, s);
        return structuredClone({ name: s.name, dir: `/owner/tools/${s.name}`, entry: agent ? null : 'run.mjs', manifest });
      }
      case 'script.code.save': {
        const s = this.get(p.name);
        if (s.manifest.invoke_agent) throw ownerError(`${p.name} invokes an agent and has no script`, 'script_invalid');
        if (p.expected_digest !== s.digest) throw ownerError('Tool changed since its code was opened; reload before saving', 'script_changed');
        s.code = p.code; this.rehash(s); return this.show(p.name);
      }
      case 'script.manifest.save': {
        const s = this.get(p.name);
        if (p.expected_digest !== s.digest) throw ownerError('Tool changed since it was opened; reload before saving', 'script_changed');
        const x = p.spec ?? {};
        s.manifest = { ...s.manifest, description: x.description || s.manifest.description, params: x.input_schema || s.manifest.params, output_schema: x.output_schema || s.manifest.output_schema,
          timeout_seconds: x.timeout_seconds ?? s.manifest.timeout_seconds, ...(s.manifest.invoke_agent ? { invoke_agent: this.pin(x.invoke_agent || s.manifest.invoke_agent) } : {}) };
        this.rehash(s); return this.show(p.name);
      }
      case 'script.grant': {
        const s = this.get(p.name);
        if (!this.status(s).tested) throw ownerError(`${p.name} has no passing test for its current version`, 'invalid_request');
        if (!p.standalone && !(typeof p.repo_path === 'string' && path.isAbsolute(p.repo_path))) throw ownerError('A repository grant needs an absolute repo path', 'invalid_request');
        const roles = [...new Set(p.roles ?? ['dev'])].sort(), rid = p.standalone ? undefined : repoId(p.repo_path);
        const id = `script-${p.name}-${sha(JSON.stringify([rid || 'standalone', roles])).slice(0, 10)}`;
        const g = { id, tool: `script:${p.name}`, digest: s.digest, scope: p.standalone ? 'standalone' : 'repository', ...(rid ? { repo_id: rid } : {}), roles, operations: ['describe', 'invoke'], resources: [], unattended: p.unattended === true, enabled: true };
        s.grants = s.grants.filter(x => x.id !== id).concat(g); return structuredClone(g);
      }
      case 'agent.definition.save': {
        const d = p.definition, exists = this.agents.has(d.name);
        if (p.create && exists) throw ownerError(`Agent ${d.name} already exists`, 'agent_invalid');
        if (!p.create && !exists) throw ownerError(`No agent named ${d.name}`, 'agent_not_found');
        const a = { name: d.name, digest: sha(JSON.stringify(d)), definition: structuredClone(d) }; this.agents.set(d.name, a);
        return structuredClone({ definition: a.definition, digest: a.digest, storage: 'central_db' });
      }
      case 'script.test': {
        const s = this.get(p.name);
        const output_json = s.manifest.invoke_agent ? this.agentTurn(s, p.input) : runCode(s.code, p.input);
        s.published = s.digest;
        const revoked = s.grants.filter(g => g.enabled && g.digest !== s.digest).map(g => { g.enabled = false; return g.id; });
        return { tool: p.name, digest: s.digest, result: { ok: true, exit_code: 0, output_json }, published: { id: `script:${p.name}`, digest: s.digest }, revoked_grants: revoked };
      }
      default: throw ownerError(`unsupported owner method ${method}`, 'invalid_request');
    }
  }
  agentTurn(s, input) {
    const pin = s.manifest.invoke_agent, a = this.agents.get(pin.name);
    if (!a || a.digest !== pin.digest) return { status: 'error', tool_calls: [], tool_summary: [], error: { message: 'pinned agent digest mismatch' } };
    const tool = a.definition.tools[0];
    const format = /^(dos-[a-z]+)-manager$/.exec(a.name)?.[1];
    const req = { ...input, ...(format && input.expected_format === undefined ? { expected_format: format } : {}) };
    const result = this.legacyAgent ? legacyRun(req) : runCode(this.get(tool).code, req);
    const truncated = Buffer.byteLength(JSON.stringify(result)) > HANDOFF_LIMIT; // native handoff budget
    const st = result.status === 'ok' ? 'ok' : 'error';
    return { status: 'done', agent: a.name, tool_calls: [{ tool, status: st, effect: 'read' }], tool_summary: [{ tool, status: st, effect: 'read', result: truncated ? null : result, result_truncated: truncated }], error: null };
  }
}
const rootGrant = (name, digest) => ({ id: `script-${name}-root`, tool: `script:${name}`, digest, scope: 'standalone', roles: ['dev'], operations: ['describe', 'invoke'], unattended: false, enabled: true });
const PROTECTED_SCRIPTS = [
  { name: 'dos-coordinator-invoke', digest: 'd'.repeat(64), published: 'd'.repeat(64), manifest: { name: 'dos-coordinator-invoke', description: 'root', invoke_agent: { name: 'dos-coordinator', digest: 'e'.repeat(64) } }, grants: [rootGrant('dos-coordinator-invoke', 'd'.repeat(64))] },
  { name: 'dos-engineer-invoke', digest: '1'.repeat(64), published: '1'.repeat(64), manifest: { name: 'dos-engineer-invoke', description: 'root', invoke_agent: { name: 'dos-engineer', digest: 'f'.repeat(64) } }, grants: [rootGrant('dos-engineer-invoke', '1'.repeat(64))] },
  { name: 'unrelated-tool', digest: '2'.repeat(64), published: '2'.repeat(64), manifest: { name: 'unrelated-tool', description: 'foreign', entry: 'run.mjs' }, code: '// foreign' },
];
const PROTECTED_AGENTS = [{ name: 'dos-coordinator', digest: 'e'.repeat(64), definition: { name: 'dos-coordinator' } }, { name: 'dos-engineer', digest: 'f'.repeat(64), definition: { name: 'dos-engineer' } }];
function anchoredOwner(opts = {}) {
  const [tool, binding] = ['dos-package-inspect', 'dos-mz-manager-invoke'].map(n => ANCHOR.tools.find(t => t.name === n));
  const mz = ANCHOR.agents.find(a => a.name === 'dos-mz-manager');
  return new FakeOwner({ ...opts,
    scripts: [{ name: tool.name, digest: tool.digest, published: tool.digest, manifest: tool.manifest, code: LEGACY }, { name: binding.name, digest: binding.digest, published: binding.digest, manifest: binding.manifest }, ...PROTECTED_SCRIPTS],
    agents: [{ name: mz.name, digest: mz.digest, definition: mz.definition }, ...PROTECTED_AGENTS] });
}
const freshOwner = (quirks = {}) => new FakeOwner({ scripts: PROTECTED_SCRIPTS, agents: PROTECTED_AGENTS, quirks });
const target = c => c.params?.name ?? c.params?.spec?.name ?? c.params?.definition?.name;
const mutations = (owner, from = 0) => owner.calls.slice(from).filter(c => MUTATING.includes(c.method));
const FOREIGN = ['dos-coordinator', 'dos-coordinator-invoke', 'dos-engineer', 'dos-engineer-invoke', 'unrelated-tool'];
function assertForeignUntouched(owner) {
  for (const c of owner.calls) assert.ok(!FOREIGN.includes(target(c)), `${c.method} touched ${target(c)}`);
}
const readState = dir => JSON.parse(fs.readFileSync(path.join(dir, 'state.json'), 'utf8'));
const stateSha = dir => sha(fs.readFileSync(path.join(dir, 'state.json')));
const prev = dir => loadPrevious(path.join(dir, 'state.json'), TMP, stateSha(dir));
async function expectFailure(promise, pattern) {
  const e = await promise.then(() => null, err => err);
  assert.ok(e, 'registration should fail'); assert.match(e.message, pattern); assert.equal(e.state.status, 'failed');
  return e.state;
}
const T = 'dos-package-inspect', UNREL = 'a'.repeat(64), FOREIGN_CODE = '/* unrelated */';
function foreignScript(name) {
  return { name, digest: UNREL, published: UNREL, code: FOREIGN_CODE, manifest: { schema: 'posse.script_tool.v1', name, description: 'someone else', entry: 'run.mjs', interpreter: 'node', params: { type: 'object' }, effect: 'write', timeout_seconds: 30 },
    grants: [{ id: `script-${name}-foreign`, tool: `script:${name}`, digest: UNREL, scope: 'standalone', roles: ['dev'], operations: ['describe', 'invoke'], unattended: false, enabled: true }] };
}
const plant = owner => owner.scripts.set(T, foreignScript(T));
function assertForeignIntact(owner) { const s = owner.scripts.get(T); assert.equal(s.code, FOREIGN_CODE); assert.equal(s.digest, UNREL); assert.equal(s.grants.length, 1); }
const writesTo = (owner, name) => owner.calls.filter(c => ['script.code.save', 'script.manifest.save', 'script.grant', 'script.test'].includes(c.method) && target(c) === name);
function assertFailureEvidence(dir, stage) {
  const st = readState(dir); assert.equal(st.status, 'failed'); assert.equal(st.failure.stage, stage);
  const loaded = loadPrevious(path.join(dir, 'state.json'), TMP, stateSha(dir));
  const files = [...loaded.receipts.keys()];
  assert.ok(files.some(f => /-failure\.json$/.test(f)) && files.some(f => /-summary\.json$/.test(f)), 'failure and summary receipts are listed and verify');
  assert.equal(loaded.unlisted.length, 0);
}

test('plan: only implemented operations with explicit smoke cases; Root-owned names refused', { skip: NO_KEEN }, () => {
  const plan = makePlan();
  assert.deepEqual(plan.tools.map(t => t.name), ['dos-package-inspect']);
  assert.deepEqual(plan.agents.map(a => a.name), ['dos-mz-manager', 'dos-com-manager']);
  assert.deepEqual(plan.deferredTools, ['dos-core-run', 'dos-core-validate']);
  for (const n of ['dos-coordinator', 'dos-coordinator-invoke', 'dos-engineer', 'dos-engineer-invoke', 'dos-cpu-engineer-invoke']) assert.ok(plan.protected.includes(n) && !plan.owned.includes(n), n);
  assert.deepEqual(plan.agents.find(a => a.name === 'dos-com-manager').smoke.expect, { errorPattern: 'format mismatch' });
  assert.deepEqual(plan.tools[0].smoke.expect.identity, SMOKE.expected);
  const runCat = { ...INSPECT_ONLY, TOOLS: INSPECT_ONLY.TOOLS.map(t => t.operation === 'run' ? { ...t, implemented: true } : t) };
  assert.throws(() => makePlan(runCat), /No explicit smoke case for operation run/);
  const runCase = { input: { package_path: KEEN, executable: 'KEEN1.EXE', run_id: 'explicit-run-case', until_ms: 1000 }, expect: {} };
  const withRun = makePlan(runCat, { smokeBuilders: { run: () => runCase } });
  assert.deepEqual(withRun.tools.find(t => t.operation === 'run').smoke, runCase);
  const rogue = { ...INSPECT_ONLY, AGENTS: [...catalog.AGENTS, { definition: { ...catalog.AGENTS[0].definition, name: 'dos-coordinator' }, operation: 'inspect' }] };
  assert.throws(() => makePlan(rogue), /Root-owned/);
  const noSmoke = buildPlan({ source: ROOT, catalog: INSPECT_ONLY, template: TEMPLATE, inventory, runtimeDigest, runtimeRoot: ROOT, outputRoot: TMP, readRoots: [ROOT], node: process.execPath, smoke: null, grantScopes: GRANTS });
  assert.equal(noSmoke.tools[0].smoke, null);
});

test('trust anchor: reviewed partial receipt validates; tampered anchors are refused', { skip: NO_KEEN }, () => {
  const plan = makePlan();
  const entries = validateAnchor(ANCHOR, plan);
  assert.deepEqual(Object.keys(entries).sort(), ['dos-mz-manager', 'dos-mz-manager-invoke', 'dos-package-inspect']);
  assert.equal(entries['dos-mz-manager-invoke'].kind, 'binding');
  const clone = () => structuredClone(ANCHOR);
  const a1 = clone(); a1.tools[0].published_digest = '0'.repeat(64);
  assert.throws(() => validateAnchor(a1, plan), /exact published/);
  const a2 = clone(); a2.agents.push({ ...a2.agents[0], name: 'dos-coordinator', definition: { ...a2.agents[0].definition, name: 'dos-coordinator' } });
  assert.throws(() => validateAnchor(a2, plan), /Root-owned/);
  const a3 = clone(); a3.tools[1].manifest.invoke_agent.digest = '0'.repeat(64);
  assert.throws(() => validateAnchor(a3, plan), /does not pin/);
  const a4 = clone(); a4.source = '/elsewhere';
  assert.throws(() => validateAnchor(a4, plan), /source/);
  const a5 = clone(); a5.format = 'other';
  assert.throws(() => validateAnchor(a5, plan), /format/);
});

test('the real truncated handoff receipt is a semantic failure, never success', { skip: NO_KEEN }, () => {
  const plan = makePlan();
  const diag = JSON.parse(fs.readFileSync(path.join(ROOT, 'receipts/mz-binding-diagnostic.json'), 'utf8'));
  const v = evaluateSmoke(plan.agents.find(a => a.name === 'dos-mz-manager'), diag, plan);
  assert.equal(v.passed, false); assert.equal(v.truncated, true);
  assert.ok(v.problems.some(p => /truncated/.test(p)));
  assert.equal(v.digest, '27caa77a8a5b5b5f8a46fb39cbd04c499d7e2ac6c2843403997bad170db23f1b');
});

test('N5: non-throwing create failures, malformed create responses and list-to-create races never save over another script', { skip: NO_KEEN }, async () => {
  const plan = makePlan();
  const cases = [
    ['non-throwing failure after a list-to-create race', /script\.create for dos-package-inspect did not succeed/, true, function (p) { if (p.spec.name === T) { plant(this); return { ok: false, error: 'name already exists' }; } }],
    ['owner throws on the duplicate (ScriptToolRegistry.create)', /already exists/, true, function (p) { if (p.spec.name === T) plant(this); }],
    ['success claimed with the foreign manifest', /not the requested script/, true, function (p) { if (p.spec.name === T) { plant(this); return { name: T, dir: '/x', entry: 'run.mjs', manifest: structuredClone(this.scripts.get(T).manifest) }; } }],
    ['created, then replaced before the fresh check', /not the fresh script/, true, function (p) { if (p.spec.name !== T) return; const r = this.handle('script.create', p); plant(this); return r; }],
    ['null response', /did not succeed/, false, p => (p.spec.name === T ? null : undefined)],
    ['string response', /did not succeed/, false, p => (p.spec.name === T ? 'created' : undefined)],
    ['empty object', /script\.create response names/, false, p => (p.spec.name === T ? {} : undefined)],
    ['other name', /script\.create response names/, false, p => (p.spec.name === T ? { name: 'other-tool', manifest: { name: 'other-tool' } } : undefined)],
    ['error alongside ok', /did not succeed/, false, p => (p.spec.name === T ? { ok: true, name: T, error: 'partial' } : undefined)],
  ];
  for (const [label, re, planted, quirk] of cases) {
    const owner = freshOwner({ 'script.create': quirk });
    const dir = fresh('n5');
    await expectFailure(applyRegistration({ owner, plan, receipts: dir }), re);
    assert.deepEqual(writesTo(owner, T), [], label);
    if (planted) assertForeignIntact(owner);
    assertFailureEvidence(dir, `tool:${T}`);
    assertForeignUntouched(owner);
  }
  // Replaced after the fresh check but before code.get: the pre-save digest is not the fresh script's.
  let swapped = false;
  const raced = freshOwner({ 'script.code.get': function (p) { if (p.name === T && !swapped) { swapped = true; plant(this); } } });
  const dr = fresh('n5');
  await expectFailure(applyRegistration({ owner: raced, plan, receipts: dr }), /Pre-save digest/);
  assert.deepEqual(writesTo(raced, T), []); assertForeignIntact(raced); assertFailureEvidence(dr, `tool:${T}`);
  // A code.save that reports failure without throwing stops before test or grants; the created script stays exactly resumable.
  const unsaved = freshOwner({ 'script.code.save': () => ({ ok: false, error: 'disk full' }) });
  const du = fresh('n5');
  const su = await expectFailure(applyRegistration({ owner: unsaved, plan, receipts: du }), /script\.code\.save for dos-package-inspect did not return the saved script/);
  assert.equal(su.entries[T].action, 'created-unsaved'); assert.equal(su.entries[T].origin, 'created');
  assert.ok(!unsaved.calls.some(c => ['script.test', 'script.grant'].includes(c.method)));
  delete unsaved.quirks['script.code.save'];
  await expectFailure(applyRegistration({ owner: unsaved, plan, previous: prev(du), receipts: fresh('n5') }), /code differs.*--upgrade-owned/);
  const done = await applyRegistration({ owner: unsaved, plan, previous: prev(du), upgrade: true, receipts: fresh('n5') });
  assert.equal(done.status, 'complete'); assert.equal(done.entries[T].action, 'upgraded');
  assert.equal(unsaved.scripts.get(T).code, plan.tools[0].code);
  // A save that reports success but installed other code is caught before test or grants.
  const other = freshOwner({ 'script.code.save': function (p) { return this.handle('script.code.save', { ...p, code: '// not the reviewed code' }); } });
  await expectFailure(applyRegistration({ owner: other, plan, receipts: fresh('n5') }), /not the reviewed planned code/);
  assert.ok(!other.calls.some(c => ['script.test', 'script.grant'].includes(c.method)));
});

test('owner write responses are verified: non-throwing grant and agent-save failures stop the run', { skip: NO_KEEN }, async () => {
  const plan = makePlan();
  const denied = freshOwner({ 'script.grant': () => ({ ok: false, error: 'denied' }) });
  const d1 = fresh('w');
  await expectFailure(applyRegistration({ owner: denied, plan, receipts: d1 }), /script\.grant for dos-package-inspect .* did not succeed/);
  assert.equal(denied.calls.filter(c => c.method === 'script.grant').length, 1);
  assert.ok(!denied.calls.some(c => c.method === 'agent.definition.save'));
  assertFailureEvidence(d1, `tool:${T}`);
  const wrongDigest = freshOwner({ 'script.grant': p => ({ id: 'g', tool: `script:${p.name}`, digest: 'c'.repeat(64), scope: 'standalone', enabled: true }) });
  await expectFailure(applyRegistration({ owner: wrongDigest, plan, receipts: fresh('w') }), /did not succeed/);
  const silent = freshOwner({ 'script.grant': () => ({ id: 'g' }) });
  await expectFailure(applyRegistration({ owner: silent, plan, receipts: fresh('w') }), /does not list the new grant/);
  for (const resp of [{ ok: false, error: 'invalid' }, { definition: { name: 'dos-mz-manager' }, digest: 'not-a-digest' }, { definition: { name: 'other' }, digest: 'c'.repeat(64) }]) {
    const o = freshOwner({ 'agent.definition.save': p => (p.definition.name === 'dos-mz-manager' ? resp : undefined) });
    const d = fresh('w');
    await expectFailure(applyRegistration({ owner: o, plan, receipts: d }), /agent\.definition\.save for dos-mz-manager did not return/);
    assert.ok(!o.calls.some(c => c.method === 'script.create' && target(c) === 'dos-mz-manager-invoke'));
    assertFailureEvidence(d, 'agent:dos-mz-manager');
  }
});

test('N6: resume ownership needs verified receipts, a reviewed state sha256 and the same anchor', { skip: NO_KEEN }, async () => {
  const plan = makePlan();
  // The verifier's probe B: a standalone forged state naming an owned tool at a foreign digest.
  const forged = { format: STATE_FORMAT, source: plan.source, runtimeDigest: plan.runtimeDigest, entries: { [T]: { kind: 'tool', name: T, digest: UNREL } } };
  assert.throws(() => validatePrevious(forged, plan, true), /standalone state\.json is not ownership evidence/);
  const victim = new FakeOwner({ scripts: [foreignScript(T), ...PROTECTED_SCRIPTS], agents: PROTECTED_AGENTS });
  await expectFailure(applyRegistration({ owner: victim, plan, previous: forged, upgrade: true, receipts: fresh('n6') }), /standalone/);
  assert.equal(victim.calls.length, 0, 'refused before contacting the owner');
  const d1 = fresh('n6'); fs.mkdirSync(d1); const f1 = path.join(d1, 'state.json');
  fs.writeFileSync(f1, JSON.stringify({ ...forged, receipts: d1 }));
  assert.throws(() => loadPrevious(f1, TMP, sha(fs.readFileSync(f1))), /no receipt log/);
  const otherRoot = fresh('n6-root'); fs.mkdirSync(otherRoot);
  // A real completed run.
  const owner = freshOwner(); const r = fresh('n6');
  await applyRegistration({ owner, plan, receipts: r });
  const sf = path.join(r, 'state.json'), orig = fs.readFileSync(sf), good = sha(orig);
  assert.equal(validatePrevious(loadPrevious(sf, TMP, good), plan, false).entries[T].evidence.origin, 'created');
  assert.throws(() => loadPrevious(sf, TMP, 'b'.repeat(64)), /--resume-sha256/);
  assert.throws(() => loadPrevious(sf, otherRoot, good), /must be/);
  const withRoot = JSON.parse(orig); withRoot.entries['dos-coordinator'] = { kind: 'agent', name: 'dos-coordinator', digest: 'e'.repeat(64) };
  fs.writeFileSync(sf, JSON.stringify(withRoot));
  assert.throws(() => validatePrevious(loadPrevious(sf, TMP, stateSha(r)), plan, true), /non-owned entry dos-coordinator/);
  const claim = JSON.parse(orig); claim.entries[T].digest = UNREL; fs.writeFileSync(sf, JSON.stringify(claim));
  assert.throws(() => loadPrevious(sf, TMP, good), /--resume-sha256/);
  assert.throws(() => validatePrevious(loadPrevious(sf, TMP, stateSha(r)), plan, true), /without a verified ownership-evidence receipt/);
  const evp = path.join(r, claim.entries[T].evidence.file), ev = JSON.parse(fs.readFileSync(evp, 'utf8'));
  ev.digest = UNREL; fs.writeFileSync(evp, JSON.stringify(ev, null, 2) + '\n');
  assert.throws(() => loadPrevious(sf, TMP, stateSha(r)), /does not match its recorded sha256/);
  // Anchor-derived ownership is honoured only with the same reviewed anchor.
  const ao = anchoredOwner(); const ra = fresh('n6');
  await applyRegistration({ owner: ao, plan, anchor: ANCHOR, upgrade: true, receipts: ra });
  assert.throws(() => validatePrevious(prev(ra), plan, false), /supply that same reviewed --anchor/);
  const edited = structuredClone(ANCHOR); edited.reason = 'edited';
  assert.throws(() => validatePrevious(prev(ra), plan, false, { anchorSha: anchorSha256(edited) }), /same reviewed --anchor/);
  assert.ok(validatePrevious(prev(ra), plan, false, { anchorSha: anchorSha256(ANCHOR) }).entries[T].digest);
  const mark = ao.calls.length;
  await expectFailure(applyRegistration({ owner: ao, plan, previous: prev(ra), receipts: fresh('n6') }), /--anchor/);
  assert.equal(ao.calls.length, mark, 'refused before contacting the owner');
});

test('anchored upgrade, exact resume, definition upgrade, failed-repin resume and external-change refusal', { skip: NO_KEEN }, async () => {
  const plan = makePlan();
  const owner = anchoredOwner();
  // 1. Without --upgrade-owned the anchored legacy code is not replaced.
  const r1 = fresh('reg');
  const s1 = await expectFailure(applyRegistration({ owner, plan, anchor: ANCHOR, receipts: r1 }), /code differs.*--upgrade-owned/);
  assert.equal(s1.failure.stage, 'tool:dos-package-inspect');
  assert.equal(mutations(owner).length, 0);
  assertFailureEvidence(r1, 'tool:dos-package-inspect');
  // 2. --upgrade-owned with the anchor completes.
  const r2 = fresh('reg');
  const s2 = await applyRegistration({ owner, plan, anchor: ANCHOR, upgrade: true, receipts: r2 });
  assert.equal(s2.status, 'complete'); assert.equal(readState(r2).format, STATE_FORMAT);
  assert.equal(owner.scripts.get('dos-package-inspect').code, plan.tools[0].code);
  assert.equal(owner.calls.find(c => c.method === 'script.code.save').params.expected_digest, ANCHOR.tools[0].digest);
  assert.equal(s2.entries['dos-package-inspect'].action, 'upgraded');
  assert.equal(s2.entries['dos-package-inspect'].origin, `anchor:${anchorSha256(ANCHOR)}`);
  assert.equal(s2.entries['dos-mz-manager'].action, 'unchanged');
  assert.equal(s2.entries['dos-mz-manager-invoke'].action, 'unchanged');
  assert.equal(owner.scripts.get('dos-mz-manager-invoke').digest, ANCHOR.tools[1].digest, 'binding not rewritten');
  assert.ok(!owner.calls.some(c => c.method === 'agent.definition.save' && target(c) === 'dos-mz-manager'));
  assert.equal(s2.entries['dos-com-manager'].action, 'created'); assert.equal(s2.entries['dos-com-manager-invoke'].origin, 'created');
  const mzSmoke = s2.entries['dos-mz-manager-invoke'].semantic;
  assert.equal(mzSmoke.passed, true); assert.equal(mzSmoke.truncated, false);
  assert.ok(mzSmoke.childBytes <= RESULT_BUDGET); assert.equal(mzSmoke.completeness.identity, true);
  assert.equal(s2.entries['dos-com-manager-invoke'].semantic.passed, true);
  for (const n of plan.owned.filter(n => owner.scripts.has(n))) {
    const s = owner.scripts.get(n), g = s.grants.filter(x => x.enabled);
    assert.equal(g.length, 3, n);
    for (const x of g) { assert.deepEqual(x.roles, ['dev']); assert.equal(x.unattended, false); assert.equal(x.digest, s.digest); }
  }
  assertForeignUntouched(owner);
  // 3. Exact resume: nothing changes, nothing is re-granted, tests are reused.
  let mark = owner.calls.length;
  const r3 = fresh('reg');
  const s3 = await applyRegistration({ owner, plan, anchor: ANCHOR, previous: prev(r2), receipts: r3 });
  assert.equal(s3.mode, 'resume'); assert.equal(mutations(owner, mark).length, 0);
  assert.ok(!owner.calls.slice(mark).some(c => c.method === 'script.test'));
  for (const n of ['dos-package-inspect', 'dos-mz-manager-invoke', 'dos-com-manager-invoke']) {
    assert.equal(s3.entries[n].test, 'reused', n);
    assert.deepEqual(s3.entries[n].grants.map(g => g.action), ['present', 'present', 'present']);
  }
  // 4. A reviewed definition change is refused without --upgrade-owned...
  const v2 = { ...INSPECT_ONLY, AGENTS: catalog.AGENTS.map(a => a.definition.name === 'dos-mz-manager' ? { ...a, definition: { ...a.definition, prompt: a.definition.prompt + '\nReviewed v2.' } } : a) };
  const plan2 = makePlan(v2);
  mark = owner.calls.length;
  const s4 = await expectFailure(applyRegistration({ owner, plan: plan2, anchor: ANCHOR, previous: prev(r3), receipts: fresh('reg') }), /definition differs.*--upgrade-owned/);
  assert.equal(s4.failure.stage, 'agent:dos-mz-manager'); assert.equal(mutations(owner, mark).length, 0);
  // 5a. ...a repin whose response reports failure without throwing stops before test or grants...
  owner.quirks['script.manifest.save'] = () => ({ ok: false, error: 'manifest write failed' });
  mark = owner.calls.length;
  const r5a = fresh('reg');
  const s5a = await expectFailure(applyRegistration({ owner, plan: plan2, anchor: ANCHOR, previous: prev(r3), upgrade: true, receipts: r5a }), /did not return the repinned binding/);
  assert.equal(s5a.entries['dos-mz-manager'].action, 'upgraded'); assert.equal(s5a.failure.stage, 'binding:dos-mz-manager-invoke');
  assert.ok(!owner.calls.slice(mark).some(c => ['script.test', 'script.grant'].includes(c.method) && target(c) === 'dos-mz-manager-invoke'));
  delete owner.quirks['script.manifest.save'];
  // 5b. ...and resumes exactly from that failed run: repin from the recorded pin, retest, restore only revoked grants.
  mark = owner.calls.length;
  const r5 = fresh('reg');
  const s5 = await applyRegistration({ owner, plan: plan2, anchor: ANCHOR, previous: prev(r5a), upgrade: true, receipts: r5 });
  assert.equal(s5.entries['dos-mz-manager'].action, 'unchanged');
  assert.equal(s5.entries['dos-mz-manager-invoke'].action, 'repinned');
  assert.equal(owner.calls.slice(mark).find(c => c.method === 'script.manifest.save').params.spec.invoke_agent.digest, owner.agents.get('dos-mz-manager').digest);
  assert.equal(s5.entries['dos-mz-manager-invoke'].test, 'ran');
  assert.equal(s5.entries['dos-package-inspect'].test, 'reused');
  const grantCalls = owner.calls.slice(mark).filter(c => c.method === 'script.grant');
  assert.deepEqual([...new Set(grantCalls.map(target))], ['dos-mz-manager-invoke']);
  assert.equal(grantCalls.length, 3, 'only grants revoked by the re-test are restored');
  // 6. An externally changed owned agent is never overwritten, even with --upgrade-owned.
  const com = owner.agents.get('dos-com-manager');
  com.definition = { ...com.definition, prompt: 'external edit' }; com.digest = sha(JSON.stringify(com.definition));
  mark = owner.calls.length;
  const s6 = await expectFailure(applyRegistration({ owner, plan: plan2, anchor: ANCHOR, previous: prev(r5), upgrade: true, receipts: fresh('reg') }), /externally changed/);
  assert.equal(s6.failure.stage, 'agent:dos-com-manager'); assert.equal(mutations(owner, mark).length, 0);
  assertForeignUntouched(owner);
});

test('truncated handoff stops before grants, is recorded, and resumes exactly once fixed', { skip: NO_KEEN }, async () => {
  const plan = makePlan();
  const owner = anchoredOwner({ legacyAgent: true });
  const r1 = fresh('trunc');
  const s1 = await expectFailure(applyRegistration({ owner, plan, anchor: ANCHOR, upgrade: true, receipts: r1 }), /truncated/);
  assert.equal(s1.failure.stage, 'binding:dos-mz-manager-invoke');
  const sem = readState(r1).entries['dos-mz-manager-invoke'].semantic;
  assert.equal(sem.passed, false); assert.equal(sem.truncated, true);
  assert.ok(!owner.calls.some(c => c.method === 'script.grant' && target(c) === 'dos-mz-manager-invoke'));
  assert.equal(owner.scripts.get('dos-package-inspect').grants.length, 3, 'tool passed and was granted');
  assert.ok(fs.readdirSync(r1).some(f => /dos-mz-manager-invoke-test\.json$/.test(f)), 'raw failing smoke receipt saved');
  assertFailureEvidence(r1, 'binding:dos-mz-manager-invoke');
  owner.legacyAgent = false;
  const mark = owner.calls.length;
  const s2 = await applyRegistration({ owner, plan, anchor: ANCHOR, previous: prev(r1), receipts: fresh('trunc') });
  assert.equal(s2.status, 'complete');
  assert.equal(s2.entries['dos-package-inspect'].test, 'reused');
  assert.equal(s2.entries['dos-mz-manager-invoke'].test, 'ran');
  assert.equal(s2.entries['dos-mz-manager-invoke'].semantic.passed, true);
  assert.equal(owner.calls.slice(mark).filter(c => c.method === 'script.code.save').length, 0);
  assert.equal(owner.scripts.get('dos-mz-manager-invoke').grants.filter(g => g.enabled).length, 3);
  assertForeignUntouched(owner);
});

test('unknown existing entries are refused without any mutation', { skip: NO_KEEN }, async () => {
  const plan = makePlan();
  const owner = new FakeOwner({ scripts: [{ name: T, digest: '3'.repeat(64), manifest: ANCHOR.tools[0].manifest, code: '// someone else' }, ...PROTECTED_SCRIPTS], agents: PROTECTED_AGENTS });
  await expectFailure(applyRegistration({ owner, plan, upgrade: true, receipts: fresh('unknown') }), /not recorded by the trust anchor/);
  assert.equal(mutations(owner).length, 0);
  const changed = anchoredOwner(); changed.scripts.get(T).digest = '4'.repeat(64);
  await expectFailure(applyRegistration({ owner: changed, plan, anchor: ANCHOR, upgrade: true, receipts: fresh('unknown') }), /externally changed/);
  assert.equal(mutations(changed).length, 0);
  const odd = anchoredOwner(); odd.scripts.get(T).grants = [{ scope: 'opaque', enabled: true }];
  await expectFailure(applyRegistration({ owner: odd, plan, anchor: ANCHOR, upgrade: true, receipts: fresh('unknown') }), /unrecognized shape/);
  assert.ok(!odd.calls.some(c => c.method === 'script.grant'));
});

test('run/validate smoke verdicts need ok results, exact identity, requested shots, all checks and the pinned core', { skip: NO_KEEN }, () => {
  const pin = 'c'.repeat(64);
  const plan = makePlan(catalog, { smokeBuilders: operationSmokeBuilders('syn1'), binaryPin: { sha256: pin, source: 'test' } });
  const run = plan.tools.find(t => t.operation === 'run'), val = plan.tools.find(t => t.operation === 'validate');
  assert.notDeepEqual(run.smoke.input, plan.tools[0].smoke.input, 'run smoke does not reuse inspection input');
  assert.equal(plan.binaryPin.independentlyVerified, false);
  const wrap = result => ({ tool: 'x', digest: 'f'.repeat(64), published: { id: 'x', digest: 'f'.repeat(64) }, result: { ok: true, exit_code: 0, output_json: { status: 'ok', result } } });
  const okRun = { format: 'dos-run-summary/1', ok: true, candidateIdentity: SMOKE.expected, binarySha256: pin, exit: 'until-ms', shots: [{ ms: 0 }, { ms: 1000 }] };
  const okVal = { format: 'dos-validate/1', ok: true, candidateIdentity: SMOKE.expected, binarySha256: pin, checks: [{ name: 'a', passed: true }], runs: [{}, {}] };
  assert.equal(evaluateSmoke(run, wrap(okRun), plan).passed, true);
  assert.equal(evaluateSmoke(val, wrap(okVal), plan).passed, true);
  const bad = (over, re, item = run, base = okRun) => { const v = evaluateSmoke(item, wrap({ ...base, ...over }), plan); assert.equal(v.passed, false); assert.ok(v.problems.some(p => re.test(p)), v.problems.join(' | ')); };
  bad({ format: 'dos-validate/1' }, /unexpected result format/);
  bad({ ok: false }, /not ok/);
  bad({ candidateIdentity: { ...SMOKE.expected, executableSha256: '0'.repeat(64) } }, /candidate identity/);
  bad({ exit: 'program-exit' }, /until_ms/);
  bad({ shots: [{ ms: 0 }] }, /shots_ms/);
  bad({ binarySha256: 'd'.repeat(64) }, /not independently verified/);
  bad({ checks: [{ name: 'a', passed: false }] }, /checks/, val, okVal);
  bad({ runs: [{}] }, /two runs/, val, okVal);
  bad({ format: 'dos-run-summary/1' }, /unexpected result format/, val, okVal);
  assert.throws(() => makePlan(catalog, { smokeBuilders: operationSmokeBuilders('syn2'), binaryPin: { sha256: 'xyz', source: 's' } }), /binaryPin/);
});

const NATIVE = path.join(ROOT, 'build/native/posse-dosbox');
const NO_NATIVE = (!HAVE_KEEN || !fs.existsSync(NATIVE)) && 'native core or supplied archive absent';
function coreAuthentic() {
  const r = spawnSync(process.execPath, [path.join(ROOT, 'core/port/scripts/provenance.mjs')], { cwd: ROOT, encoding: 'utf8', timeout: 120000 });
  return { ok: r.status === 0, detail: String(r.stderr || r.stdout || '').trim().slice(0, 300) };
}
test('full catalog offline: run/validate register with their own smoke cases, or stop ungranted when the core is not authentic', { skip: NO_NATIVE, timeout: 600000 }, async t => {
  const core = JSON.parse(fs.readFileSync(path.join(ROOT, 'build/native/build-manifest.json'), 'utf8')).output.sha256;
  const plan = makePlan(catalog, { smokeBuilders: operationSmokeBuilders(`e2e${Date.now().toString(36)}`), outputRoot: path.join(TMP, 'runs'),
    binaryPin: { sha256: core, source: 'test: build/native/build-manifest.json output.sha256 (self-reported)' } });
  assert.deepEqual(plan.tools.map(x => x.name), ['dos-package-inspect', 'dos-core-run', 'dos-core-validate']);
  assert.deepEqual(plan.agents.map(a => a.name), ['dos-mz-manager', 'dos-com-manager', 'dos-core-runner', 'dos-validator']);
  const ops = [...plan.tools, ...plan.agents].filter(i => i.operation !== 'inspect');
  assert.equal(new Set(ops.map(i => i.smoke.input.run_id)).size, ops.length, 'fresh run id per smoke');
  for (const i of ops) { assert.equal(i.smoke.input.until_ms, 1000); assert.ok(i.smoke.expect.runIdentity && !i.smoke.expect.identity, i.name); }
  const owner = freshOwner(); const r = fresh('full');
  const auth = coreAuthentic();
  if (!auth.ok) {
    // Core sources changed after the native build (not owned by tooling). The real run smoke must fail, be recorded, and never be granted.
    t.diagnostic(`native core not authentic for the current tree (${auth.detail}); exercised the refusal path only`);
    const st = await expectFailure(applyRegistration({ owner, plan, receipts: r }), /Semantic smoke failed for dos-core-run/);
    assert.equal(st.failure.stage, 'tool:dos-core-run');
    assert.match(st.entries['dos-core-run'].semantic.problems.join(' '), /source tree digest|rebuild/);
    assert.equal(st.entries['dos-package-inspect'].semantic.passed, true);
    assert.equal(owner.scripts.get('dos-core-run').grants.length, 0);
    assert.ok(!owner.scripts.has('dos-core-validate') && !owner.agents.has('dos-core-runner'), 'nothing after the failed stage');
    assertFailureEvidence(r, 'tool:dos-core-run');
    assertForeignUntouched(owner);
    return;
  }
  const s = await applyRegistration({ owner, plan, receipts: r });
  assert.equal(s.status, 'complete');
  for (const n of ['dos-core-run', 'dos-core-validate', 'dos-core-runner-invoke', 'dos-validator-invoke']) {
    assert.equal(s.entries[n].semantic.passed, true, n); assert.equal(s.entries[n].semantic.truncated, false); assert.ok(s.entries[n].semantic.childBytes <= RESULT_BUDGET, n);
    assert.equal(owner.scripts.get(n).grants.filter(g => g.enabled && g.digest === owner.scripts.get(n).digest).length, 3, n);
  }
  assertForeignUntouched(owner);
  const mark = owner.calls.length;
  const s2 = await applyRegistration({ owner, plan, previous: prev(r), receipts: fresh('full') });
  assert.equal(s2.status, 'complete'); assert.equal(mutations(owner, mark).length, 0);
  assert.ok(!owner.calls.slice(mark).some(c => c.method === 'script.test'));
});

test('register.mjs default is an offline plan with sha256-pinned anchor/resume commands and prerequisites', { skip: NO_KEEN }, () => {
  const reg = (...a) => spawnSync(process.execPath, [path.join(ROOT, 'agents/register.mjs'), ...a], { encoding: 'utf8' });
  const before = fs.readdirSync(path.join(ROOT, 'receipts')).filter(n => n.startsWith('tooling-registration-'));
  const anchorFile = path.join(ROOT, 'agent-config/intake-partial-registration.json'), anchorFileSha = sha(fs.readFileSync(anchorFile));
  const r = reg();
  assert.equal(r.status, 0, r.stderr);
  const plan = JSON.parse(r.stdout);
  assert.match(plan.mode, /offline/);
  assert.equal(plan.anchor.valid, true); assert.equal(plan.anchor.fileSha256, anchorFileSha);
  assert.deepEqual(plan.anchor.unanchored, ['dos-core-run', 'dos-core-validate', 'dos-com-manager', 'dos-com-manager-invoke', 'dos-core-runner', 'dos-core-runner-invoke', 'dos-validator', 'dos-validator-invoke']);
  assert.deepEqual(plan.deferredTools, []);
  assert.equal(plan.proposedCommands.apply, `node agents/register.mjs --apply --upgrade-owned --anchor agent-config/intake-partial-registration.json --anchor-sha256 ${anchorFileSha}`);
  assert.match(plan.proposedCommands.resume, /--resume-sha256 /);
  assert.equal(plan.binaryPin, null); assert.match(plan.nativeCore.status, /not independently verified/);
  assert.ok(Array.isArray(plan.prerequisites) && plan.prerequisites.length >= 5);
  assert.deepEqual(plan.tools[0].smoke.expect.identity, SMOKE.expected);
  assert.equal(plan.resultBudget, RESULT_BUDGET);
  assert.deepEqual(fs.readdirSync(path.join(ROOT, 'receipts')).filter(n => n.startsWith('tooling-registration-')), before);
  assert.ok(!fs.existsSync(path.join(ROOT, 'agents/registration.json')));
  const bad = reg('--bogus'); assert.equal(bad.status, 1); assert.match(bad.stderr, /Unknown argument/);
  const res = reg('--resume', path.join(ROOT, 'package.json'));
  assert.equal(res.status, 0); assert.equal(JSON.parse(res.stdout).previous.valid, false); assert.match(JSON.parse(res.stdout).previous.error, /resume-sha256/);
  const outside = reg('--resume', path.join(ROOT, 'package.json'), '--resume-sha256', sha(fs.readFileSync(path.join(ROOT, 'package.json'))));
  assert.equal(JSON.parse(outside.stdout).previous.valid, false);
  assert.equal(reg('--resume-sha256', 'abc').status, 1);
  const lone = reg('--resume-sha256', 'b'.repeat(64)); assert.equal(lone.status, 1); assert.match(lone.stderr, /requires --resume/);
  const pinned = JSON.parse(reg('--binary-sha256', 'c'.repeat(64)).stdout);
  assert.equal(pinned.binaryPin.sha256, 'c'.repeat(64)); assert.equal(pinned.binaryPin.independentlyVerified, false);
  const wrong = JSON.parse(reg('--anchor', anchorFile, '--anchor-sha256', 'b'.repeat(64)).stdout);
  assert.equal(wrong.anchor.valid, false); assert.match(wrong.anchor.error, /differs/);
});
