import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { inspectPackage, requireCandidate, sha256, dosComponent } from '../lib/package/inspect.mjs';
import { readZip } from '../lib/package/zip.mjs';
import { PackageManager } from '../lib/package/PackageManager.mjs';
import { makeZip, makeMz, KEEN, KEEN_SHA256 } from './fixtures.mjs';

const com = Buffer.from([0xb4, 0x4c, 0xcd, 0x21]);
const ok = (extra = []) => makeZip([{ name: 'GAME/GAME.EXE', data: makeMz() }, { name: 'GAME/DATA.DAT', data: Buffer.from('data') }, ...extra]);

test('synthetic package: sole candidate, root detection, identity', () => {
  const zip = ok();
  const { metadata, drive } = inspectPackage(zip);
  assert.equal(metadata.root, 'GAME');
  assert.equal(metadata.selection, 'sole-candidate');
  assert.equal(metadata.executable, 'GAME.EXE');
  assert.equal(metadata.format, 'dos-mz');
  assert.equal(metadata.archiveSha256, sha256(zip));
  assert.deepEqual(Object.keys(metadata.candidateIdentity).sort(), ['archiveSha256', 'contentDigest', 'executable', 'executableSha256', 'format', 'machine', 'root']);
  assert.deepEqual([...drive.keys()].sort(), ['DATA.DAT', 'GAME.EXE']);
  assert.ok(Object.isFrozen(metadata) && Object.isFrozen(metadata.members[0]));
});

test('multi-executable packages require explicit selection', () => {
  const zip = ok([{ name: 'GAME/SETUP.COM', data: com }]);
  const { metadata } = inspectPackage(zip);
  assert.equal(metadata.selection, 'required');
  assert.equal(metadata.executable, null);
  assert.throws(() => requireCandidate(metadata), /Executable selection required/);
  const explicit = inspectPackage(zip, { executable: 'c:\\setup.com' }).metadata;
  assert.equal(explicit.executable, 'SETUP.COM');
  assert.equal(explicit.format, 'dos-com');
  assert.equal(explicit.selection, 'explicit');
  assert.throws(() => inspectPackage(zip, { executable: 'MISSING.EXE' }), /not a package executable/);
  assert.throws(() => inspectPackage(zip, { executable: 'DATA.DAT' }), /not a package executable/);
  // Different selected programs yield different candidate identities.
  assert.notEqual(JSON.stringify(inspectPackage(zip, { executable: 'GAME.EXE' }).metadata.candidateIdentity), JSON.stringify(explicit.candidateIdentity));
});

test('format comes from bytes, not extension, title or hash', () => {
  // An .EXE without MZ is a flat image (DOS EXEC semantics); a .COM with MZ is MZ.
  const zip = makeZip([{ name: 'A.EXE', data: com }, { name: 'B.COM', data: makeMz() }]);
  const a = inspectPackage(zip, { executable: 'A.EXE' }).metadata, b = inspectPackage(zip, { executable: 'B.COM' }).metadata;
  assert.equal(a.format, 'dos-com'); assert.equal(a.executables[0].extensionMismatch, true);
  assert.equal(b.format, 'dos-mz');
  // Renaming members does not change classification.
  const renamed = makeZip([{ name: 'KEEN1.EXE', data: com }]);
  assert.equal(inspectPackage(renamed).metadata.format, 'dos-com');
  assert.throws(() => inspectPackage(zip, { executable: 'A.EXE', expectedFormat: 'dos-mz' }), /format mismatch/);
});

test('unsupported executable formats fail explicitly', () => {
  for (const sig of ['PE', 'NE', 'LE', 'LX']) {
    const zip = makeZip([{ name: 'WIN.EXE', data: makeMz({ newHeader: sig }) }]);
    assert.throws(() => requireCandidate(inspectPackage(zip).metadata), /Unsupported executable format/, sig);
  }
  assert.throws(() => inspectPackage(makeZip([{ name: 'T.EXE', data: Buffer.from('MZ\0\0') }])), /Truncated MZ header/);
  assert.throws(() => inspectPackage(makeZip([{ name: 'T.EXE', data: makeMz({ declareExtra: 4096 }) }])), /declares/);
  assert.throws(() => inspectPackage(makeZip([{ name: 'BIG.COM', data: Buffer.alloc(0xff01, 0x90) }])), /COM limit/);
  assert.throws(() => inspectPackage(makeZip([{ name: 'EMPTY.COM', data: Buffer.alloc(0) }])), /Empty executable/);
  assert.throws(() => inspectPackage(makeZip([{ name: 'README.TXT', data: Buffer.from('x') }])), /no DOS executable/);
  assert.throws(() => inspectPackage(ok(), { machine: 'amiga' }), /Unsupported machine profile/);
  assert.throws(() => inspectPackage(ok(), { expectedFormat: 'elf' }), /Unknown expected format/);
  assert.throws(() => inspectPackage(ok(), { bogus: 1 }), /Unknown inspection option/);
});

test('malformed and unsafe archives are rejected', () => {
  const good = ok();
  const cases = {
    'not a zip': Buffer.from('hello world, definitely not a zip archive'),
    'truncated': good.subarray(0, good.length - 5),
    'CRC mismatch': makeZip([{ name: 'A.COM', data: com, crc: 0x12345678 }]),
    'path traversal': makeZip([{ name: '../A.COM', data: com }]),
    'absolute path': makeZip([{ name: '/A.COM', data: com }]),
    'drive path': makeZip([{ name: 'C:A.COM', data: com }]),
    'backslash path': makeZip([{ name: 'X\\A.COM', data: com }]),
    'duplicate case-insensitive': makeZip([{ name: 'A.COM', data: com }, { name: 'a.com', data: com }]),
    'encrypted': makeZip([{ name: 'A.COM', data: com, flags: 1 }]),
    'unsupported method': makeZip([{ name: 'A.COM', data: com, method: 12 }]),
    'ZIP64 marker': makeZip([{ name: 'A.COM', data: com, usize: 0xffffffff }]),
    'multi-disk': makeZip([{ name: 'A.COM', data: com }], { corrupt: { disk: 1 } }),
    'entry count mismatch': makeZip([{ name: 'A.COM', data: com }], { corrupt: { count: 2 } }),
    'bad local offset': makeZip([{ name: 'A.COM', data: com, localOffset: 3 }]),
    'declared size lie': makeZip([{ name: 'A.COM', data: com, usize: 2 }]),
  };
  for (const [label, bytes] of Object.entries(cases)) assert.throws(() => inspectPackage(bytes), /ZIP rejected|DOS path|Package/, label);
  // Corrupted deflate stream.
  const bad = Buffer.from(good); bad[40] ^= 0xff;
  assert.throws(() => inspectPackage(bad), /ZIP rejected/);
});

test('DOS drive mapping excludes non-8.3 names and reports collisions', () => {
  assert.equal(dosComponent('keen1.exe'), 'KEEN1.EXE');
  for (const bad of ['Long file name.txt', 'TOOLONGNAME.EXE', 'A.TOOL', 'CON', 'nul.txt', 'A B.EXE', 'A.B.C']) assert.equal(dosComponent(bad), null, bad);
  const zip = makeZip([{ name: 'A.COM', data: com }, { name: 'Read me first.txt', data: Buffer.from('x') }]);
  const { metadata } = inspectPackage(zip);
  assert.equal(metadata.excluded.length, 1);
  assert.match(metadata.excluded[0].reason, /8\.3/);
  assert.throws(() => inspectPackage(makeZip([{ name: 'A.COM', data: com }, { name: 'A.COM/B.DAT', data: com }])), /collision/);
  assert.throws(() => inspectPackage(ok(), { root: '../x' }), /Invalid package root/);
  assert.throws(() => inspectPackage(ok(), { root: 'NOPE' }), /contains no files/);
});

test('package manager hands out independent drive copies', () => {
  const zip = ok(); const before = Buffer.from(zip);
  const mgr = new PackageManager();
  const { key } = mgr.importBytes(zip);
  const one = mgr.drive(key), two = mgr.drive(key);
  one.get('GAME.EXE')[0] = 0;
  assert.equal(two.get('GAME.EXE')[0], 0x4d);
  assert.equal(mgr.drive(key).get('GAME.EXE')[0], 0x4d);
  zip[0] ^= 0xff; // caller mutating its buffer must not affect the owned copy
  assert.equal(mgr.drive(key).get('GAME.EXE')[0], 0x4d);
  assert.ok(before.length);
});

test('Commander Keen 1 archive: pinned identity, explicit executable, unchanged input', { skip: !existsSync(KEEN) && 'input absent' }, () => {
  const bytes = readFileSync(KEEN);
  assert.equal(sha256(bytes), KEEN_SHA256);
  const { metadata, drive } = inspectPackage(bytes);
  assert.equal(metadata.root, 'CKeen1');
  assert.equal(metadata.files, 48);
  assert.equal(metadata.selection, 'required');
  assert.deepEqual(metadata.executables.map(c => [c.dosPath, c.format]), [['CATALOG.EXE', 'dos-mz'], ['DEALERS.EXE', 'dos-com'], ['KEEN1.EXE', 'dos-mz'], ['SWCBBS.EXE', 'dos-mz']]);
  const keen = inspectPackage(bytes, { executable: 'KEEN1.EXE' }).metadata;
  assert.equal(keen.candidateIdentity.executableSha256, '8b3f829f7eeab18a7fbf9d539967e9ae9c856258aa78efc0531fa922df71c4a2');
  assert.equal(keen.executables.find(c => c.dosPath === 'KEEN1.EXE').packer.name, 'LZEXE 0.91');
  // Execution uses the original packed bytes, not the optional unpacked analysis output.
  assert.equal(sha256(drive.get('KEEN1.EXE')), keen.candidateIdentity.executableSha256);
  // Every archive member is preserved byte-for-byte (via CRC/SHA in readZip).
  const zipNames = readZip(bytes).entries.filter(e => !e.directory).length;
  assert.equal(metadata.files + metadata.excluded.length, zipNames);
  assert.equal(sha256(readFileSync(KEEN)), KEEN_SHA256);
});

test('CLI inspect: success and explicit failure', { skip: !existsSync(KEEN) && 'input absent' }, () => {
  const bin = fileURLToPath(new URL('../bin/dos.mjs', import.meta.url));
  const r = spawnSync(process.execPath, [bin, 'inspect', fileURLToPath(KEEN), '--exe', 'keen1.exe'], { encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
  const out = JSON.parse(r.stdout);
  assert.equal(out.format, 'dos-inspection/1');
  assert.equal(out.package.executable, 'KEEN1.EXE');
  const bad = spawnSync(process.execPath, [bin, 'inspect', fileURLToPath(KEEN), '--exe', 'NOPE.EXE'], { encoding: 'utf8' });
  assert.equal(bad.status, 1);
  assert.match(JSON.parse(bad.stderr).error, /not a package executable/);
  const dup = spawnSync(process.execPath, [bin, 'inspect', fileURLToPath(KEEN), '--exe', 'A', '--exe', 'B'], { encoding: 'utf8' });
  assert.equal(dup.status, 1);
});
