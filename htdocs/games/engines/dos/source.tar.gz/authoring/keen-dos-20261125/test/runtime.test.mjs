// Runtime contract regressions for verification/native-review-20261125T180810Z.md findings 1-9 and 12.
// End-to-end cases need the authenticated native binary and the original package; they skip if either is absent.
import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, mkdirSync, writeFileSync, readFileSync, readdirSync, chmodSync, copyFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { join } from 'node:path';
import { DosRunner, DosRunError, DEFAULT_BINARY, ROOT, authenticateBinary } from '../lib/runner/DosRunner.mjs';
import { buildConfig } from '../lib/runner/conf.mjs';

const PKG = join(ROOT, 'inputs/commander-keen-1.zip');
const T = join(ROOT, 'build', `test-runtime-${process.pid}-${Date.now()}`);
mkdirSync(T, { recursive: true });
const live = existsSync(DEFAULT_BINARY) && existsSync(PKG) && existsSync(join(ROOT, 'build/native/build-manifest.json'));
const skip = live ? false : 'native binary, manifest or package absent';
const base = { packageFile: PKG, executable: 'KEEN1.EXE', machine: 'pc-svga' };
const h = f => createHash('sha256').update(readFileSync(f)).digest('hex');
const runner = () => new DosRunner({ instanceRoot: join(T, 'inst') });

test('F5: binary without a manifest, or not matching its manifest, is refused before any write', async () => {
  mkdirSync(join(T, 'fake'), { recursive: true });
  const fake = join(T, 'fake/posse-dosbox');
  writeFileSync(fake, '#!/bin/sh\necho {} > out/summary.json\n'); chmodSync(fake, 0o755);
  await assert.rejects(authenticateBinary(fake), /no readable build manifest/);
  writeFileSync(join(T, 'fake/build-manifest.json'), JSON.stringify({ format: 'posse-dos-build-manifest/1', output: { sha256: '0'.repeat(64) }, inputs: { inputDigest: 'x' } }));
  await assert.rejects(authenticateBinary(fake), /does not match its build manifest/);
  const r = new DosRunner({ binary: fake, instanceRoot: join(T, 'inst') });
  await assert.rejects(r.run({ ...base, untilMs: 100, instance: 'fake' }), /manifest/);
  assert.equal(existsSync(join(T, 'inst/fake')), false);
});
test('F4: missing binary is refused before the instance is created', async () => {
  const r = new DosRunner({ binary: join(T, 'nowhere/posse-dosbox'), instanceRoot: join(T, 'inst') });
  await assert.rejects(r.run({ ...base, untilMs: 100, instance: 'nobin' }), /binary unreadable/);
  assert.equal(existsSync(join(T, 'inst/nobin')), false);
});
test('F3: an existing run ID is never reused or deleted', { skip }, async () => {
  mkdirSync(join(T, 'inst/reuse'), { recursive: true });
  writeFileSync(join(T, 'inst/reuse/PRIOR-EVIDENCE.txt'), 'keep');
  await assert.rejects(runner().run({ ...base, untilMs: 100, instance: 'reuse' }), /immutable/);
  assert.equal(readFileSync(join(T, 'inst/reuse/PRIOR-EVIDENCE.txt'), 'utf8'), 'keep');
  assert.deepEqual(readdirSync(join(T, 'inst/reuse')), ['PRIOR-EVIDENCE.txt']);
});
test('F1/F2/F12: equal input gives identical shots from 0 ms; a shot at untilMs is written; modes recorded', { skip }, async () => {
  const shots = [0, 500, 1000, 1500, 2000, 2500, 3000, 3200];
  const sets = [];
  for (const n of ['det-a', 'det-bb', 'det-ccc']) {
    const o = await runner().run({ ...base, untilMs: 3200, shotsMs: shots, instance: n });
    assert.equal(o.ok, true);
    assert.deepEqual(o.summary.shotDetails.map(s => s.requestedMs), shots);
    assert.deepEqual(o.summary.shots, o.summary.shotDetails.map(s => s.file));
    assert.deepEqual(o.summary.missingShots, []);
    assert.ok(o.summary.modes.some(m => m.width === 640 && m.height === 400) && o.summary.modes.some(m => m.width === 320 && m.height === 200));
    const out = join(o.instanceDir, 'out');
    sets.push(JSON.stringify([o.summary.shotDetails.map(s => h(join(out, s.file))), h(join(out, 'frames.tsv')), h(join(out, 'audio.wav'))]));
  }
  assert.equal(new Set(sets).size, 1, 'shots, per-frame hashes and audio must be identical across equal runs');
});
test('F6: timeout is a rejected run with preserved evidence', { skip }, async () => {
  await assert.rejects(runner().run({ ...base, untilMs: 600000, timeoutMs: 200, instance: 'timeout' }), e => {
    assert.ok(e instanceof DosRunError); assert.equal(e.result.ok, false);
    assert.ok(e.result.failures.includes('timeout')); assert.ok(e.result.failures.includes('signal:SIGKILL'));
    return true;
  });
  assert.ok(existsSync(join(T, 'inst/timeout/result.json')));
});
test('F6: CLI exits nonzero for a failed run', { skip }, () => {
  const r = spawnSync(process.execPath, [join(ROOT, 'bin/dos-run.mjs'), PKG, '--exe', 'KEEN1.EXE', '--instance', `cli-fail-${process.pid}`, '--until-ms', '1000', '--shot-ms', '1001'], { encoding: 'utf8' });
  assert.equal(r.status, 1); assert.match(r.stderr, /shotsMs/);
});

function native(args, cwd = T) { return spawnSync(DEFAULT_BINARY, args, { cwd, encoding: 'utf8' }); }
function nopeConf() { mkdirSync(join(T, 'empty'), { recursive: true }); const c = join(T, 'nope.conf'); writeFileSync(c, buildConfig({ driveDir: join(T, 'empty'), executable: 'NOPE.EXE', format: 'dos-mz', machine: 'pc-svga' })); return c; }
test('F7: a nonexistent DOS program is a failure (exit 3, ok:false)', { skip }, () => {
  mkdirSync(join(T, 'o7'), { recursive: true });
  const r = native(['--conf', nopeConf(), '--until-ms', '1000', '--out', join(T, 'o7')]);
  assert.equal(r.status, 3);
  const s = JSON.parse(readFileSync(join(T, 'o7/summary.json'), 'utf8'));
  assert.equal(s.ok, false); assert.deepEqual(s.failures, ['program-exit-before-until-ms']);
});
test('F8: missing --out or config fails with exit 2 and writes nothing', { skip }, () => {
  assert.equal(native(['--conf', nopeConf(), '--until-ms', '1000', '--out', join(T, 'no-such-dir')]).status, 2);
  assert.equal(existsSync(join(T, 'no-such-dir')), false);
  mkdirSync(join(T, 'cwd8'), { recursive: true });
  assert.equal(native(['--conf', join(T, 'missing.conf'), '--until-ms', '1000'], join(T, 'cwd8')).status, 2);
  assert.deepEqual(readdirSync(join(T, 'cwd8')), []);
});
test('F9: malformed input lines are rejected; comments and blanks are accepted', { skip }, () => {
  mkdirSync(join(T, 'o9'), { recursive: true });
  for (const l of ['this line is not an event', '100 enter', '100 enter down extra', '-5 enter down', '100 bogus down', '1e3 enter down']) {
    writeFileSync(join(T, 'in9.txt'), l + '\n');
    const r = native(['--conf', nopeConf(), '--until-ms', '1000', '--out', join(T, 'o9'), '--input', join(T, 'in9.txt')]);
    assert.equal(r.status, 2, l); assert.match(r.stderr, /bad input line 1/);
  }
  assert.deepEqual(readdirSync(join(T, 'o9')), []);
  writeFileSync(join(T, 'in9.txt'), '# c\n\n  100 enter down\n200 enter up\n');
  const r = native(['--conf', nopeConf(), '--until-ms', '1000', '--out', join(T, 'o9'), '--input', join(T, 'in9.txt')]);
  assert.equal(r.status, 3); // parsed fine; fails only because NOPE.EXE does not exist
  assert.equal(JSON.parse(readFileSync(join(T, 'o9/summary.json'), 'utf8')).keysParsed, 2);
});
